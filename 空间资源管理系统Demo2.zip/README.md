
  # 空间资源管理系统Demo2

  This is a code bundle for 空间资源管理系统Demo2. The original project is available at https://www.figma.com/design/zDvpHjP6ib7iPGqBQMkUDj/%E7%A9%BA%E9%97%B4%E8%B5%84%E6%BA%90%E7%AE%A1%E7%90%86%E7%B3%BB%E7%BB%9FDemo2.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  