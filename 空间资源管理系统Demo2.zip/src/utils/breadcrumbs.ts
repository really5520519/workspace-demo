interface Breadcrumb {
  label: string;
  href: string;
  clickable: boolean;
}

export function getBreadcrumbs(activeItem: string): Breadcrumb[] {
  const breadcrumbs: Breadcrumb[] = [
    { label: "首页", href: "#", clickable: true }
  ];

  switch (activeItem) {
    case "system-homepage":
      // 系统主页只显示"首页"面包屑
      break;
    case "space-service":
      breadcrumbs.push({ label: "用户端", href: "#", clickable: true });
      breadcrumbs.push({ label: "员工侧", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间服务", href: "#", clickable: false });
      break;
    case "seat-binding":
      breadcrumbs.push({ label: "用户端", href: "#", clickable: true });
      breadcrumbs.push({ label: "员工侧", href: "#", clickable: true });
      breadcrumbs.push({ label: "工位绑定", href: "#", clickable: false });
      break;
    case "move-plan":
      breadcrumbs.push({ label: "用户端", href: "#", clickable: true });
      breadcrumbs.push({ label: "员工侧", href: "#", clickable: true });
      breadcrumbs.push({ label: "搬家计划", href: "#", clickable: false });
      break;
    case "space-resource-service":
      breadcrumbs.push({ label: "用户端", href: "#", clickable: true });
      breadcrumbs.push({ label: "部门侧", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间资源与服务", href: "#", clickable: false });
      break;
    case "requirement-application":
      breadcrumbs.push({ label: "用户端", href: "#", clickable: true });
      breadcrumbs.push({ label: "部门侧", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间资源与服务", href: "#", clickable: true });
      breadcrumbs.push({ label: "需求申请", href: "#", clickable: false });
      break;
    case "space-usage":
      breadcrumbs.push({ label: "用户端", href: "#", clickable: true });
      breadcrumbs.push({ label: "部门侧", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间资源使用", href: "#", clickable: false });
      break;
    case "space-billing":
      breadcrumbs.push({ label: "用户端", href: "#", clickable: true });
      breadcrumbs.push({ label: "部门侧", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间费用账单", href: "#", clickable: false });
      break;
    case "business-analysis":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "经营管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "经营分析", href: "#", clickable: false });
      break;
    case "budget-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "经营管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "预算管理", href: "#", clickable: false });
      break;
    case "cost-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "经营管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "成本管理", href: "#", clickable: false });
      break;
    case "pricing-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "经营管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "定价管理", href: "#", clickable: false });
      break;
    case "space-sku-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "经营管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "定价管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间SKU管理", href: "#", clickable: false });
      break;
    case "pricing-product-edit":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "经营管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "定价管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "商品编辑", href: "#", clickable: false });
      break;
    case "billing-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "经营管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "业务计费", href: "#", clickable: false });
      break;
    case "project-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "运营管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "项目管理", href: "#", clickable: false });
      break;
    case "project-workflow-statistics":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "运营管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "项目管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "项目全流程统计", href: "#", clickable: false });
      break;
    case "demand-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "运营管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "需求管理", href: "#", clickable: false });
      break;
    case "lease-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "运营管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "租赁管理", href: "#", clickable: false });
      break;
    case "tenancy-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "运营管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "租赁管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "租期管理", href: "#", clickable: false });
      break;
    case "construction-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "运营管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "项目施工管理", href: "#", clickable: false });
      break;
    case "allocation-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "运营管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间分配", href: "#", clickable: false });
      break;
    case "move-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "运营管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "搬家管理", href: "#", clickable: false });
      break;
    case "space-resource-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间资源管理", href: "#", clickable: false });
      break;
    case "workplace-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间资源管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "工区管理", href: "#", clickable: false });
      break;
    case "inventory-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间资源管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "库存管理", href: "#", clickable: false });
      break;
    case "space-statistics":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间资源管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间资源统计", href: "#", clickable: false });
      break;
    case "supply-demand-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间资源管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "供需管理", href: "#", clickable: false });
      break;
    case "facility-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间资源管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "设施设备管理", href: "#", clickable: false });
      break;
    case "building-file-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间资源管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "楼宇文件管理", href: "#", clickable: false });
      break;
    case "building-personnel-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间资源管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "楼宇人员管理", href: "#", clickable: false });
      break;
    case "building-supplier-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间资源管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "楼宇供应商管理", href: "#", clickable: false });
      break;
    case "building-operation-info":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "空间资源管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "楼宇运营信息", href: "#", clickable: false });
      break;
    case "permission-management":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "系统管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "权限管理", href: "#", clickable: false });
      break;
    case "operation-log":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "系统管理", href: "#", clickable: true });
      breadcrumbs.push({ label: "操作记录", href: "#", clickable: false });
      break;
    case "interface-config":
      breadcrumbs.push({ label: "管理端", href: "#", clickable: true });
      breadcrumbs.push({ label: "上下游配置", href: "#", clickable: true });
      breadcrumbs.push({ label: "接口", href: "#", clickable: false });
      break;
    default:
      breadcrumbs.push({ label: "功能页面", href: "#", clickable: true });
      break;
  }

  return breadcrumbs;
}