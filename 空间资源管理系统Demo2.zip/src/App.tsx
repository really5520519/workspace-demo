import { useState } from "react";
import { AppSidebar } from "./components/AppSidebar";
import { MainContent } from "./components/MainContent";
import { TopBar } from "./components/TopBar";
import {
  SidebarProvider,
  SidebarInset,
} from "./components/ui/sidebar";

export default function App() {
  const [activeItem, setActiveItem] = useState(
    "system-homepage",
  );
  const [isDark, setIsDark] = useState(false);
  const [projectId, setProjectId] = useState<
    string | undefined
  >();
  const [productId, setProductId] = useState<
    string | undefined
  >();

  const handleItemClick = (id: string, data?: any) => {
    console.log("handleItemClick called with:", id, data);
    setActiveItem(id);
    if (id === "project-details" && data?.projectId) {
      setProjectId(data.projectId);
      setProductId(undefined);
    } else if (id === "product-details" && data?.productId) {
      setProductId(data.productId);
      setProjectId(undefined);
    } else if (
      id === "pricing-product-edit" &&
      data?.productId
    ) {
      setProductId(data.productId);
      setProjectId(undefined);
    } else if (
      id !== "project-details" &&
      id !== "product-details" &&
      id !== "pricing-product-edit"
    ) {
      setProjectId(undefined);
      setProductId(undefined);
    }
  };

  const toggleTheme = () => {
    setIsDark(!isDark);
    document.documentElement.classList.toggle("dark");
  };

  return (
    <div className={`h-screen ${isDark ? "dark" : ""}`}>
      <SidebarProvider>
        <div className="flex h-full bg-background">
          <AppSidebar
            activeItem={activeItem}
            onItemClick={handleItemClick}
          />
          <SidebarInset className="flex-1 flex flex-col">
            <TopBar
              onThemeToggle={toggleTheme}
              isDark={isDark}
            />
            <MainContent
              activeItem={activeItem}
              onNavigate={handleItemClick}
              projectId={projectId}
              productId={productId}
            />
          </SidebarInset>
        </div>
      </SidebarProvider>
    </div>
  );
}