import { Button } from "./ui/button";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "./ui/breadcrumb";
import { FileText } from "lucide-react";
import { getBreadcrumbs } from "../utils/breadcrumbs";
import { SpaceResourceManagementOverviewContent } from "./pages/SpaceResourceManagementOverview";
import { ProjectManagementContent } from "./pages/ProjectManagement";
import { SystemHomepage } from "./pages/SystemHomepage";
import { SpaceResourceServiceContent as NewSpaceResourceServiceContent } from "./pages/SpaceResourceService";
import { RequirementApplication } from "./pages/RequirementApplication";
import { LeaseManagementContent as NewLeaseManagementContent } from "./pages/LeaseManagement";
import { TenancyManagementContent } from "./pages/TenancyManagement";
import { DemandManagementContent as NewDemandManagementContent } from "./pages/DemandManagement";
import { ConstructionManagementContent as NewConstructionManagementContent } from "./pages/ConstructionManagement";
import { SpaceAllocationManagementContent } from "./pages/SpaceAllocationManagement";
import { MoveManagementContent as NewMoveManagementContent } from "./pages/MoveManagement";
import { 
  WorkplaceManagementContent, 
  SpaceServiceContent, 
  SeatBindingContent, 
  MovePlanContent, 
  SpaceResourceServiceContent, 
  SpaceUsageContent, 
  SpaceBillingContent 
} from "./pages/AllPages";
import { 
  DefaultContent,
  BudgetManagementContent,
  CostManagementContent,
  PricingManagementContent,
  BillingManagementContent,
  DemandManagementContent,
  LeaseManagementContent,
  ConstructionManagementContent,
  AllocationManagementContent,
  MoveManagementContent,
  SupplyDemandManagementContent,
  FacilityManagementContent,
  BuildingFileManagementContent,
  BuildingPersonnelManagementContent,
  BuildingSupplierManagementContent,
  BuildingOperationInfoContent,
  PermissionManagementContent,
  OperationLogContent,
  InterfaceConfigContent
} from "./pages/DefaultContent";
import { InventoryManagementContent } from "./pages/InventoryManagement";
import { SpaceStatisticsContent } from "./pages/SpaceStatistics";
import { BudgetManagementContent as NewBudgetManagementContent } from "./pages/BudgetManagement";
import { SpaceBillingContent as NewSpaceBillingContent } from "./pages/SpaceBilling";
import { SupplyDemandManagementContent as NewSupplyDemandManagementContent } from "./pages/SupplyDemandManagement";
import { SpaceUsageContent as NewSpaceUsageContent } from "./pages/SpaceUsage";
import { BusinessAnalysis } from "./pages/BusinessAnalysis";
import { ProjectDetailsContent } from "./pages/ProjectDetails";
import { ProductDetailsContent } from "./pages/ProductDetails";
import { CostManagementContent as NewCostManagementContent } from "./pages/CostManagement";
import { BusinessBillingContent } from "./pages/BusinessBilling";
import { SpaceSKUManagementContent } from "./pages/SpaceSKUManagement";
import { PricingProductEditContent } from "./pages/PricingProductEdit";
import { ProjectWorkflowStatisticsContent } from "./pages/ProjectWorkflowStatistics";

interface MainContentProps {
  activeItem: string;
  onNavigate?: (targetId: string, data?: any) => void;
  projectId?: string;
  productId?: string;
}

export function MainContent({ activeItem, onNavigate, projectId, productId }: MainContentProps) {
  const breadcrumbs = getBreadcrumbs(activeItem);

  const getPageContent = () => {
    console.log("getPageContent called with activeItem:", activeItem);
    switch (activeItem) {
      case "system-homepage":
        return <SystemHomepage onNavigate={onNavigate || (() => {})} />;
      case "space-service":
        return <SpaceServiceContent onNavigate={onNavigate} />;
      case "seat-binding":
        return <SeatBindingContent />;
      case "move-plan":
        return <MovePlanContent />;
      case "space-resource-service":
        return <NewSpaceResourceServiceContent onNavigate={onNavigate} />;
      case "requirement-application":
        return <RequirementApplication onBack={() => onNavigate?.("space-resource-service")} />;
      case "space-usage":
        return <NewSpaceUsageContent />;
      case "space-billing":
        return <NewSpaceBillingContent />;
      case "business-analysis":
        return <BusinessAnalysis />;
      case "budget-management":
        return <NewBudgetManagementContent />;
      case "cost-management":
        return <NewCostManagementContent />;
      case "pricing-management":
        return <PricingManagementContent onNavigate={onNavigate} />;
      case "billing-management":
        return <BusinessBillingContent />;
      case "project-management":
        return <ProjectManagementContent onNavigate={onNavigate} />;
      case "project-details":
        return <ProjectDetailsContent projectId={projectId} onNavigateBack={() => onNavigate?.("project-management")} />;
      case "project-workflow-statistics":
        return <ProjectWorkflowStatisticsContent onNavigate={onNavigate} />;
      case "demand-management":
        return <NewDemandManagementContent />;
      case "lease-management":
        return <NewLeaseManagementContent onNavigate={onNavigate} />;
      case "tenancy-management":
        return <TenancyManagementContent onBack={() => onNavigate?.("lease-management")} />;
      case "construction-management":
        return <NewConstructionManagementContent />;
      case "allocation-management":
        return <SpaceAllocationManagementContent />;
      case "move-management":
        return <NewMoveManagementContent onNavigate={onNavigate} />;
      case "space-resource-management":
        return <SpaceResourceManagementOverviewContent />;
      case "workplace-management":
        return <WorkplaceManagementContent />;
      case "inventory-management":
        return <InventoryManagementContent />;
      case "space-statistics":
        return <SpaceStatisticsContent />;
      case "supply-demand-management":
        return <NewSupplyDemandManagementContent />;
      case "facility-management":
        return <FacilityManagementContent />;
      case "building-file-management":
        return <BuildingFileManagementContent />;
      case "building-personnel-management":
        return <BuildingPersonnelManagementContent />;
      case "building-supplier-management":
        return <BuildingSupplierManagementContent />;
      case "building-operation-info":
        return <BuildingOperationInfoContent />;
      case "permission-management":
        return <PermissionManagementContent />;
      case "operation-log":
        return <OperationLogContent />;
      case "interface-config":
        return <InterfaceConfigContent />;
      case "product-details":
        return <ProductDetailsContent productId={productId} onNavigateBack={() => onNavigate?.("pricing-management")} />;
      case "space-sku-management":
        return <SpaceSKUManagementContent onNavigate={onNavigate} />;
      case "pricing-product-edit":
        return <PricingProductEditContent onNavigate={onNavigate} productId={productId} />;
      default:
        return <DefaultContent itemId={activeItem} />;
    }
  };

  return (
    <div className="flex-1 min-h-screen bg-secondary/10 flex justify-center">
      <div className="w-[1300px] max-w-full">
        <div className="p-4">
          <div className="flex items-center justify-between mb-4">
            <Breadcrumb className="flex-1">
              <BreadcrumbList>
                {breadcrumbs.map((breadcrumb, index) => (
                  <div key={index} className="flex items-center">
                    {index > 0 && <BreadcrumbSeparator />}
                    <BreadcrumbItem>
                      {index === breadcrumbs.length - 1 ? (
                        <BreadcrumbPage className="text-xs">{breadcrumb.label}</BreadcrumbPage>
                      ) : breadcrumb.clickable ? (
                        <BreadcrumbLink 
                          href={breadcrumb.href}
                          className="cursor-pointer hover:text-primary text-xs"
                        >
                          {breadcrumb.label}
                        </BreadcrumbLink>
                      ) : (
                        <span className="text-muted-foreground text-xs">{breadcrumb.label}</span>
                      )}
                    </BreadcrumbItem>
                  </div>
                ))}
              </BreadcrumbList>
            </Breadcrumb>
            <Button 
              variant="outline" 
              size="sm" 
              className="ml-4 h-7 text-xs"
              onClick={() => window.open('https://bytedance.feishu.cn/docx/doxcnHkZGVjGXYzYJqQDVQeL6Qb', '_blank')}
            >
              <FileText className="h-3 w-3 mr-1" />
              说明文档
            </Button>
          </div>
          {getPageContent()}
        </div>
      </div>
    </div>
  );
}