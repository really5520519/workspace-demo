import { useState } from "react";
import {
  Building2,
  Users,
  User,
  BarChart3,
  DollarSign,
  Calculator,
  CreditCard,
  FolderOpen,
  ClipboardList,
  Home,
  MoveRight,
  Wrench,
  MapPin,
  Package,
  Workflow,
  Shield,
  ScrollText,
  FileText,
  UserCheck,
  ChevronDown,
  ChevronRight,
  Network,
  Share2,
  Truck,
  Tag,
  PanelLeftClose,
  PanelLeftOpen,
  MessageCircle,
  Smartphone,
  Car,
  Archive,
  Search,
  Settings,
  TreePine,
  Layers,
  Palette,
  Database,
  Eye,
  BookOpen,
  Receipt,
  BarChart,
  BarChart2,
  LayoutGrid,
  Grid2x2
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent,
  SidebarFooter,
} from "./ui/sidebar";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "./ui/collapsible";
import { Button } from "./ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "./ui/tooltip";

interface MenuItem {
  id: string;
  label: string;
  icon?: any;
  children?: MenuItem[];
}

const menuStructure: MenuItem[] = [
  {
    id: "user-side",
    label: "用户端",
    icon: Users,
    children: [
      {
        id: "employee-side",
        label: "员工侧",
        icon: User,
        children: [
          { id: "space-service", label: "空间服务", icon: Building2 },
          { id: "seat-binding", label: "工位绑定", icon: MapPin },
          { id: "move-plan", label: "搬家计划", icon: Truck }
        ]
      },
      {
        id: "department-side",
        label: "部门侧",
        icon: Network,
        children: [
          { id: "space-resource-service", label: "空间资源与服务", icon: Building2 },
          { id: "space-usage", label: "空间资源使用", icon: BarChart3 },
          { id: "space-billing", label: "空间费用账单", icon: CreditCard }
        ]
      }
    ]
  },
  {
    id: "admin-side",
    label: "管理端",
    icon: LayoutGrid,
    children: [
      {
        id: "business-management",
        label: "经营管理",
        icon: BarChart3,
        children: [
          { id: "business-analysis", label: "经营分析", icon: BarChart3 },
          { id: "budget-management", label: "预算管理", icon: Calculator },
          { id: "cost-management", label: "成本管理", icon: DollarSign },
          { id: "pricing-management", label: "定价管理", icon: Tag },
          { id: "billing-management", label: "业务计费", icon: CreditCard }
        ]
      },
      {
        id: "operation-management",
        label: "运营管理",
        icon: FolderOpen,
        children: [
          { id: "project-management", label: "项目管理", icon: FolderOpen },
          { id: "demand-management", label: "需求管理", icon: ClipboardList },
          { id: "lease-management", label: "租赁管理", icon: Home },
          { id: "construction-management", label: "项目施工管理", icon: Wrench },
          { id: "allocation-management", label: "空间分配", icon: MapPin },
          { id: "move-management", label: "搬家管理", icon: Truck }
        ]
      },
      {
        id: "space-resource-management",
        label: "空间资源管理",
        icon: Building2,
        children: [
          { id: "workplace-management", label: "工区管理", icon: Building2 },
          { id: "inventory-management", label: "库存管理", icon: Package },
          { id: "supply-demand-management", label: "供需管理", icon: BarChart3 },
          { id: "facility-management", label: "设施设备管理", icon: Settings },
          { id: "building-file-management", label: "楼宇文件管理", icon: FileText },
          { id: "building-personnel-management", label: "楼宇人员管理", icon: UserCheck },
          { id: "building-supplier-management", label: "楼宇供应商管理", icon: Users },
          { id: "building-operation-info", label: "楼宇运营信息", icon: Database }
        ]
      },
      {
        id: "system-management",
        label: "系统管理",
        icon: Settings,
        children: [
          { id: "permission-management", label: "权限管理", icon: Shield },
          { id: "operation-log", label: "操作记录", icon: ScrollText }
        ]
      },
      {
        id: "integration-config",
        label: "上下游配置",
        icon: Layers,
        children: [
          { id: "interface-config", label: "接口", icon: Layers }
        ]
      }
    ]
  }
];

interface MenuItemComponentProps {
  item: MenuItem;
  level: number;
  activeItem: string;
  onItemClick: (id: string) => void;
  isCollapsed: boolean;
}

function MenuItemComponent({ item, level, activeItem, onItemClick, isCollapsed }: MenuItemComponentProps) {
  const [isOpen, setIsOpen] = useState(true);
  const hasChildren = item.children && item.children.length > 0;
  const Icon = item.icon;

  // 在收缩状态下，只显示一级菜单
  if (isCollapsed && level > 0) {
    return null;
  }

  // 计算缩进
  const getIndentClass = () => {
    if (isCollapsed) return "";
    switch (level) {
      case 0: return "";
      case 1: return "pl-4";
      case 2: return "pl-8";
      default: return `pl-${(level + 1) * 3}`;
    }
  };

  if (hasChildren) {
    // 在收缩状态下，一级菜单变成可点击的按钮
    if (isCollapsed && level === 0) {
      return (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <SidebarMenuButton
                className="w-full justify-center p-2"
                onClick={() => {
                  // 如果一级菜单有子项，可以点击第一个可点击的子项
                  const findFirstClickableItem = (menuItem: MenuItem): string | null => {
                    if (!menuItem.children) return menuItem.id;
                    for (const child of menuItem.children) {
                      const result = findFirstClickableItem(child);
                      if (result) return result;
                    }
                    return null;
                  };
                  const firstClickableId = findFirstClickableItem(item);
                  if (firstClickableId) {
                    onItemClick(firstClickableId);
                  }
                }}
              >
                {Icon && <Icon className="h-5 w-5" />}
              </SidebarMenuButton>
            </TooltipTrigger>
            <TooltipContent side="right" className="font-medium">
              {item.label}
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      );
    }

    return (
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CollapsibleTrigger asChild>
          <SidebarMenuButton
            className={`w-full justify-between ${getIndentClass()}`}
          >
            <div className="flex items-center gap-2 min-w-0">
              {Icon && level !== 2 && <Icon className="h-4 w-4 flex-shrink-0" />}
              {!isCollapsed && <span className="truncate text-sm">{item.label}</span>}
            </div>
            {!isCollapsed && (
              isOpen ? (
                <ChevronDown className="h-4 w-4 flex-shrink-0" />
              ) : (
                <ChevronRight className="h-4 w-4 flex-shrink-0" />
              )
            )}
          </SidebarMenuButton>
        </CollapsibleTrigger>
        {!isCollapsed && (
          <CollapsibleContent>
            <SidebarMenu>
              {item.children?.map((child) => (
                <SidebarMenuItem key={child.id}>
                  <MenuItemComponent
                    item={child}
                    level={level + 1}
                    activeItem={activeItem}
                    onItemClick={onItemClick}
                    isCollapsed={isCollapsed}
                  />
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </CollapsibleContent>
        )}
      </Collapsible>
    );
  }

  return (
    <SidebarMenuButton
      onClick={() => onItemClick(item.id)}
      isActive={activeItem === item.id}
      className={`w-full ${getIndentClass()}`}
    >
      <div className="flex items-center gap-2 min-w-0">
        {Icon && level !== 2 && <Icon className="h-4 w-4 flex-shrink-0" />}
        {!isCollapsed && <span className="truncate text-sm ml-2">{item.label}</span>}
      </div>
    </SidebarMenuButton>
  );
}

interface AppSidebarProps {
  activeItem: string;
  onItemClick: (id: string) => void;
}

export function AppSidebar({ activeItem, onItemClick }: AppSidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };

  return (
    <Sidebar 
      className={`border-r transition-all duration-300 ${isCollapsed ? 'w-16' : 'w-64'}`}
      collapsible="icon"
    >
      <SidebarHeader className="border-b p-4">
        <div 
          className="flex items-center gap-2 cursor-pointer hover:bg-accent/50 rounded-md px-2 py-1 -mx-2 -my-1 transition-colors"
          onClick={() => onItemClick("system-homepage")}
        >
          <Building2 className="h-6 w-6 text-primary flex-shrink-0" />
          {!isCollapsed && (
            <h2 className="text-sm font-semibold text-primary truncate">
              空间资源管理系统
            </h2>
          )}
        </div>
      </SidebarHeader>
      
      <SidebarContent className="flex-1 overflow-y-auto">
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuStructure.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <MenuItemComponent
                    item={item}
                    level={0}
                    activeItem={activeItem}
                    onItemClick={onItemClick}
                    isCollapsed={isCollapsed}
                  />
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t p-2">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleCollapse}
                className={`w-full ${isCollapsed ? 'justify-center p-2' : 'justify-between'}`}
              >
                {isCollapsed ? (
                  <PanelLeftOpen className="h-4 w-4" />
                ) : (
                  <>
                    <PanelLeftClose className="h-4 w-4" />
                    <span className="text-sm">收缩</span>
                  </>
                )}
              </Button>
            </TooltipTrigger>
            <TooltipContent side="right" className="font-medium">
              {isCollapsed ? "展开菜单" : "收缩菜单"}
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </SidebarFooter>
    </Sidebar>
  );
}