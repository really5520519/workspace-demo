import { useState } from "react";
import { Bell, Search, Settings, User, Moon, Sun, ChevronDown, Globe, Clock, CheckSquare, LogOut, Check, HelpCircle, MessageCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
} from "./ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";

interface TopBarProps {
  onThemeToggle: () => void;
  isDark: boolean;
}

export function TopBar({ onThemeToggle, isDark }: TopBarProps) {
  const [selectedLanguage, setSelectedLanguage] = useState("简体中文");

  return (
    <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="flex h-12 items-center px-4 gap-4">
        {/* 搜索框 */}
        <div className="flex-1 max-w-md">
          <div className="relative">
            <Search className="absolute left-2 top-2 h-3 w-3 text-muted-foreground" />
            <Input
              placeholder="搜索功能、项目..."
              className="pl-7 h-8 text-xs"
            />
          </div>
        </div>

        {/* 右侧操作区 */}
        <div className="flex items-center gap-1 ml-auto">
          {/* 智能客服 */}
          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
            <MessageCircle className="h-3 w-3" />
          </Button>

          {/* 通知 */}
          <Button variant="ghost" size="sm" className="relative h-8 w-8 p-0">
            <Bell className="h-3 w-3" />
            <Badge 
              variant="destructive" 
              className="absolute -top-1 -right-1 h-4 w-4 text-xs flex items-center justify-center p-0"
            >
              3
            </Badge>
          </Button>

          {/* 用户菜单 */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center gap-2 h-8 px-2 rounded-lg hover:bg-accent">
                <Avatar className="h-6 w-6 rounded-full">
                  <AvatarImage src="/avatars/01.png" alt="@johnsmith" />
                  <AvatarFallback className="rounded-full text-xs">
                    <User className="h-3 w-3" />
                  </AvatarFallback>
                </Avatar>
                <span className="text-xs font-medium">John Smith</span>
                <ChevronDown className="h-3 w-3 text-muted-foreground" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end" forceMount>
              {/* 用户信息区域 */}
              <DropdownMenuLabel className="font-normal p-3">
                <div className="flex items-center gap-2">
                  <Avatar className="h-8 w-8 rounded-full">
                    <AvatarImage src="/avatars/01.png" alt="@johnsmith" />
                    <AvatarFallback className="rounded-full text-xs">
                      <User className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col space-y-1">
                    <p className="text-xs font-medium leading-none">John Smith</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      john.smith@company.com
                    </p>
                  </div>
                </div>
              </DropdownMenuLabel>
              
              <DropdownMenuSeparator />
              
              {/* 我的任务 */}
              <DropdownMenuItem className="p-2">
                <CheckSquare className="mr-2 h-3 w-3" />
                <span className="text-xs">我的任务</span>
              </DropdownMenuItem>
              
              <DropdownMenuSeparator />
              
              {/* 语言设置 */}
              <DropdownMenuSub>
                <DropdownMenuSubTrigger className="p-2">
                  <Globe className="mr-2 h-3 w-3" />
                  <span className="text-xs">语言</span>
                </DropdownMenuSubTrigger>
                <DropdownMenuSubContent className="w-40">
                  <DropdownMenuItem 
                    className="p-2 justify-between"
                    onClick={() => setSelectedLanguage("简体中文")}
                  >
                    <span className="text-xs">简体中文</span>
                    {selectedLanguage === "简体中文" && (
                      <Check className="h-3 w-3" />
                    )}
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    className="p-2 justify-between"
                    onClick={() => setSelectedLanguage("English")}
                  >
                    <span className="text-xs">English</span>
                    {selectedLanguage === "English" && (
                      <Check className="h-3 w-3" />
                    )}
                  </DropdownMenuItem>
                </DropdownMenuSubContent>
              </DropdownMenuSub>
              
              {/* 时区设置 */}
              <DropdownMenuItem className="p-2">
                <Clock className="mr-2 h-3 w-3" />
                <span className="text-xs">时区</span>
              </DropdownMenuItem>
              
              <DropdownMenuSeparator />
              
              {/* 退出登录 */}
              <DropdownMenuItem className="p-2 text-center justify-center text-muted-foreground">
                <LogOut className="mr-2 h-3 w-3" />
                <span className="text-xs">退出登录</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}