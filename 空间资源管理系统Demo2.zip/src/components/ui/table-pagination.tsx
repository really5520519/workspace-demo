import { useState } from "react";
import { Button } from "./button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./select";
import { Input } from "./input";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface TablePaginationProps {
  total: number;
  currentPage: number;
  pageSize: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
}

export function TablePagination({
  total,
  currentPage,
  pageSize,
  onPageChange,
  onPageSizeChange
}: TablePaginationProps) {
  const [jumpPage, setJumpPage] = useState("");
  const totalPages = Math.ceil(total / pageSize);

  const handleJumpToPage = () => {
    const page = parseInt(jumpPage);
    if (page >= 1 && page <= totalPages) {
      onPageChange(page);
      setJumpPage("");
    }
  };

  const getVisiblePages = () => {
    const pages = [];
    const showEllipsisStart = currentPage > 4;
    const showEllipsisEnd = currentPage < totalPages - 3;

    if (totalPages <= 7) {
      // 如果总页数小于等于7，显示所有页码
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      // 总是显示第1页
      pages.push(1);

      if (showEllipsisStart) {
        pages.push("...");
      }

      // 显示当前页周围的页码
      let start = Math.max(2, currentPage - 1);
      let end = Math.min(totalPages - 1, currentPage + 1);

      if (currentPage <= 3) {
        end = 5;
      }
      if (currentPage >= totalPages - 2) {
        start = totalPages - 4;
      }

      for (let i = start; i <= end; i++) {
        if (i > 1 && i < totalPages) {
          pages.push(i);
        }
      }

      if (showEllipsisEnd) {
        pages.push("...");
      }

      // 总是显示最后一页
      if (totalPages > 1) {
        pages.push(totalPages);
      }
    }

    return pages;
  };

  return (
    <div className="flex items-center justify-end mt-4 text-sm">
      <div className="flex items-center gap-2">
        {/* 总条数 */}
        <div className="text-muted-foreground">
          共 {total} 条
        </div>

        {/* 上一页按钮 */}
        <Button
          variant="outline"
          size="sm"
          className="h-8 w-8 p-0"
          onClick={() => onPageChange(Math.max(1, currentPage - 1))}
          disabled={currentPage === 1}
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>

        {/* 页码按钮 */}
        {getVisiblePages().map((page, index) => (
          <Button
            key={index}
            variant={page === currentPage ? "default" : "outline"}
            size="sm"
            className={`h-8 min-w-8 px-2 ${
              page === currentPage 
                ? "bg-blue-600 text-white hover:bg-blue-700" 
                : page === "..." 
                  ? "cursor-default hover:bg-transparent border-none" 
                  : ""
            }`}
            onClick={() => typeof page === "number" ? onPageChange(page) : undefined}
            disabled={page === "..."}
          >
            {page}
          </Button>
        ))}

        {/* 下一页按钮 */}
        <Button
          variant="outline"
          size="sm"
          className="h-8 w-8 p-0"
          onClick={() => onPageChange(Math.min(totalPages, currentPage + 1))}
          disabled={currentPage === totalPages}
        >
          <ChevronRight className="h-4 w-4" />
        </Button>

        {/* 每页条数选择 */}
        <Select value={pageSize.toString()} onValueChange={(value) => onPageSizeChange(parseInt(value))}>
          <SelectTrigger className="h-8 w-20 text-sm">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="10">10</SelectItem>
            <SelectItem value="20">20</SelectItem>
            <SelectItem value="50">50</SelectItem>
            <SelectItem value="100">100</SelectItem>
          </SelectContent>
        </Select>
        <span className="text-muted-foreground text-sm">条/页</span>

        {/* 跳转到指定页 */}
        <span className="text-muted-foreground text-sm">跳至</span>
        <Input
          type="number"
          min="1"
          max={totalPages}
          value={jumpPage}
          onChange={(e) => setJumpPage(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleJumpToPage()}
          className="h-8 w-16 text-sm text-center"
          placeholder="1"
        />
        <span className="text-muted-foreground text-sm">页</span>
      </div>
    </div>
  );
}