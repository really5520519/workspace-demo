import { useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../ui/card";
import { Button } from "../ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import { Badge } from "../ui/badge";
import { MapPin } from "lucide-react";
import { TablePagination } from "../ui/table-pagination";

export function SeatBindingContent() {
  const [currentSeat, setCurrentSeat] = useState({
    location: "总裁科技园开发中心 - A座 16F A区",
    seatNumber: "101",
    occupancyTime: "2024-01-16 09:30:00"
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const totalItems = 42; // 模拟总条数

  const historyData = [
    {
      id: "1",
      seatNumber: "A-94-02-40-B-007",
      location: "上海市黄浦区淮海",
      configuration: "A座一32F-06-C40", 
      type: "固定工位",
      systemTime: "2022-10-01 10:00:00",
      unbindTime: "2023-05-31 18:00:00",
      bindingDays: "244",
      status: "绑定中",
      workZone: "A区开发工区"
    },
    {
      id: "2", 
      seatNumber: "A-94-02-40-B-007",
      location: "上海市黄浦区淮海",
      configuration: "A座一32F-06-C40",
      type: "固定工位", 
      systemTime: "2022-10-06 14:00:00",
      unbindTime: "2023-05-31 18:00:00",
      bindingDays: "302",
      status: "已解绑",
      workZone: "B区运营工区"
    }
  ];

  const handleUnbind = () => {
    // 模拟解除绑定操作
    alert("解除绑定操作需要确认，请联系管理员");
  };

  return (
    <div className="space-y-4">
      {/* 页面标题 */}
      <div>
        <h1 className="text-lg font-medium">工位绑定</h1>
      </div>

      {/* 工位信息 */}
      <div className="p-4 bg-blue-50 rounded-lg">
        <div className="flex items-center gap-3">
          {/* 左侧图标 */}
          <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <MapPin className="h-8 w-8 text-blue-600" />
          </div>
          
          {/* 右侧内容 */}
          <div className="flex-1 min-w-0">
            {/* 标题和时间 */}
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-medium text-gray-900">工位位置</h3>
                <span className="text-blue-600 font-medium" style={{ fontSize: '12px' }}>已绑定200天</span>
              </div>
              <span className="text-xs text-gray-500">绑定时间：2023-12-30 14:22:43</span>
            </div>
            
            {/* 位置信息和工位编号 */}
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium text-gray-900">北京市-时尚方科-A座-3F-092</span>
              <span className="text-sm font-medium text-gray-900">CNBJWKSF4092</span>
            </div>
            
            {/* 底部状态栏 */}
            <div className="flex items-center justify-between">
              <span className="text-xs text-gray-700">固定工位</span>
              <Button 
                size="sm" 
                className="h-7 text-xs bg-blue-600 hover:bg-blue-700 text-white"
                onClick={handleUnbind}
              >
                修改绑定
              </Button>
            </div>
          </div>
        </div>
      </div>



      {/* 工位变更历史 */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium">
            工位变更历史
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="text-sm">工位编号</TableHead>
                  <TableHead className="text-sm">状态</TableHead>
                  <TableHead className="text-sm">工区名称</TableHead>
                  <TableHead className="text-sm">位置</TableHead>
                  <TableHead className="text-sm">工位配置编号</TableHead>
                  <TableHead className="text-sm">工位类型</TableHead>
                  <TableHead className="text-sm">绑定时间</TableHead>
                  <TableHead className="text-sm">解除绑定时间</TableHead>
                  <TableHead className="text-sm">绑定天数</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {historyData.map((record) => (
                  <TableRow key={record.id}>
                    <TableCell className="text-sm font-medium">
                      {record.seatNumber}
                    </TableCell>
                    <TableCell className="text-sm">
                      <Badge 
                        variant="secondary" 
                        className={`text-xs ${
                          record.status === "绑定中" 
                            ? "bg-green-100 text-green-800" 
                            : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {record.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm">
                      {record.workZone}
                    </TableCell>
                    <TableCell className="text-sm">
                      {record.location}
                    </TableCell>
                    <TableCell className="text-sm">
                      {record.configuration}
                    </TableCell>
                    <TableCell className="text-sm">
                      {record.type}
                    </TableCell>
                    <TableCell className="text-sm">
                      {record.systemTime}
                    </TableCell>
                    <TableCell className="text-sm">
                      {record.unbindTime}
                    </TableCell>
                    <TableCell className="text-sm">
                      {record.bindingDays}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            
            {historyData.length === 0 && (
              <div className="text-center py-8 text-muted-foreground text-sm">
                暂无工位变更历史
              </div>
            )}
          </div>

          <TablePagination
            total={totalItems}
            currentPage={currentPage}
            pageSize={pageSize}
            onPageChange={setCurrentPage}
            onPageSizeChange={setPageSize}
          />
        </CardContent>
      </Card>
    </div>
  );
}