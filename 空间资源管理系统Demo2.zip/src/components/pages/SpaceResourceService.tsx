import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { TablePagination } from "../ui/table-pagination";

import { FileText, Plus } from "lucide-react";

interface SpaceResourceServiceProps {
  onNavigate?: (page: string) => void;
}

export function SpaceResourceServiceContent({ onNavigate }: SpaceResourceServiceProps) {
  const [activeTab, setActiveTab] = useState("daily-application");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const totalItems = 25; // 模拟总条数

  // 统计数据
  const statistics = [
    {
      title: "工位",
      items: [
        { label: "总需求", value: "100" },
        { label: "已申请", value: "70" },
        { label: "已分配", value: "50" }
      ]
    },
    {
      title: "空间",
      items: [
        { label: "总需求", value: "5" },
        { label: "已申请", value: "3" },
        { label: "已分配", value: "2" }
      ]
    },
    {
      title: "其他服务",
      items: [
        { label: "注册地", value: "2" },
        { label: "已占用", value: "45天" }
      ]
    }
  ];

  // 日常申请记录数据
  const applicationRecords = [
    {
      id: "BUD-2024-001",
      status: "已生效",
      statusColor: "bg-green-100 text-green-800",
      location: "北京-总部-A栋-3层",
      hcCount: "50",
      workstationCount: "50",
      independentSpaceCount: "2",
      department: "研发部",
      submitter: "张三",
      submitTime: "2023-12-01",
      action: "查看"
    },
    {
      id: "BUD-2024-002",
      status: "审核中",
      statusColor: "bg-yellow-100 text-yellow-800",
      location: "上海-分部-B栋-5层",
      hcCount: "20",
      workstationCount: "20",
      independentSpaceCount: "1",
      department: "市场部",
      submitter: "李四",
      submitTime: "2024-01-10",
      action: "查看"
    }
  ];

  // 预算申请记录数据
  const budgetRecords = [
    {
      id: "BGT-2024-001",
      status: "已批准",
      statusColor: "bg-green-100 text-green-800",
      budgetPeriod: "2024Q1",
      hcCount: "30",
      outsourceCount: "5",
      resourceType: "工位",
      quantity: "35",
      area: "350㎡",
      location: "北京-总部-A栋",
      billingDepartment: "技术部",
      submitter: "王五",
      submitTime: "2024-01-15",
      action: "查看"
    },
    {
      id: "BGT-2024-002",
      status: "申请中",
      statusColor: "bg-blue-100 text-blue-800",
      budgetPeriod: "2024Q2",
      hcCount: "15",
      outsourceCount: "3",
      resourceType: "独立办公室",
      quantity: "2",
      area: "120㎡",
      location: "上海-分部-B栋",
      billingDepartment: "产品部",
      submitter: "赵六",
      submitTime: "2024-02-20",
      action: "查看"
    },
    {
      id: "BGT-2024-003",
      status: "已驳回",
      statusColor: "bg-red-100 text-red-800",
      budgetPeriod: "2024Q1",
      hcCount: "25",
      outsourceCount: "8",
      resourceType: "会议室",
      quantity: "3",
      area: "180㎡",
      location: "深圳-研发中心-C栋",
      billingDepartment: "销售部",
      submitter: "孙七",
      submitTime: "2024-01-28",
      action: "查看"
    }
  ];

  return (
    <div className="space-y-4">
      {/* 页面标题 */}
      <div>
        <h1 className="text-lg font-medium">空间资源与服务</h1>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-3 gap-4">
        {statistics.map((stat, index) => (
          <Card key={index} className="bg-white border border-gray-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-900">{stat.title}</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-2">
                {stat.items.map((item, itemIndex) => (
                  <div key={itemIndex} className="flex justify-between items-center">
                    <span className="text-xs text-muted-foreground">{item.label}:</span>
                    <span className="text-xs font-medium text-blue-600">{item.value}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 申请记录 */}
      <Card className="bg-white border border-gray-200">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-medium text-gray-900 text-[12px]">申请记录</CardTitle>
            <div className="flex gap-2">
              <Button 
                size="sm" 
                className="h-7 text-xs bg-blue-600 text-white hover:bg-blue-700"
                onClick={() => onNavigate?.('requirement-application')}
              >
                <Plus className="h-3 w-3 mr-1" />
                需求申请
              </Button>
              <Button size="sm" className="h-7 text-xs bg-blue-600 text-white hover:bg-blue-700">
                <Plus className="h-3 w-3 mr-1" />
                预算申请
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent className="pt-0 mt-[-21px] mr-[0px] mb-[0px] ml-[0px]">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-fit grid-cols-2 mb-4">
              <TabsTrigger value="daily-application" className="text-xs">工位申请</TabsTrigger>
              <TabsTrigger value="budget-outside" className="text-xs">空间申请</TabsTrigger>
            </TabsList>

            {/* 日常申请Tab */}
            <TabsContent value="daily-application" className="mt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10">申请编号</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">城市-职场-楼宇-楼层</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">HC人数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">工位需求数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">独立空间数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">部门</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">提交人</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">提交时间</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {applicationRecords.map((record) => (
                      <TableRow key={record.id} className="hover:bg-gray-50">
                        <TableCell className="text-xs text-blue-600 font-medium">
                          {record.id}
                        </TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`${record.statusColor} text-xs px-2 py-1 font-normal`}
                          >
                            {record.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{record.location}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.hcCount}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.workstationCount}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.independentSpaceCount}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.department}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.submitter}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.submitTime}</TableCell>
                        <TableCell className="text-xs">
                          <Button 
                            variant="link" 
                            size="sm" 
                            className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                          >
                            {record.action}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <TablePagination
                total={totalItems}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </TabsContent>

            {/* 预算申请记录Tab */}
            <TabsContent value="budget-outside" className="mt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10">申请编号</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">预算期间</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">HC人数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">编外人数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">资源类型</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">数量</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">面积</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">位置</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">预算部门</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">提交人</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">提交时间</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {budgetRecords.map((record) => (
                      <TableRow key={record.id} className="hover:bg-gray-50">
                        <TableCell className="text-xs text-blue-600 font-medium">
                          {record.id}
                        </TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`${record.statusColor} text-xs px-2 py-1 font-normal`}
                          >
                            {record.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{record.budgetPeriod}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.hcCount}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.outsourceCount}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.resourceType}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.quantity}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.area}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.location}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.billingDepartment}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.submitter}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.submitTime}</TableCell>
                        <TableCell className="text-xs">
                          <Button 
                            variant="link" 
                            size="sm" 
                            className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                          >
                            {record.action}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <TablePagination
                total={totalItems}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}