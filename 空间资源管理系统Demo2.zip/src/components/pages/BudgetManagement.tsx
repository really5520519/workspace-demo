import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../ui/dialog";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "../ui/tooltip";

import { FileText, Info, Eye, BarChart2 } from "lucide-react";

export function BudgetManagementContent() {
  const [activeTab, setActiveTab] = useState("revenue");
  const [selectedBudget, setSelectedBudget] = useState<any>(null);
  const [showBudgetDetails, setShowBudgetDetails] = useState(false);

  // 收入预算项目数据
  const revenueBudgetItems = [
    {
      id: "REV-2024-07",
      project: "REV-2024-07",
      budgetStatus: "申请中",
      budgetTitle: "北京办公室Q3工位收入预算",
      budgetDescription: "针对北京总部办公区域第三季度工位租赁收入的预算规划，包含固定工位、灵活工位及会议室的收入预测。预期新增工位200个，平均单价3500元/月，预计季度总收入达到250万元。",
      detailedDescription: "本预算项目涵盖北京办公室Q3季度的所有工位收入来源：\n\n1. 固定工位收入：150个固定工位，单价4000元/月\n2. 灵活工位收入：50个灵活工位，单价3000元/月\n3. 会议室收入：10间会议室，平均500元/小时\n4. 临时办公收入：日租工位，200元/天\n\n预算基于历史数据和市场调研，考虑了季节性因素和市场竞争情况。",
      city: "2024-07",
      status: "申请中",
      totalBudget: "¥2,500,000",
      budgeted: "¥2,200,000",
      allocated: "¥1,800,000",
      balance: "¥400,000",
      action: "查看",
      applicant: "张明",
      department: "北京运营中心",
      applyDate: "2024-07-01",
      approver: "李总",
      category: "工位收入"
    },
    {
      id: "REV-2024-06", 
      project: "REV-2024-06",
      budgetStatus: "已审批",
      budgetTitle: "上海分部空间服务收入预算",
      budgetDescription: "上海分部空间增值服务收入预算，包括茶水间服务、健身房使用费、停车位租赁等附加服务的收入预测。",
      detailedDescription: "上海分部空间增值服务收入包括：\n\n1. 茶水间服务：咖啡、茶饮等，月均收入8万元\n2. 健身房使用费：员工健身服务，月均收入3万元\n3. 停车位租赁：地下停车场，80个车位，月均收入4万元\n4. 其他增值服务：打印复印、快递代收等\n\n该预算已通过财务部门审核，执行状态良好。",
      city: "2024-06",
      status: "申请中",
      totalBudget: "¥1,800,000",
      budgeted: "¥1,500,000",
      allocated: "¥1,200,000",
      balance: "¥300,000",
      action: "查看",
      applicant: "王芳",
      department: "上海运营中心",
      applyDate: "2024-06-15",
      approver: "陈总",
      category: "增值服务"
    },
    {
      id: "REV-2024-07-US",
      project: "REV-2024-07-US", 
      budgetStatus: "待审批",
      budgetTitle: "纽约办公室运营收入预算",
      budgetDescription: "纽约办公室整体运营收入预算，包括工位租赁、会议室预约、活动场地租赁等综合收入预测。",
      detailedDescription: "纽约办公室运营收入预算详情：\n\n1. 工位租赁收入：100个工位，平均$800/月\n2. 会议室预约：8间会议室，$50/小时\n3. 活动场地租赁：大型活动空间，$200/小时\n4. 国际客户服务费：跨境办公服务\n\n该预算需要总部最终审批，预计审批周期5-7个工作日。",
      city: "2024-07",
      status: "申请中",
      totalBudget: "$180,000",
      budgeted: "$150,000",
      allocated: "$120,000",
      balance: "$30,000",
      action: "查看",
      applicant: "John Smith",
      department: "New York Operations",
      applyDate: "2024-07-10",
      approver: "CEO",
      category: "综合收入"
    }
  ];

  // 成本预算项目数据
  const costBudgetItems = [
    {
      id: "COST-2024-07",
      project: "COST-2024-07",
      budgetStatus: "申请中",
      budgetTitle: "北京办公室Q3装修成本预算",
      budgetDescription: "北京办公室第三季度装修改造项目成本预算，包括办公区域重新设计、会议室升级、公共区域改造等装修工程的成本估算。",
      detailedDescription: "北京办公室Q3装修项目详细成本分解：\n\n1. 办公区域装修：60万元\n   - 地面铺装：15万元\n   - 墙面装修：20万元\n   - 天花板工程：25万元\n\n2. 会议室升级：30万元\n   - 智能设备安装：15万元\n   - 家具更换：15万元\n\n3. 公共区域改造：25万元\n4. 设计费用：5万元\n5. 监理费用：3万元\n6. 应急预算：7万元",
      city: "2024-07",
      status: "申请中",
      totalBudget: "¥1,200,000",
      budgeted: "¥1,000,000",
      allocated: "¥800,000",
      balance: "¥200,000",
      action: "查看",
      applicant: "刘工",
      department: "设施管理部",
      applyDate: "2024-07-05",
      approver: "运营总监",
      category: "装修成本"
    },
    {
      id: "COST-2024-06", 
      project: "COST-2024-06",
      budgetStatus: "已审批",
      budgetTitle: "上海分部运营成本预算",
      budgetDescription: "上海分部日常运营成本预算，包括物业费、水电费、清洁费、安保费等运营维护成本的月度预算规划。",
      detailedDescription: "上海分部运营成本明细：\n\n1. 物业管理费：30万元/季度\n2. 水电费：15万元/季度\n3. 清洁服务费：8万元/季度\n4. 安保服务费：12万元/季度\n5. 绿植维护费：3万元/季度\n6. 设备维修费：5万元/季度\n7. 其他杂费：7万元/季度\n\n该预算已获得审批，按月执行。",
      city: "2024-06",
      status: "申请中",
      totalBudget: "¥800,000",
      budgeted: "¥700,000",
      allocated: "¥600,000",
      balance: "¥100,000",
      action: "查看",
      applicant: "赵管家",
      department: "运营管理部",
      applyDate: "2024-06-01",
      approver: "财务总监",
      category: "运营成本"
    },
    {
      id: "COST-2024-07-US",
      project: "COST-2024-07-US", 
      budgetStatus: "待审批",
      budgetTitle: "纽约办公室基础设施成本预算",
      budgetDescription: "纽约办公室基础设施升级和维护成本预算，包括网络设备更新、空调系统维护、电梯保养等基础设施投入。",
      detailedDescription: "纽约办公室基础设施成本预算：\n\n1. Network Infrastructure: $35,000\n   - Router/Switch upgrade: $20,000\n   - Cable installation: $15,000\n\n2. HVAC System Maintenance: $25,000\n3. Elevator Maintenance: $15,000\n4. Security System Upgrade: $10,000\n\n该预算正在等待总部财务委员会审批。",
      city: "2024-07",
      status: "申请中",
      totalBudget: "$85,000",
      budgeted: "$70,000",
      allocated: "$55,000",
      balance: "$15,000",
      action: "查看",
      applicant: "Mike Johnson",
      department: "Facilities Management",
      applyDate: "2024-07-08",
      approver: "CFO",
      category: "基础设施"
    }
  ];

  // 收入预算指标数据
  const revenueBudgetMetrics = [
    {
      title: "总收入预算",
      amount: "¥8,500,000",
      progress: 85,
      progressColor: "bg-blue-500"
    },
    {
      title: "工位收入预算", 
      amount: "¥4,800,000",
      progress: 88,
      progressColor: "bg-blue-500"
    },
    {
      title: "空间收入预算",
      amount: "¥2,200,000", 
      progress: 75,
      progressColor: "bg-blue-500"
    },
    {
      title: "服务收入预算",
      amount: "¥1,500,000",
      progress: 72,
      progressColor: "bg-blue-500"
    }
  ];

  // 成本预算指标数据
  const costBudgetMetrics = [
    {
      title: "总成本预算",
      amount: "¥4,250,000",
      progress: 85,
      progressColor: "bg-orange-500"
    },
    {
      title: "运营成本预算", 
      amount: "¥1,800,000",
      progress: 60,
      progressColor: "bg-orange-500"
    },
    {
      title: "装修成本预算",
      amount: "¥1,100,000", 
      progress: 75,
      progressColor: "bg-orange-500"
    },
    {
      title: "设备成本预算",
      amount: "¥1,350,000",
      progress: 45,
      progressColor: "bg-orange-500"
    }
  ];

  return (
    <div className="space-y-6 max-w-[1300px] mx-auto p-[0px]">
      {/* 页面标题和说明文档按钮 */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h1 className="text-lg font-medium">预算管理</h1>
          <Button 
            variant="outline" 
            size="sm" 
            className="h-7 text-xs bg-white border-blue-500 text-blue-600 hover:bg-blue-50 hover:border-blue-600"
          >
            <BarChart2 className="h-3 w-3 mr-1" />
            预算统计
          </Button>
        </div>
      </div>

      {/* 预算管理标签页 */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="inline-flex mb-6">
          <TabsTrigger value="revenue" className="text-xs">收入预算</TabsTrigger>
          <TabsTrigger value="cost" className="text-xs">成本预算</TabsTrigger>
        </TabsList>

        {/* 收入预算标签页 */}
        <TabsContent value="revenue" className="space-y-6">
          {/* 收入预算概览区域 */}
          <div className="grid grid-cols-12 gap-6">
            {/* ��侧环形图 */}
            <div className="col-span-3">
              <Card className="bg-white border border-gray-200 h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center h-full">
                  <div className="relative w-32 h-32 mb-4">
                    {/* 环形图 SVG */}
                    <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
                      {/* 背景圆环 */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#e5e7eb"
                        strokeWidth="8"
                        fill="none"
                      />
                      {/* 进度圆环 */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#3b82f6"
                        strokeWidth="8"
                        fill="none"
                        strokeDasharray={`${2 * Math.PI * 40 * 0.85} ${2 * Math.PI * 40}`}
                        strokeLinecap="round"
                      />
                    </svg>
                    {/* 中心文字 */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <div className="text-xs text-gray-600">收入预算占用</div>
                      <div className="text-lg font-medium text-gray-900">85%</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                    <span className="text-gray-600">已分配</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* 右侧收入预算指标卡片 */}
            <div className="col-span-9">
              <div className="grid grid-cols-2 gap-4 h-full">
                {revenueBudgetMetrics.map((metric, index) => (
                  <Card key={index} className="bg-white border border-gray-200">
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <div className="text-xs text-gray-600">{metric.title}</div>
                          <div className="text-xs text-gray-500">{metric.progress}%</div>
                        </div>
                        <div className="text-lg font-medium text-gray-900">{metric.amount}</div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${metric.progressColor}`}
                            style={{ width: `${metric.progress}%` }}
                          ></div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          {/* 收入预算详情表格 */}
          <Card className="bg-white border border-gray-200">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-900">收入预算明细</CardTitle>
                <div className="flex items-center gap-2">
                  <Button size="sm" className="h-7 text-xs bg-blue-600 hover:bg-blue-700">
                    新增收入预算
                  </Button>
                  <Button variant="outline" size="sm" className="h-7 text-xs">
                    导出数据
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10">预算项目</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">预算状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">预算标题</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">预算说明</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">城市</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">总预算</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">已预算</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">已分配</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">余额</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {revenueBudgetItems.map((item) => (
                      <TableRow key={item.id} className="hover:bg-gray-50">
                        <TableCell className="text-xs text-gray-900">{item.project}</TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`text-xs border ${
                              item.budgetStatus === "已审批" 
                                ? "bg-blue-50 text-blue-700 border-blue-200" 
                                : item.budgetStatus === "待审批"
                                ? "bg-yellow-50 text-yellow-700 border-yellow-200" 
                                : "bg-gray-100 text-gray-700 border-gray-200"
                            }`}
                          >
                            {item.budgetStatus}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{item.budgetTitle}</TableCell>
                        <TableCell className="text-xs text-gray-900 max-w-xs">
                          <div className="flex items-center gap-2">
                            <div className="truncate flex-1" title={item.budgetDescription}>
                              {item.budgetDescription}
                            </div>
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="h-6 w-6 p-0 hover:bg-blue-50"
                                    onClick={() => {
                                      setSelectedBudget(item);
                                      setShowBudgetDetails(true);
                                    }}
                                  >
                                    <Info className="h-3 w-3 text-blue-600" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p className="text-xs">查看详细说明</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </div>
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{item.city}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.totalBudget}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.budgeted}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.allocated}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.balance}</TableCell>
                        <TableCell className="text-xs">
                          <Button 
                            variant="link" 
                            size="sm" 
                            className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                          >
                            {item.action}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 成本预算标签页 */}
        <TabsContent value="cost" className="space-y-6">
          {/* 成本预算概览区域 */}
          <div className="grid grid-cols-12 gap-6">
            {/* 左侧环形图 */}
            <div className="col-span-3">
              <Card className="bg-white border border-gray-200 h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center h-full">
                  <div className="relative w-32 h-32 mb-4">
                    {/* 环形图 SVG */}
                    <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
                      {/* 背景圆环 */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#e5e7eb"
                        strokeWidth="8"
                        fill="none"
                      />
                      {/* 进度圆环 */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#f97316"
                        strokeWidth="8"
                        fill="none"
                        strokeDasharray={`${2 * Math.PI * 40 * 0.75} ${2 * Math.PI * 40}`}
                        strokeLinecap="round"
                      />
                    </svg>
                    {/* 中心文字 */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <div className="text-xs text-gray-600">成本预算占用</div>
                      <div className="text-lg font-medium text-gray-900">75%</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                    <span className="text-gray-600">已分配</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* 右侧成本预算指标卡片 */}
            <div className="col-span-9">
              <div className="grid grid-cols-2 gap-4 h-full">
                {costBudgetMetrics.map((metric, index) => (
                  <Card key={index} className="bg-white border border-gray-200">
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <div className="text-xs text-gray-600">{metric.title}</div>
                          <div className="text-xs text-gray-500">{metric.progress}%</div>
                        </div>
                        <div className="text-lg font-medium text-gray-900">{metric.amount}</div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${metric.progressColor}`}
                            style={{ width: `${metric.progress}%` }}
                          ></div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          {/* 成本预算详情表格 */}
          <Card className="bg-white border border-gray-200">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-900">成本预算明细</CardTitle>
                <div className="flex items-center gap-2">
                  <Button size="sm" className="h-7 text-xs bg-orange-600 hover:bg-orange-700">
                    新增成本预算
                  </Button>
                  <Button variant="outline" size="sm" className="h-7 text-xs">
                    导出数据
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10">预算项目</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">预算状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">预算标题</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">预算说明</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">城市</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">总预算</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">已预算</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">已分配</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">余额</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {costBudgetItems.map((item) => (
                      <TableRow key={item.id} className="hover:bg-gray-50">
                        <TableCell className="text-xs text-gray-900">{item.project}</TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`text-xs border ${
                              item.budgetStatus === "已审批" 
                                ? "bg-green-50 text-green-700 border-green-200" 
                                : item.budgetStatus === "待审批"
                                ? "bg-yellow-50 text-yellow-700 border-yellow-200" 
                                : "bg-gray-100 text-gray-700 border-gray-200"
                            }`}
                          >
                            {item.budgetStatus}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{item.budgetTitle}</TableCell>
                        <TableCell className="text-xs text-gray-900 max-w-xs">
                          <div className="flex items-center gap-2">
                            <div className="truncate flex-1" title={item.budgetDescription}>
                              {item.budgetDescription}
                            </div>
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="h-6 w-6 p-0 hover:bg-orange-50"
                                    onClick={() => {
                                      setSelectedBudget(item);
                                      setShowBudgetDetails(true);
                                    }}
                                  >
                                    <Info className="h-3 w-3 text-orange-600" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p className="text-xs">查看详细说明</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </div>
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{item.city}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.totalBudget}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.budgeted}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.allocated}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.balance}</TableCell>
                        <TableCell className="text-xs">
                          <Button 
                            variant="link" 
                            size="sm" 
                            className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                          >
                            {item.action}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* 预算详情弹窗 */}
      <Dialog open={showBudgetDetails} onOpenChange={setShowBudgetDetails}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-lg font-medium">预算详情说明</DialogTitle>
          </DialogHeader>
          {selectedBudget && (
            <div className="space-y-6 py-4">
              {/* 基本信息 */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-xs text-gray-600 mb-1">预算项目</div>
                  <div className="text-sm font-medium text-gray-900">{selectedBudget.project}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-600 mb-1">预算状态</div>
                  <Badge 
                    variant="secondary" 
                    className={`text-xs border ${
                      selectedBudget.budgetStatus === "已审批" 
                        ? "bg-green-50 text-green-700 border-green-200" 
                        : selectedBudget.budgetStatus === "待审批"
                        ? "bg-yellow-50 text-yellow-700 border-yellow-200" 
                        : "bg-gray-100 text-gray-700 border-gray-200"
                    }`}
                  >
                    {selectedBudget.budgetStatus}
                  </Badge>
                </div>
                <div>
                  <div className="text-xs text-gray-600 mb-1">申请人</div>
                  <div className="text-sm text-gray-900">{selectedBudget.applicant}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-600 mb-1">申请部门</div>
                  <div className="text-sm text-gray-900">{selectedBudget.department}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-600 mb-1">申请日期</div>
                  <div className="text-sm text-gray-900">{selectedBudget.applyDate}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-600 mb-1">审批人</div>
                  <div className="text-sm text-gray-900">{selectedBudget.approver}</div>
                </div>
              </div>

              {/* 预算标题 */}
              <div>
                <div className="text-xs text-gray-600 mb-2">预算标题</div>
                <div className="text-sm font-medium text-gray-900 p-3 bg-gray-50 rounded-lg">
                  {selectedBudget.budgetTitle}
                </div>
              </div>

              {/* 预算说明 */}
              <div>
                <div className="text-xs text-gray-600 mb-2">预算说明</div>
                <div className="text-sm text-gray-900 p-3 bg-blue-50 rounded-lg">
                  {selectedBudget.budgetDescription}
                </div>
              </div>

              {/* 详细说明 */}
              <div>
                <div className="text-xs text-gray-600 mb-2">详细说明</div>
                <div className="text-sm text-gray-900 p-3 bg-gray-50 rounded-lg whitespace-pre-line">
                  {selectedBudget.detailedDescription}
                </div>
              </div>

              {/* 预算金额信息 */}
              <div className="grid grid-cols-4 gap-4">
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <div className="text-xs text-gray-600 mb-1">总预算</div>
                  <div className="text-sm font-medium text-blue-700">{selectedBudget.totalBudget}</div>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <div className="text-xs text-gray-600 mb-1">已预算</div>
                  <div className="text-sm font-medium text-green-700">{selectedBudget.budgeted}</div>
                </div>
                <div className="text-center p-3 bg-orange-50 rounded-lg">
                  <div className="text-xs text-gray-600 mb-1">已分配</div>
                  <div className="text-sm font-medium text-orange-700">{selectedBudget.allocated}</div>
                </div>
                <div className="text-center p-3 bg-purple-50 rounded-lg">
                  <div className="text-xs text-gray-600 mb-1">余额</div>
                  <div className="text-sm font-medium text-purple-700">{selectedBudget.balance}</div>
                </div>
              </div>

              {/* 操作按钮 */}
              <div className="flex justify-end gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="h-8 text-xs"
                  onClick={() => setShowBudgetDetails(false)}
                >
                  关闭
                </Button>
                <Button 
                  size="sm" 
                  className="h-8 text-xs bg-blue-600 hover:bg-blue-700"
                >
                  <FileText className="h-3 w-3 mr-1" />
                  导出详情
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}