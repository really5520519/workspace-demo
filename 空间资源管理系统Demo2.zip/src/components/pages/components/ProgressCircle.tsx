import { Card, CardContent } from "../../ui/card";

interface ProgressCircleProps {
  percentage: number;
  title: string;
  subtitle: string;
}

export function ProgressCircle({ percentage, title, subtitle }: ProgressCircleProps) {
  const circumference = 2 * Math.PI * 40;
  const strokeDasharray = `${circumference * (percentage / 100)} ${circumference}`;

  return (
    <Card className="bg-white border border-gray-200 h-full">
      <CardContent className="p-6 flex flex-col items-center justify-center h-full">
        <div className="relative w-32 h-32 mb-4">
          <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="40"
              stroke="#e5e7eb"
              strokeWidth="8"
              fill="none"
            />
            <circle
              cx="50"
              cy="50"
              r="40"
              stroke="#3b82f6"
              strokeWidth="8"
              fill="none"
              strokeDasharray={strokeDasharray}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <div className="text-xs text-gray-600">{title}</div>
            <div className="text-lg font-medium text-gray-900">{percentage}%</div>
          </div>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
          <span className="text-gray-600">{subtitle}</span>
        </div>
      </CardContent>
    </Card>
  );
}