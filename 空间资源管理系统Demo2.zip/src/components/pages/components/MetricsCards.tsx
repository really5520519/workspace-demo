import { Card, CardContent } from "../../ui/card";

interface Metric {
  title: string;
  amount: string;
  progress: number;
  progressColor: string;
}

interface MetricsCardsProps {
  metrics: Metric[];
}

export function MetricsCards({ metrics }: MetricsCardsProps) {
  return (
    <div className="grid grid-cols-2 gap-4 h-full">
      {metrics.map((metric, index) => (
        <Card key={index} className="bg-white border border-gray-200">
          <CardContent className="p-4">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <div className="text-xs text-gray-600">{metric.title}</div>
                <div className="text-xs text-gray-500">{metric.progress}%</div>
              </div>
              <div className="text-lg font-medium text-gray-900">{metric.amount}</div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full ${metric.progressColor}`}
                  style={{ width: `${metric.progress}%` }}
                ></div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}