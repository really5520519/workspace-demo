import { Card, CardContent, CardHeader, CardTitle } from "../../ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../../ui/table";
import { Button } from "../../ui/button";
import { Badge } from "../../ui/badge";

interface BillingItem {
  id: string;
  project: string;
  city: string;
  status: string;
  totalAmount: string;
  paidAmount: string;
  unpaidAmount: string;
  overdue: string;
  action: string;
}

interface BillingTableProps {
  items: BillingItem[];
}

export function BillingTable({ items }: BillingTableProps) {
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case '已支付':
        return 'bg-green-50 text-green-700 border-green-200';
      case '待支付':
        return 'bg-orange-50 text-orange-700 border-orange-200';
      default:
        return 'bg-blue-50 text-blue-700 border-blue-200';
    }
  };

  return (
    <Card className="bg-white border border-gray-200">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium text-gray-900">账单明细</CardTitle>
          <div className="flex items-center gap-2">
            <Button size="sm" className="h-7 text-xs bg-blue-600 hover:bg-blue-700">
              生成账单
            </Button>
            <Button variant="outline" size="sm" className="h-7 text-xs">
              导出数据
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50">
                <TableHead className="text-xs font-medium text-gray-700 h-10">账单项目</TableHead>
                <TableHead className="text-xs font-medium text-gray-700 h-10">期间</TableHead>
                <TableHead className="text-xs font-medium text-gray-700 h-10">总金额</TableHead>
                <TableHead className="text-xs font-medium text-gray-700 h-10">已支付</TableHead>
                <TableHead className="text-xs font-medium text-gray-700 h-10">待支付</TableHead>
                <TableHead className="text-xs font-medium text-gray-700 h-10">逾期金额</TableHead>
                <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((item) => (
                <TableRow key={item.id} className="hover:bg-gray-50">
                  <TableCell className="text-xs text-gray-900">{item.project}</TableCell>
                  <TableCell className="text-xs text-gray-900">{item.city}</TableCell>
                  <TableCell className="text-xs text-gray-900">{item.totalAmount}</TableCell>
                  <TableCell className="text-xs text-gray-900">{item.paidAmount}</TableCell>
                  <TableCell className="text-xs text-gray-900">{item.unpaidAmount}</TableCell>
                  <TableCell className="text-xs text-gray-900">{item.overdue}</TableCell>
                  <TableCell className="text-xs">
                    <div className="flex items-center gap-2">
                      <Badge 
                        variant="secondary" 
                        className={`text-xs border ${getStatusBadgeClass(item.status)}`}
                      >
                        {item.status}
                      </Badge>
                      <Button 
                        variant="link" 
                        size="sm" 
                        className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                      >
                        {item.action}
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}