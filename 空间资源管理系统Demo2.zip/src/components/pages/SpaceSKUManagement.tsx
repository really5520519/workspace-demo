import { Button } from "../ui/button";
import { ArrowLeft } from "lucide-react";

interface SpaceSKUManagementContentProps {
  onNavigate?: (page: string, data?: any) => void;
}

export function SpaceSKUManagementContent({ onNavigate }: SpaceSKUManagementContentProps) {
  const handleBack = () => {
    onNavigate?.("pricing-management");
  };

  return (
    <div className="space-y-4" style={{ maxWidth: '1300px', margin: '0 auto' }}>
      {/* 页面标题和返回按钮 */}
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleBack}
            className="h-8 px-2"
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            返回
          </Button>
          <div>
            <h1>空间SKU管理</h1>
            <p className="text-muted-foreground">管理空间商品SKU信息和定价配置</p>
          </div>
        </div>
      </div>

      {/* 暂时为空的内容区域 */}
      <div className="flex items-center justify-center h-96 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
        <div className="text-center">
          <h2 className="text-xl text-gray-500 mb-2">页面内容正在开发中</h2>
          <p className="text-gray-400">空间SKU管理功能即将上线</p>
        </div>
      </div>
    </div>
  );
}