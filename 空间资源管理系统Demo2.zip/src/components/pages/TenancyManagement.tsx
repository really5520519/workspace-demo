import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { TablePagination } from "../ui/table-pagination";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { 
  Building2, 
  Clock, 
  CheckCircle, 
  AlertTriangle,
  ArrowLeft,
  Calendar,
  MapPin,
  User,
  CalendarDays,
  FileText,
  RotateCcw,
  TrendingUp,
  LogOut
} from "lucide-react";

// 统计卡片数据
const statisticsData = [
  {
    title: "总租赁合同",
    value: "89",
    unit: "个",
    icon: Building2,
    color: "text-blue-600"
  },
  {
    title: "即将到期",
    value: "12",
    unit: "个",
    icon: Clock,
    color: "text-orange-600"
  },
  {
    title: "已续签",
    value: "45",
    unit: "个",
    icon: CheckCircle,
    color: "text-green-600"
  },
  {
    title: "逾期未处理",
    value: "3",
    unit: "个",
    icon: AlertTriangle,
    color: "text-red-600"
  }
];

// 合同类型统计数据
const contractTypeData = [
  {
    title: "新租合同",
    value: "28",
    unit: "个",
    icon: FileText,
    color: "text-blue-600"
  },
  {
    title: "续租合同",
    value: "35",
    unit: "个",
    icon: RotateCcw,
    color: "text-green-600"
  },
  {
    title: "扩租合同",
    value: "18",
    unit: "个",
    icon: TrendingUp,
    color: "text-purple-600"
  },
  {
    title: "退租合同",
    value: "8",
    unit: "个",
    icon: LogOut,
    color: "text-red-600"
  }
];

// 租期数据
const tenancyData = [
  {
    year: "2024",
    month: "1月",
    id: "TNY-2024-001",
    projectName: "深圳南山科技园办公楼租赁",
    contractId: "CON-2025-007",
    cityWorkplace: "深圳-南山区科技园",
    leaseManager: "王经理",
    startDate: "2024-01-15",
    endDate: "2026-01-14",
    duration: "24个月",
    monthlyRent: "¥280,000",
    totalRent: "¥6,720,000",
    status: "正常",
    daysToExpiry: 358,
    renewalStatus: "未处理"
  },
  {
    year: "2023",
    month: "3月",
    id: "TNY-2024-002",
    projectName: "上海浦东新区产业园租赁",
    contractId: "CON-2025-009",
    cityWorkplace: "上海-浦东新区",
    leaseManager: "刘经理",
    startDate: "2023-03-20",
    endDate: "2025-03-19",
    duration: "24个月",
    monthlyRent: "¥320,000",
    totalRent: "¥7,680,000",
    status: "即将到期",
    daysToExpiry: 85,
    renewalStatus: "续签中"
  },
  {
    year: "2024",
    month: "6月",
    id: "TNY-2024-003",
    projectName: "广州天河CBD办公楼续租",
    contractId: "CON-2025-010",
    cityWorkplace: "广州-天河区",
    leaseManager: "张经理",
    startDate: "2024-06-01",
    endDate: "2027-05-31",
    duration: "36个月",
    monthlyRent: "¥250,000",
    totalRent: "¥9,000,000",
    status: "正常",
    daysToExpiry: 1247,
    renewalStatus: "已续签"
  },
  {
    year: "2023",
    month: "9月",
    id: "TNY-2024-004",
    projectName: "杭州西湖区创意园租赁",
    contractId: "CON-2025-011",
    cityWorkplace: "杭州-西湖区",
    leaseManager: "李经理",
    startDate: "2023-09-10",
    endDate: "2025-09-09",
    duration: "24个月",
    monthlyRent: "¥180,000",
    totalRent: "¥4,320,000",
    status: "即将到期",
    daysToExpiry: 249,
    renewalStatus: "未处理"
  },
  {
    year: "2024",
    month: "2月",
    id: "TNY-2024-005",
    projectName: "武汉江汉区商务中心租赁",
    contractId: "CON-2025-013",
    cityWorkplace: "武汉-江汉区",
    leaseManager: "赵经理",
    startDate: "2024-02-01",
    endDate: "2026-01-31",
    duration: "24个月",
    monthlyRent: "¥200,000",
    totalRent: "¥4,800,000",
    status: "正常",
    daysToExpiry: 375,
    renewalStatus: "未处理"
  },
  {
    year: "2023",
    month: "5月",
    id: "TNY-2024-006",
    projectName: "成都高新区研发中心租赁",
    contractId: "CON-2025-008",
    cityWorkplace: "成都-高新区",
    leaseManager: "陈经理",
    startDate: "2023-05-15",
    endDate: "2025-05-14",
    duration: "24个月",
    monthlyRent: "¥220,000",
    totalRent: "¥5,280,000",
    status: "即将到期",
    daysToExpiry: 141,
    renewalStatus: "续签中"
  },
  {
    year: "2024",
    month: "8月",
    id: "TNY-2024-007",
    projectName: "苏州工业园区办公空间",
    contractId: "CON-2025-012",
    cityWorkplace: "苏州-工业园区",
    leaseManager: "周经理",
    startDate: "2024-08-01",
    endDate: "2026-07-31",
    duration: "24个月",
    monthlyRent: "¥160,000",
    totalRent: "¥3,840,000",
    status: "正常",
    daysToExpiry: 549,
    renewalStatus: "未处理"
  },
  {
    year: "2023",
    month: "12月",
    id: "TNY-2024-008",
    projectName: "西安雁塔区总部基地",
    contractId: "CON-2025-014",
    cityWorkplace: "西安-雁塔区",
    leaseManager: "吴经理",
    startDate: "2023-12-01",
    endDate: "2024-11-30",
    duration: "12个月",
    monthlyRent: "¥140,000",
    totalRent: "¥1,680,000",
    status: "逾期",
    daysToExpiry: -32,
    renewalStatus: "逾期未处理"
  }
];

// 状态徽章配色
const getStatusBadge = (status: string) => {
  switch (status) {
    case "正常":
      return <Badge variant="default" className="bg-green-100 text-green-800 hover:bg-green-100">{status}</Badge>;
    case "即将到期":
      return <Badge variant="secondary" className="bg-orange-100 text-orange-800 hover:bg-orange-100">{status}</Badge>;
    case "逾期":
      return <Badge variant="secondary" className="bg-red-100 text-red-800 hover:bg-red-100">{status}</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

// 续签状态徽章配色
const getRenewalStatusBadge = (status: string) => {
  switch (status) {
    case "已续签":
      return <Badge variant="default" className="bg-blue-100 text-blue-800 hover:bg-blue-100">{status}</Badge>;
    case "续签中":
      return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">{status}</Badge>;
    case "未处理":
      return <Badge variant="outline" className="bg-gray-100 text-gray-800 hover:bg-gray-100">{status}</Badge>;
    case "逾期未处理":
      return <Badge variant="secondary" className="bg-red-100 text-red-800 hover:bg-red-100">{status}</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

interface TenancyManagementProps {
  onBack?: () => void;
}

export function TenancyManagementContent({ onBack }: TenancyManagementProps) {
  const [activeTab, setActiveTab] = useState("by-year-month");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [yearFilter, setYearFilter] = useState("2024");
  const [monthFilter, setMonthFilter] = useState("all");
  const [cityFilter, setCityFilter] = useState("all");
  const [managerFilter, setManagerFilter] = useState("all");
  const totalItems = 89; // 模拟总条数

  // 根据当前标签页过滤数据
  const getFilteredData = () => {
    let filteredData = [...tenancyData];
    
    switch (activeTab) {
      case "by-year-month":
        if (yearFilter !== "all") {
          filteredData = filteredData.filter(item => 
            item.startDate.includes(yearFilter) || item.endDate.includes(yearFilter)
          );
        }
        if (monthFilter !== "all") {
          filteredData = filteredData.filter(item => 
            item.startDate.includes(`-${monthFilter.padStart(2, '0')}-`) || 
            item.endDate.includes(`-${monthFilter.padStart(2, '0')}-`)
          );
        }
        break;
      case "by-city-workplace":
        if (cityFilter !== "all") {
          filteredData = filteredData.filter(item => 
            item.cityWorkplace.includes(cityFilter)
          );
        }
        break;
      case "by-lease-manager":
        if (managerFilter !== "all") {
          filteredData = filteredData.filter(item => 
            item.leaseManager === managerFilter
          );
        }
        break;
      case "by-calendar":
        // 按日历视图可以有不同的过滤逻辑
        break;
    }
    
    return filteredData;
  };

  const filteredData = getFilteredData();

  return (
    <div className="space-y-4">
      {/* 页面标题 */}
      <div className="flex items-center gap-3">
        <Button variant="outline" size="sm" onClick={onBack} className="h-7">
          <ArrowLeft className="h-3 w-3 mr-1" />
          返回
        </Button>
        <h1 className="text-[15px] font-bold">租期管理</h1>
      </div>

      {/* 统计卡片区域 */}
      <div className="grid grid-cols-4 gap-4">
        {statisticsData.map((item, index) => {
          const Icon = item.icon;
          return (
            <Card key={index} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{item.title}</p>
                    <p className="text-2xl font-semibold">{item.value}<span className="text-sm font-normal ml-1">{item.unit}</span></p>
                  </div>
                  <Icon className={`h-8 w-8 ${item.color}`} />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* 合同类型统计卡片区域 */}
      <div className="grid grid-cols-4 gap-4">
        {contractTypeData.map((item, index) => {
          const Icon = item.icon;
          return (
            <Card key={index} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{item.title}</p>
                    <p className="text-2xl font-semibold">{item.value}<span className="text-sm font-normal ml-1">{item.unit}</span></p>
                  </div>
                  <Icon className={`h-8 w-8 ${item.color}`} />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* 租期列表区域 */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="font-bold">
              租期管理列表
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="mb-4 w-fit h-auto p-1">
              <TabsTrigger value="by-year-month" className="text-sm px-3 py-1.5">
                <Calendar className="h-3 w-3 mr-1" />
                按年月
              </TabsTrigger>
              <TabsTrigger value="by-city-workplace" className="text-sm px-3 py-1.5">
                <MapPin className="h-3 w-3 mr-1" />
                按城市职场
              </TabsTrigger>
              <TabsTrigger value="by-lease-manager" className="text-sm px-3 py-1.5">
                <User className="h-3 w-3 mr-1" />
                按租赁经理
              </TabsTrigger>
              <TabsTrigger value="by-calendar" className="text-sm px-3 py-1.5">
                <CalendarDays className="h-3 w-3 mr-1" />
                按日历
              </TabsTrigger>
            </TabsList>

            {/* 筛选器区域 */}
            <div className="flex items-center gap-4 mb-4">
              {activeTab === "by-year-month" && (
                <>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-600">年份：</span>
                    <Select value={yearFilter} onValueChange={setYearFilter}>
                      <SelectTrigger className="w-32 h-8 text-sm">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">全部</SelectItem>
                        <SelectItem value="2024">2024年</SelectItem>
                        <SelectItem value="2025">2025年</SelectItem>
                        <SelectItem value="2026">2026年</SelectItem>
                        <SelectItem value="2027">2027年</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-600">月份：</span>
                    <Select value={monthFilter} onValueChange={setMonthFilter}>
                      <SelectTrigger className="w-32 h-8 text-sm">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">全部</SelectItem>
                        <SelectItem value="1">1月</SelectItem>
                        <SelectItem value="2">2月</SelectItem>
                        <SelectItem value="3">3月</SelectItem>
                        <SelectItem value="4">4月</SelectItem>
                        <SelectItem value="5">5月</SelectItem>
                        <SelectItem value="6">6月</SelectItem>
                        <SelectItem value="7">7月</SelectItem>
                        <SelectItem value="8">8月</SelectItem>
                        <SelectItem value="9">9月</SelectItem>
                        <SelectItem value="10">10月</SelectItem>
                        <SelectItem value="11">11月</SelectItem>
                        <SelectItem value="12">12月</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}
              
              {activeTab === "by-city-workplace" && (
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600">城市：</span>
                  <Select value={cityFilter} onValueChange={setCityFilter}>
                    <SelectTrigger className="w-40 h-8 text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">全部城市</SelectItem>
                      <SelectItem value="深圳">深圳</SelectItem>
                      <SelectItem value="上海">上海</SelectItem>
                      <SelectItem value="广州">广州</SelectItem>
                      <SelectItem value="杭州">杭州</SelectItem>
                      <SelectItem value="武汉">武汉</SelectItem>
                      <SelectItem value="成都">成都</SelectItem>
                      <SelectItem value="苏州">苏州</SelectItem>
                      <SelectItem value="西安">西安</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
              
              {activeTab === "by-lease-manager" && (
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600">租赁经理：</span>
                  <Select value={managerFilter} onValueChange={setManagerFilter}>
                    <SelectTrigger className="w-40 h-8 text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">全部经理</SelectItem>
                      <SelectItem value="王经理">王经理</SelectItem>
                      <SelectItem value="刘经理">刘经理</SelectItem>
                      <SelectItem value="张经理">张经理</SelectItem>
                      <SelectItem value="李经理">李经理</SelectItem>
                      <SelectItem value="赵经理">赵经理</SelectItem>
                      <SelectItem value="陈经理">陈经理</SelectItem>
                      <SelectItem value="周经理">周经理</SelectItem>
                      <SelectItem value="吴经理">吴经理</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            <TabsContent value={activeTab} className="mt-0">
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-sm font-medium">年度</TableHead>
                      <TableHead className="text-sm font-medium">月份</TableHead>
                      <TableHead className="text-sm font-medium">租期ID</TableHead>
                      <TableHead className="text-sm font-medium">项目名称</TableHead>
                      <TableHead className="text-sm font-medium">合同ID</TableHead>
                      <TableHead className="text-sm font-medium">城市职场</TableHead>
                      <TableHead className="text-sm font-medium">租赁经理</TableHead>
                      <TableHead className="text-sm font-medium">租期开始</TableHead>
                      <TableHead className="text-sm font-medium">租期结束</TableHead>
                      <TableHead className="text-sm font-medium">租期时长</TableHead>
                      <TableHead className="text-sm font-medium">月租金</TableHead>
                      <TableHead className="text-sm font-medium">总租金</TableHead>
                      <TableHead className="text-sm font-medium">租期状态</TableHead>
                      <TableHead className="text-sm font-medium">距到期天数</TableHead>
                      <TableHead className="text-sm font-medium">续签状态</TableHead>
                      <TableHead className="text-sm font-medium">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredData.map((item, index) => (
                      <TableRow key={index} className="hover:bg-muted/30">
                        <TableCell className="text-sm">{item.year}</TableCell>
                        <TableCell className="text-sm">{item.month}</TableCell>
                        <TableCell className="text-sm font-mono">{item.id}</TableCell>
                        <TableCell className="text-sm">{item.projectName}</TableCell>
                        <TableCell className="text-sm font-mono">{item.contractId}</TableCell>
                        <TableCell className="text-sm">{item.cityWorkplace}</TableCell>
                        <TableCell className="text-sm">{item.leaseManager}</TableCell>
                        <TableCell className="text-sm">{item.startDate}</TableCell>
                        <TableCell className="text-sm">{item.endDate}</TableCell>
                        <TableCell className="text-sm">{item.duration}</TableCell>
                        <TableCell className="text-sm">{item.monthlyRent}</TableCell>
                        <TableCell className="text-sm">{item.totalRent}</TableCell>
                        <TableCell>{getStatusBadge(item.status)}</TableCell>
                        <TableCell className={`text-sm ${
                          item.daysToExpiry < 0 ? 'text-red-600' : 
                          item.daysToExpiry < 90 ? 'text-orange-600' : 
                          'text-gray-900'
                        }`}>
                          {item.daysToExpiry < 0 ? `逾期${Math.abs(item.daysToExpiry)}天` : `${item.daysToExpiry}天`}
                        </TableCell>
                        <TableCell>{getRenewalStatusBadge(item.renewalStatus)}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm" className="h-7 text-xs text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                            查看详情
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <TablePagination
                total={totalItems}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}