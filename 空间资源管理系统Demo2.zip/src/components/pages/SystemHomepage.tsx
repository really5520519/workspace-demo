import { Card, CardContent } from "../ui/card";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Users, Building2, MapPin, Archive, BarChart2, BarChart3, FolderOpen, Settings, Layers, LayoutGrid } from "lucide-react";

interface SystemHomepageProps {
  onNavigate: (targetId: string) => void;
}

export function SystemHomepage({ onNavigate }: SystemHomepageProps) {
  return (
    <div className="space-y-8">
      {/* 页面标题区域 */}
      <div className="text-center space-y-2">
        <h1 className="text-2xl font-bold text-gray-900">空间资源管理系统</h1>
        <p className="text-sm text-gray-600">统一管理空间资源、提升办公效率、实现智能化运营</p>
      </div>

      {/* 功能卡片区域 */}
      <div className="grid grid-cols-2 gap-8">
        {/* 左侧功能卡片 - 用户端 */}
        <div className="space-y-4">
          <div className="mb-4">
            <h2 className="text-lg font-medium text-gray-800 mb-2">用户端服务</h2>
            <p className="text-xs text-gray-500">为员工和部门提供便捷的空间服务</p>
          </div>



          {/* 空间服务 */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Building2 className="h-6 w-6 text-blue-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium text-gray-900">空间服务管理</h3>
                    <Badge variant="outline" className="text-xs">员工功能</Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-3">
                    查看工位信息、设备服务等空间资源
                  </p>
                  <Button 
                    size="sm" 
                    className="h-7 text-xs bg-blue-600 hover:bg-blue-700"
                    onClick={() => onNavigate('space-service')}
                  >
                    查看服务
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 工位绑定 */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <MapPin className="h-6 w-6 text-blue-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium text-gray-900">工位绑定</h3>
                    <Badge variant="outline" className="text-xs">员工功能</Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-3">
                    管理个人工位绑定和使用历史
                  </p>
                  <Button 
                    size="sm" 
                    className="h-7 text-xs bg-blue-600 hover:bg-blue-700"
                    onClick={() => onNavigate('seat-binding')}
                  >
                    管理工位
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 空间资源申请 */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Archive className="h-6 w-6 text-blue-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium text-gray-900">资源申请</h3>
                    <Badge variant="outline" className="text-xs">部门功能</Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-3">
                    部门空间资源申请和使用管理
                  </p>
                  <Button 
                    size="sm" 
                    className="h-7 text-xs bg-blue-600 hover:bg-blue-700"
                    onClick={() => onNavigate('space-resource-service')}
                  >
                    申请资源
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 右侧功能卡片 - 管理端 */}
        <div className="space-y-4">
          <div className="mb-4">
            <h2 className="text-lg font-medium text-gray-800 mb-2">管理端服务</h2>
            <p className="text-xs text-gray-500">为管理人员提供全面的运营管理工具</p>
          </div>



          {/* 经营分析 */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <BarChart3 className="h-6 w-6 text-green-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium text-gray-900">经营分析</h3>
                    <Badge className="text-xs bg-green-100 text-green-800">经营管理</Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-3">
                    费用分析、预算管理、成本控制
                  </p>
                  <Button 
                    size="sm" 
                    variant="outline"
                    className="h-7 text-xs"
                    onClick={() => onNavigate('business-analysis')}
                  >
                    查看分析
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 项目管理 */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <FolderOpen className="h-6 w-6 text-green-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium text-gray-900">项目管理</h3>
                    <Badge className="text-xs bg-green-100 text-green-800">运营管理</Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-3">
                    需求管理、租赁、装修、分配全流程
                  </p>
                  <Button 
                    size="sm" 
                    variant="outline"
                    className="h-7 text-xs"
                    onClick={() => onNavigate('project-management')}
                  >
                    管理项目
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 空间资源管理 */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Building2 className="h-6 w-6 text-green-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium text-gray-900">工区管理</h3>
                    <Badge className="text-xs bg-green-100 text-green-800">资源管理</Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-3">
                    工区、库存、设施设备综合管理
                  </p>
                  <Button 
                    size="sm" 
                    variant="outline"
                    className="h-7 text-xs"
                    onClick={() => onNavigate('space-resource-management')}
                  >
                    管理资源
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>


        </div>
      </div>

      {/* 底部快速入口 */}
      <div className="border-t pt-6">

      </div>
    </div>
  );
}