import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { TablePagination } from "../ui/table-pagination";
import { 
  FileText, 
  Building2, 
  Clock, 
  CheckCircle, 
  Send, 
  Calendar,
  Plus,
  Search
} from "lucide-react";

// 统计卡片数据
const statisticsData = [
  {
    title: "新增租赁需求",
    value: "12",
    icon: FileText,
    color: "text-blue-600"
  },
  {
    title: "已结束",
    value: "89",
    icon: CheckCircle,
    color: "text-green-600"
  },
  {
    title: "已提交决策会",
    value: "3",
    icon: Send,
    color: "text-orange-600"
  },
  {
    title: "已提交OA",
    value: "5",
    icon: FileText,
    color: "text-purple-600"
  },
  {
    title: "已提交项目需求",
    value: "4",
    icon: Building2,
    color: "text-red-600"
  }
];

// 租赁列表数据
const leaseData = [
  {
    projectId: "LSE-2025-001",
    demandId: "REQ-2025-010", 
    leaseProjectId: "LSE-2025-001",
    leaseProjectName: "深圳南山科技园办公楼租赁项目",
    contractId: "CON-2025-007",
    demandSide: "业务",
    stage: "OA合同",
    status: "进行中",
    demandType: "新租场",
    demandPeriod: "2025 Q3",
    location: "深圳-南山区",
    department: "销售部",
    leasePlan: "方案A",
    submitTime: "2024-07-20",
    lastUpdateTime: "2024-07-25"
  },
  {
    projectId: "LSE-2025-002",
    demandId: "PLN-2025-005",
    leaseProjectId: "LSE-2025-002", 
    leaseProjectName: "成都高新区研发中心租赁项目",
    contractId: "CON-2025-008",
    demandSide: "房产",
    stage: "决策会",
    status: "待批",
    demandType: "新租场",
    demandPeriod: "2026 H1",
    location: "成都-高新区",
    department: "房产规划部",
    leasePlan: "方案C",
    submitTime: "2024-07-15",
    lastUpdateTime: "2024-07-22"
  },
  {
    projectId: "LSE-2025-003",
    demandId: "REQ-2025-012",
    leaseProjectId: "LSE-2025-003",
    leaseProjectName: "上海浦东新区产业园租赁项目",
    contractId: "CON-2025-009",
    demandSide: "业务",
    stage: "合同签署",
    status: "进行中",
    demandType: "新租场",
    demandPeriod: "2025 Q4",
    location: "上海-浦东新区",
    department: "研发部",
    leasePlan: "方案B",
    submitTime: "2024-07-18",
    lastUpdateTime: "2024-07-26"
  },
  {
    projectId: "LSE-2025-004",
    demandId: "PLN-2025-007",
    leaseProjectId: "LSE-2025-004",
    leaseProjectName: "广州天河CBD办公楼续租项目",
    contractId: "CON-2025-010",
    demandSide: "房产",
    stage: "方案评审",
    status: "已完成",
    demandType: "续租",
    demandPeriod: "2025 Q2",
    location: "广州-天河区",
    department: "运营部",
    leasePlan: "方案A",
    submitTime: "2024-07-10",
    lastUpdateTime: "2024-07-20"
  },
  {
    projectId: "LSE-2025-005",
    demandId: "REQ-2025-015",
    leaseProjectId: "LSE-2025-005",
    leaseProjectName: "杭州西湖区创意园租赁项目",
    contractId: "CON-2025-011",
    demandSide: "业务",
    stage: "尽调阶段",
    status: "进行中",
    demandType: "新租场",
    demandPeriod: "2025 H2",
    location: "杭州-西湖区",
    department: "设计部",
    leasePlan: "方案D",
    submitTime: "2024-07-22",
    lastUpdateTime: "2024-07-28"
  },
  {
    projectId: "LSE-2025-006",
    demandId: "PLN-2025-003",
    leaseProjectId: "LSE-2025-006",
    leaseProjectName: "苏州工业园区办公空间转租项目",
    contractId: "CON-2025-012",
    demandSide: "房产",
    stage: "议会审议",
    status: "待批",
    demandType: "转租",
    demandPeriod: "2025 Q3",
    location: "苏州-工业园区",
    department: "房产规划部",
    leasePlan: "方案E",
    submitTime: "2024-07-12",
    lastUpdateTime: "2024-07-24"
  },
  {
    projectId: "LSE-2025-007",
    demandId: "REQ-2025-018",
    leaseProjectId: "LSE-2025-007",
    leaseProjectName: "武汉江汉区商务中心租赁项目",
    contractId: "CON-2025-013",
    demandSide: "业务",
    stage: "OA合同",
    status: "进行中",
    demandType: "新租场",
    demandPeriod: "2026 Q1",
    location: "武汉-江汉区",
    department: "客服部",
    leasePlan: "方案F",
    submitTime: "2024-07-16",
    lastUpdateTime: "2024-07-27"
  },
  {
    projectId: "LSE-2025-008",
    demandId: "PLN-2025-009",
    leaseProjectId: "LSE-2025-008",
    leaseProjectName: "西安雁塔区总部基地续租项目",
    contractId: "CON-2025-014",
    demandSide: "房产",
    stage: "风控审查",
    status: "暂停",
    demandType: "续租",
    demandPeriod: "2025 H1",
    location: "西安-雁塔区",
    department: "行政部",
    leasePlan: "方案G",
    submitTime: "2024-07-08",
    lastUpdateTime: "2024-07-18"
  },
  {
    projectId: "LSE-2025-009",
    demandId: "REQ-2025-021",
    leaseProjectId: "LSE-2025-009",
    leaseProjectName: "天津滨海新区科技园租赁项目",
    contractId: "CON-2025-015",
    demandSide: "业务",
    stage: "决策会",
    status: "待批",
    demandType: "新租场",
    demandPeriod: "2025 Q4",
    location: "天津-滨海新区",
    department: "战略部",
    leasePlan: "方案H",
    submitTime: "2024-07-25",
    lastUpdateTime: "2024-07-30"
  },
  {
    projectId: "LSE-2025-010",
    demandId: "PLN-2025-011",
    leaseProjectId: "LSE-2025-010",
    leaseProjectName: "南京鼓楼区金融大厦转租项目",
    contractId: "CON-2025-016",
    demandSide: "房产",
    stage: "合同执行",
    status: "已完成",
    demandType: "转租",
    demandPeriod: "2025 Q1",
    location: "南京-鼓楼区",
    department: "财务部",
    leasePlan: "方案I",
    submitTime: "2024-06-30",
    lastUpdateTime: "2024-07-15"
  }
];

// 状态徽章配色
const getStatusBadge = (status: string) => {
  switch (status) {
    case "进行中":
      return <Badge variant="default" className="bg-blue-100 text-blue-800 hover:bg-blue-100">{status}</Badge>;
    case "待批":
      return <Badge variant="secondary" className="bg-orange-100 text-orange-800 hover:bg-orange-100">{status}</Badge>;
    case "已完成":
      return <Badge variant="default" className="bg-green-100 text-green-800 hover:bg-green-100">{status}</Badge>;
    case "暂停":
      return <Badge variant="secondary" className="bg-red-100 text-red-800 hover:bg-red-100">{status}</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

// 阶段徽章配色
const getStageBadge = (stage: string) => {
  switch (stage) {
    case "OA合同":
      return <Badge variant="default" className="bg-green-100 text-green-800 hover:bg-green-100">{stage}</Badge>;
    case "决策会":
      return <Badge variant="secondary" className="bg-purple-100 text-purple-800 hover:bg-purple-100">{stage}</Badge>;
    case "合同签署":
      return <Badge variant="default" className="bg-blue-100 text-blue-800 hover:bg-blue-100">{stage}</Badge>;
    case "方案评审":
      return <Badge variant="secondary" className="bg-cyan-100 text-cyan-800 hover:bg-cyan-100">{stage}</Badge>;
    case "尽调阶段":
      return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">{stage}</Badge>;
    case "议会审议":
      return <Badge variant="secondary" className="bg-indigo-100 text-indigo-800 hover:bg-indigo-100">{stage}</Badge>;
    case "风控审查":
      return <Badge variant="secondary" className="bg-pink-100 text-pink-800 hover:bg-pink-100">{stage}</Badge>;
    case "合同执行":
      return <Badge variant="default" className="bg-teal-100 text-teal-800 hover:bg-teal-100">{stage}</Badge>;
    default:
      return <Badge variant="outline">{stage}</Badge>;
  }
};

interface LeaseManagementProps {
  onNavigate?: (targetId: string, data?: any) => void;
}

export function LeaseManagementContent({ onNavigate }: LeaseManagementProps) {
  const [activeTab, setActiveTab] = useState("business-demand");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const totalItems = 89; // 模拟总条数
  
  // 搜索和筛选状态
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStage, setSelectedStage] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center gap-3">
        <h1 className="text-[15px] font-normal font-bold">租赁管理</h1>
        <Button 
          size="sm" 
          className="h-8 text-sm border border-blue-600 bg-blue-50 text-blue-600 hover:bg-blue-100"
          onClick={() => onNavigate?.("tenancy-management")}
        >
          <Calendar className="h-4 w-4 mr-1" />
          租期管理
        </Button>
      </div>

      {/* 统计卡片区域 */}
      <div className="grid grid-cols-5 gap-4">
        {statisticsData.map((item, index) => {
          const Icon = item.icon;
          return (
            <Card key={index} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{item.title}</p>
                    <p className="text-2xl font-semibold">{item.value}</p>
                  </div>
                  <Icon className={`h-8 w-8 ${item.color}`} />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* 租赁列表区域 */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="font-bold">
              租赁列表
            </CardTitle>
            <Button size="sm" className="h-8 text-sm bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-1" />
              新增
            </Button>
          </div>
          
          {/* 搜索和筛选区域 */}
          <div className="flex items-center gap-3 mt-4">
            <div className="relative flex-1 max-w-80">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="搜索项目名称/项目ID/合同ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-8 text-sm"
              />
            </div>
            
            <Select value={selectedStage} onValueChange={setSelectedStage}>
              <SelectTrigger className="w-32 h-8 text-sm">
                <SelectValue placeholder="阶段" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部阶段</SelectItem>
                <SelectItem value="OA合同">OA合同</SelectItem>
                <SelectItem value="决策会">决策会</SelectItem>
                <SelectItem value="合同签署">合同签署</SelectItem>
                <SelectItem value="方案评审">方案评审</SelectItem>
                <SelectItem value="尽调阶段">尽调阶段</SelectItem>
                <SelectItem value="议会审议">议会审议</SelectItem>
                <SelectItem value="风控审查">风控审查</SelectItem>
                <SelectItem value="合同执行">合同执行</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-28 h-8 text-sm">
                <SelectValue placeholder="状态" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部状态</SelectItem>
                <SelectItem value="进行中">进行中</SelectItem>
                <SelectItem value="待批">待批</SelectItem>
                <SelectItem value="已完成">已完成</SelectItem>
                <SelectItem value="暂停">暂停</SelectItem>
              </SelectContent>
            </Select>

            <Button 
              variant="outline" 
              size="sm" 
              className="h-8 text-sm text-red-600 hover:text-red-700"
              onClick={() => {
                setSearchQuery("");
                setSelectedStage("all");
                setSelectedStatus("all");
              }}
            >
              重置筛选
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-[0px] mt-[-21px] mr-[25px] mb-[0px] ml-[25px]">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="mb-4 w-fit h-auto p-1">
              <TabsTrigger value="business-demand" className="text-sm px-3 py-1.5">
                业务需求
              </TabsTrigger>
              <TabsTrigger value="property-demand" className="text-sm px-3 py-1.5">
                房产需求
              </TabsTrigger>
              <TabsTrigger value="internal-sublease" className="text-sm px-3 py-1.5">
                内部转租
              </TabsTrigger>
              <TabsTrigger value="registration-demand" className="text-sm px-3 py-1.5">
                注册需求
              </TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="mt-0">
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-sm font-medium">项目ID</TableHead>
                      <TableHead className="text-sm font-medium">需求ID</TableHead>
                      <TableHead className="text-sm font-medium">租赁项目ID</TableHead>
                      <TableHead className="text-sm font-medium">租赁项目名称</TableHead>
                      <TableHead className="text-sm font-medium">合同ID</TableHead>
                      <TableHead className="text-sm font-medium">需求方</TableHead>
                      <TableHead className="text-sm font-medium">阶段</TableHead>
                      <TableHead className="text-sm font-medium">状态</TableHead>
                      <TableHead className="text-sm font-medium">需求类型</TableHead>
                      <TableHead className="text-sm font-medium">需求时期</TableHead>
                      <TableHead className="text-sm font-medium">地点</TableHead>
                      <TableHead className="text-sm font-medium">部门</TableHead>
                      <TableHead className="text-sm font-medium">租赁方案</TableHead>
                      <TableHead className="text-sm font-medium">提交时间</TableHead>
                      <TableHead className="text-sm font-medium">最近更新时间</TableHead>
                      <TableHead className="text-sm font-medium">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {leaseData.map((item, index) => (
                      <TableRow key={index} className="hover:bg-muted/30">
                        <TableCell className="text-sm font-mono">{item.projectId}</TableCell>
                        <TableCell className="text-sm font-mono">{item.demandId}</TableCell>
                        <TableCell className="text-sm font-mono">{item.leaseProjectId}</TableCell>
                        <TableCell className="text-sm">{item.leaseProjectName}</TableCell>
                        <TableCell className="text-sm font-mono">{item.contractId}</TableCell>
                        <TableCell className="text-sm">{item.demandSide}</TableCell>
                        <TableCell>{getStageBadge(item.stage)}</TableCell>
                        <TableCell>{getStatusBadge(item.status)}</TableCell>
                        <TableCell className="text-sm">{item.demandType}</TableCell>
                        <TableCell className="text-sm">{item.demandPeriod}</TableCell>
                        <TableCell className="text-sm">{item.location}</TableCell>
                        <TableCell className="text-sm">{item.department}</TableCell>
                        <TableCell className="text-sm">{item.leasePlan}</TableCell>
                        <TableCell className="text-sm">{item.submitTime}</TableCell>
                        <TableCell className="text-sm">{item.lastUpdateTime}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm" className="h-7 text-xs text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                            查看
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <TablePagination
                total={totalItems}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}