import { useState } from "react";
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { TablePagination } from "../ui/table-pagination";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Badge } from "../ui/badge";
import { 
  Plus, 
  RefreshCw, 
  Search,
  Building2,
  Shield,
  Zap,
  Wifi,
  FileText,
  Users,
  Clock,
  Download
} from "lucide-react";

export function BuildingSupplierManagementContent() {
  const [activeTab, setActiveTab] = useState("administrative");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const totalItems = 45; // 模拟总条数

  // 基础职场数据
  const workspaceData = [
    {
      id: "1",
      workspaceName: "望京SOHO工区",
      workspaceCode: "WJ001",
      workspaceStatus: "运营中",
      is24Hours: "是",
      hasCanteen: "是",
      hasCooking: "否",
      canteenCount: "2",
      canteenSeats: "120",
      canteenFloor: "3F, 5F",
      gymCount: "1",
      gymLocation: "地下一层",
      hasSecurityOnSite: "是",
      accessControlManager: "字节跳动",
      accessControlType: "字节",
      accessControlStatus: "正常",
      hasPropertyTurnstile: "是",
      hasAdminOnSite: "是",
      parking: "有",
      parkingSpaces: "150",
      powerType: "市电+备电",
      hvacType: "中央空调",
      hvacCoolingDate: "5月-10月",
      hvacHeatingDate: "11月-4月",
      weekendHvac: "是",
      overtimeHours: "18:00-22:00",
      overtimeRate: "5元/小时",
      elevatorInfo: "三菱电梯",
      passengerElevators: "6",
      freightElevators: "2",
      escalators: "4",
      elevatorBrand: "三菱",
      elevatorModel: "GPS-III",
      hasMachineRoom: "是",
      elevatorAge: "3",
      elevatorManager: "物业公司",
      machineRoomCount: "8",
      apCount: "156",
      networkPorts: "2400"
    },
    {
      id: "2",
      workspaceName: "陆家嘴工区",
      workspaceCode: "LJZ002",
      workspaceStatus: "运营中",
      is24Hours: "否",
      hasCanteen: "是",
      hasCooking: "是",
      canteenCount: "1",
      canteenSeats: "80",
      canteenFloor: "2F",
      gymCount: "0",
      gymLocation: "-",
      hasSecurityOnSite: "是",
      accessControlManager: "大物业",
      accessControlType: "大物业",
      accessControlStatus: "正常",
      hasPropertyTurnstile: "是",
      hasAdminOnSite: "否",
      parking: "有",
      parkingSpaces: "80",
      powerType: "市电",
      hvacType: "分体空调",
      hvacCoolingDate: "6月-9月",
      hvacHeatingDate: "12月-3月",
      weekendHvac: "否",
      overtimeHours: "18:00-20:00",
      overtimeRate: "8元/小时",
      elevatorInfo: "奥的斯电梯",
      passengerElevators: "4",
      freightElevators: "1",
      escalators: "2",
      elevatorBrand: "奥的斯",
      elevatorModel: "Gen2",
      hasMachineRoom: "否",
      elevatorAge: "5",
      elevatorManager: "维保公司",
      machineRoomCount: "5",
      apCount: "89",
      networkPorts: "1600"
    },
    {
      id: "3",
      workspaceName: "科技园工区",
      workspaceCode: "KJY003",
      workspaceStatus: "装修中",
      is24Hours: "是",
      hasCanteen: "否",
      hasCooking: "否",
      canteenCount: "0",
      canteenSeats: "0",
      canteenFloor: "-",
      gymCount: "1",
      gymLocation: "顶层",
      hasSecurityOnSite: "否",
      accessControlManager: "字节跳动",
      accessControlType: "字节",
      accessControlStatus: "调试中",
      hasPropertyTurnstile: "否",
      hasAdminOnSite: "是",
      parking: "无",
      parkingSpaces: "0",
      powerType: "市电+UPS",
      hvacType: "VRV系统",
      hvacCoolingDate: "全年",
      hvacHeatingDate: "全年",
      weekendHvac: "是",
      overtimeHours: "全天",
      overtimeRate: "免费",
      elevatorInfo: "日立电梯",
      passengerElevators: "8",
      freightElevators: "2",
      escalators: "0",
      elevatorBrand: "日立",
      elevatorModel: "NEXIEZ-GPX",
      hasMachineRoom: "是",
      elevatorAge: "1",
      elevatorManager: "日立维保",
      machineRoomCount: "12",
      apCount: "200",
      networkPorts: "3200"
    }
  ];

  // 获取各标签页的统计数据
  const getTabStats = (tabId: string) => {
    switch (tabId) {
      case "administrative":
        return [
          { label: "行政覆盖职场数", value: "25", icon: Building2, color: "bg-blue-50 text-blue-600" },
          { label: "24小时职场数", value: "12", icon: Clock, color: "bg-green-50 text-green-600" },
          { label: "供餐职场数", value: "18", icon: FileText, color: "bg-orange-50 text-orange-600" }
        ];
      case "security":
        return [
          { label: "门禁覆盖职场数", value: "23", icon: Shield, color: "bg-red-50 text-red-600" },
          { label: "安保驻场数", value: "15", icon: Users, color: "bg-purple-50 text-purple-600" },
          { label: "物业闸机数", value: "8", icon: Building2, color: "bg-cyan-50 text-cyan-600" }
        ];
      case "facilities":
        return [
          { label: "机电设施统计", value: "156", icon: Zap, color: "bg-yellow-50 text-yellow-600" },
          { label: "电梯总数", value: "89", icon: Building2, color: "bg-indigo-50 text-indigo-600" },
          { label: "机房总数", value: "34", icon: FileText, color: "bg-pink-50 text-pink-600" }
        ];
      case "it":
        return [
          { label: "IT设备统计数量", value: "2,456", icon: Wifi, color: "bg-teal-50 text-teal-600" },
          { label: "AP设备总数", value: "445", icon: Wifi, color: "bg-emerald-50 text-emerald-600" },
          { label: "网口总数", value: "7,200", icon: Building2, color: "bg-lime-50 text-lime-600" }
        ];
      default:
        return [];
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "运营中":
        return "bg-green-100 text-green-800";
      case "装修中":
        return "bg-orange-100 text-orange-800";
      case "筹备中":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const renderTableHeaders = () => {
    const commonHeaders = [
      { key: "workspaceName", label: "职场名称", sticky: true },
      { key: "workspaceCode", label: "职场编号", sticky: true },
      { key: "workspaceStatus", label: "职场状态", sticky: true }
    ];

    const specificHeaders = {
      administrative: [
        { key: "is24Hours", label: "是否24小时职场" },
        { key: "hasCanteen", label: "是否供餐" },
        { key: "hasCooking", label: "是否开火" },
        { key: "canteenCount", label: "餐厅数量" },
        { key: "canteenSeats", label: "餐位数量" },
        { key: "canteenFloor", label: "餐厅楼层" },
        { key: "gymCount", label: "健身房数量" },
        { key: "gymLocation", label: "健身房位置" },
        { key: "hasAdminOnSite", label: "是否行政驻场" },
        { key: "parking", label: "停车场" },
        { key: "parkingSpaces", label: "停车位数量" }
      ],
      security: [
        { key: "hasSecurityOnSite", label: "是否安保人员驻场" },
        { key: "accessControlManager", label: "门禁管理方" },
        { key: "accessControlType", label: "门禁类型" },
        { key: "accessControlStatus", label: "门禁状态" },
        { key: "hasPropertyTurnstile", label: "是否物业闸机" }
      ],
      facilities: [
        { key: "powerType", label: "供电电源类型" },
        { key: "hvacType", label: "空调系统类型" },
        { key: "hvacCoolingDate", label: "空调制冷日期" },
        { key: "hvacHeatingDate", label: "空调供暖日期" },
        { key: "weekendHvac", label: "周末是否有空调" },
        { key: "overtimeHours", label: "可加时的时段" },
        { key: "overtimeRate", label: "空调加时收费标准" },
        { key: "elevatorInfo", label: "电梯信息" },
        { key: "passengerElevators", label: "电梯数量（台）-客梯" },
        { key: "freightElevators", label: "电梯数量（台）-货梯" },
        { key: "escalators", label: "电梯数量（台）-扶梯或其他" },
        { key: "elevatorBrand", label: "电梯品牌" },
        { key: "elevatorModel", label: "电梯型号" },
        { key: "hasMachineRoom", label: "有无电梯机房" },
        { key: "elevatorAge", label: "使用年限（年）" },
        { key: "elevatorManager", label: "电梯管理方" },
        { key: "machineRoomCount", label: "各类机房数量" }
      ],
      it: [
        { key: "apCount", label: "AP数量" },
        { key: "networkPorts", label: "网口数量" }
      ]
    };

    return [...commonHeaders, ...specificHeaders[activeTab] || []];
  };

  const renderTableCell = (record: any, header: any) => {
    const value = record[header.key];
    const isSticky = header.sticky;
    
    if (header.key === "workspaceName") {
      return (
        <TableCell key={header.key} className={`text-xs text-blue-600 font-medium cursor-pointer hover:text-blue-800 ${isSticky ? 'sticky left-0 bg-white z-10' : ''}`}>
          {value}
        </TableCell>
      );
    }
    
    if (header.key === "workspaceStatus") {
      return (
        <TableCell key={header.key} className={`text-xs ${isSticky ? 'sticky left-32 bg-white z-10' : ''}`}>
          <Badge variant="secondary" className={`${getStatusColor(value)} text-xs px-2 py-1 font-normal`}>
            {value}
          </Badge>
        </TableCell>
      );
    }

    return (
      <TableCell key={header.key} className={`text-xs text-gray-900 ${isSticky ? 'sticky left-16 bg-white z-10' : ''}`}>
        {value || "-"}
      </TableCell>
    );
  };

  const currentStats = getTabStats(activeTab);

  return (
    <div className="space-y-4">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-medium">楼宇运营信息</h1>
        <div className="flex items-center gap-2">
          <Button size="sm" className="h-7 text-xs bg-blue-600 text-white hover:bg-blue-700">
            <Download className="h-3 w-3 mr-1" />
            导出数据
          </Button>
        </div>
      </div>

      {/* 筛选区 */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative">
          <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-3 w-3 text-muted-foreground" />
          <Input 
            placeholder="职场名称/编号..." 
            className="w-40 h-7 text-xs pl-7"
          />
        </div>
        
        <Select defaultValue="all-status">
          <SelectTrigger className="w-28 h-7 text-xs">
            <SelectValue placeholder="状态" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all-status">全部状态</SelectItem>
            <SelectItem value="operating">运营中</SelectItem>
            <SelectItem value="decoration">装修中</SelectItem>
            <SelectItem value="planning">筹备中</SelectItem>
          </SelectContent>
        </Select>

        <Button variant="outline" size="sm" className="h-7 text-xs text-red-600 hover:text-red-700">
          重置筛选
        </Button>
      </div>

      {/* 主内容区 */}
      <Card className="bg-white border border-gray-200">
        <CardContent className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-fit grid-cols-4 mb-6">
              <TabsTrigger value="administrative" className="text-xs">行政信息</TabsTrigger>
              <TabsTrigger value="security" className="text-xs">物理安全</TabsTrigger>
              <TabsTrigger value="facilities" className="text-xs">机电设施</TabsTrigger>
              <TabsTrigger value="it" className="text-xs">IT设施</TabsTrigger>
            </TabsList>

            {/* 统计区域 */}
            <div className="grid grid-cols-3 gap-6 mb-6">
              {currentStats.map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <div key={index} className={`${stat.color.replace('text-', 'bg-').replace('-600', '-50')} rounded-lg p-4 text-center`}>
                    <div className="flex items-center justify-center gap-3">
                      <div className={`w-12 h-12 ${stat.color.replace('text-', 'bg-').replace('-600', '-100')} rounded-lg flex items-center justify-center`}>
                        <Icon className={`h-6 w-6 ${stat.color}`} />
                      </div>
                      <div>
                        <div className="text-2xl font-medium text-gray-900">{stat.value}</div>
                        <div className="text-sm text-gray-600">{stat.label}</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>



            {/* 表格内容 */}
            {["administrative", "security", "facilities", "it"].map((tabId) => (
              <TabsContent key={tabId} value={tabId} className="mt-0">
                <div className="rounded-md border overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-gray-50">
                        {renderTableHeaders().map((header) => (
                          <TableHead 
                            key={header.key} 
                            className={`text-xs font-medium text-gray-700 h-10 min-w-24 ${
                              header.sticky ? 'sticky top-0 bg-gray-50 z-20' : ''
                            } ${
                              header.key === 'workspaceName' ? 'left-0' : 
                              header.key === 'workspaceCode' ? 'left-16' : 
                              header.key === 'workspaceStatus' ? 'left-32' : ''
                            }`}
                          >
                            {header.label}
                          </TableHead>
                        ))}
                        <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {workspaceData.map((record) => (
                        <TableRow key={record.id} className="hover:bg-gray-50">
                          {renderTableHeaders().map((header) => renderTableCell(record, header))}
                          <TableCell className="text-xs">
                            <Button variant="link" size="sm" className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800">
                              编辑
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                <TablePagination
                  total={totalItems}
                  currentPage={currentPage}
                  pageSize={pageSize}
                  onPageChange={setCurrentPage}
                  onPageSizeChange={setPageSize}
                />
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}