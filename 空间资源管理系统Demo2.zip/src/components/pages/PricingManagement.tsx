import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { TablePagination } from "../ui/table-pagination";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../ui/dialog";
import { Label } from "../ui/label";
import { Switch } from "../ui/switch";
import { Search, Plus, Download, Edit, History, X, Trash2 } from "lucide-react";

interface Product {
  id: string;
  propertyZone: string;
  country: string;
  city: string;
  pricingPolicy: string;
  pricingProject: string;
  pricingApplicablePeriod: string;
  attribute: string;
  category: string;
  name: string;
  status: boolean;
  regions: string[];
  businessType: string;
  billingRule: string;
  billingUnit: string;
  billingDescription: string;
  updater: string;
  updateTime: string;
  // 商品详情信息
  productId: string;
  listingTime: string;
  nature: string;
  level1: string;
  level2: string;
  level3: string;
  location: string;
  relatedProduct: string;
  source: string;
  assetType: string;
  description: string;
  contact: string;
  budgetLevel1: string;
  budgetLevel2: string;
  pricingMode: string;
  participateBilling: boolean;
  unitPrice: number;
  priceUnit: string;
  currency: string;
  unitPriceUnit: string;
  billingTimeType: string;
  monthlyBilling: number;
  cumulativeBillingTime: number;
  usageBillingMethod: string;
  billingUsage: number;
  usageUnit: string;
  availableRegions: string[];
  availableDepartments: string[];
}

interface ChangeRecord {
  id: string;
  propertyZone: string;
  country: string;
  city: string;
  pricingPolicy: string;
  pricingProject: string;
  pricingApplicablePeriod: string;
  attribute: string;
  category: string;
  name: string;
  status: boolean;
  regions: string[];
  businessType: string;
  billingRule: string;
  billingUnit: string;
  billingDescription: string;
  operator: string;
  operateTime: string;
  changeType: string;
  oldValue: string;
  newValue: string;
}

interface PricingManagementContentProps {
  onNavigate?: (page: string, data?: any) => void;
}

export function PricingManagementContent({ onNavigate }: PricingManagementContentProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [searchQuery, setSearchQuery] = useState("");
  const [productType, setProductType] = useState("all");
  const [selectedWorkArea, setSelectedWorkArea] = useState("all");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);
  
  // 价格变更记录的状态
  const [changeCurrentPage, setChangeCurrentPage] = useState(1);
  const [changeSearchQuery, setChangeSearchQuery] = useState("");
  const [changeProductType, setChangeProductType] = useState("all");
  const [changeWorkArea, setChangeWorkArea] = useState("all");
  const [changeRegion, setChangeRegion] = useState("all");
  const [changeOperator, setChangeOperator] = useState("");

  const totalItems = 245;
  const changeTotalItems = 892;

  // 模拟商品数据
  const productsData: Product[] = [
    {
      id: "1",
      propertyZone: "华北区",
      country: "中国",
      city: "北京",
      pricingPolicy: "标准定价策略",
      pricingProject: "办公空间定价",
      pricingApplicablePeriod: "2025-01-01至2025-12-31",
      attribute: "标准",
      category: "工位",
      name: "普通挡板工位",
      status: true,
      regions: ["北京", "上海"],
      businessType: "办公空间",
      billingRule: "按用量和时间收费",
      billingUnit: "元/个/月",
      billingDescription: "标准办公工位日租金",
      updater: "张三",
      updateTime: "2025-01-15 14:30",
      productId: "WS-001",
      listingTime: "2025-01-01 00:00",
      nature: "物理资产",
      level1: "办公空间",
      level2: "工位",
      level3: "标准工位",
      location: "北京-总部大厦-A座-12楼",
      relatedProduct: "会议室预订",
      source: "资产管理系统",
      assetType: "固定资产",
      description: "标准配置办公工位，包含办公桌椅、电源、网络接口",
      contact: "李经理",
      budgetLevel1: "运营成本",
      budgetLevel2: "办公场所费",
      pricingMode: "固定定价",
      participateBilling: true,
      unitPrice: 180,
      priceUnit: "元/天/个",
      currency: "CNY",
      unitPriceUnit: "个",
      billingTimeType: "分配日期-退租日期",
      monthlyBilling: 30,
      cumulativeBillingTime: 365,
      usageBillingMethod: "已分配数量",
      billingUsage: 1,
      usageUnit: "个",
      availableRegions: ["北京", "上海", "深圳"],
      availableDepartments: ["技术部", "产品部", "运营部"]
    },
    {
      id: "2",
      propertyZone: "华东区",
      country: "中国",
      city: "上海",
      pricingPolicy: "动态定价策略",
      pricingProject: "会议室服务定价",
      pricingApplicablePeriod: "2025-01-01至2025-06-30",
      attribute: "高级",
      category: "空间",
      name: "高级会议室-上海分公司",
      status: true,
      regions: ["上海"],
      businessType: "会议服务",
      billingRule: "按小时计费",
      billingUnit: "元/小时",
      billingDescription: "高级会议室时租金",
      updater: "王五",
      updateTime: "2025-01-12 09:15",
      productId: "MR-002",
      listingTime: "2025-01-02 00:00",
      nature: "服务资源",
      level1: "会议空间",
      level2: "会议室",
      level3: "高级会议室",
      location: "上海-分公司大厦-B座-8楼",
      relatedProduct: "投影设备租赁",
      source: "会议管理系统",
      assetType: "服务资产",
      description: "配备高清投影、音响设备的高级会议室",
      contact: "陈经理",
      budgetLevel1: "运营成本",
      budgetLevel2: "会议服务费",
      pricingMode: "动态定价",
      participateBilling: true,
      unitPrice: 300,
      priceUnit: "元/小时",
      currency: "CNY",
      unitPriceUnit: "小时",
      billingTimeType: "预约日期-使用日期",
      monthlyBilling: 22,
      cumulativeBillingTime: 264,
      usageBillingMethod: "已分配数量",
      billingUsage: 1,
      usageUnit: "个",
      availableRegions: ["上海", "杭州"],
      availableDepartments: ["销售部", "市场部", "管理层"]
    },
    {
      id: "3",
      propertyZone: "华南区",
      country: "中国",
      city: "深圳",
      pricingPolicy: "固定定价策略",
      pricingProject: "运营服务定价",
      pricingApplicablePeriod: "2025-01-01至2025-12-31",
      attribute: "标准",
      category: "运营",
      name: "Day2改造服务",
      status: false,
      regions: ["深圳"],
      businessType: "运营服务",
      billingRule: "按项目计费",
      billingUnit: "元/项目",
      billingDescription: "办公区域改造服务",
      updater: "赵六",
      updateTime: "2025-01-10 16:45",
      productId: "SV-003",
      listingTime: "2025-01-03 00:00",
      nature: "服务资源",
      level1: "运营服务",
      level2: "清洁服务",
      level3: "日��清洁",
      location: "深圳-科技园-C座-全楼层",
      relatedProduct: "绿植维护",
      source: "运营管理系统",
      assetType: "服务资产",
      description: "包含日常清洁、垃圾处理、设施维护",
      contact: "周经理",
      budgetLevel1: "运营成本",
      budgetLevel2: "物业管理费",
      pricingMode: "固定定价",
      participateBilling: false,
      unitPrice: 8000,
      priceUnit: "元/月",
      currency: "CNY",
      unitPriceUnit: "月",
      billingTimeType: "自然月",
      monthlyBilling: 12,
      cumulativeBillingTime: 12,
      usageBillingMethod: "已分配数量",
      billingUsage: 1,
      usageUnit: "项目",
      availableRegions: ["深圳"],
      availableDepartments: ["全部门"]
    },
    {
      id: "4",
      propertyZone: "全国",
      country: "中国",
      city: "全国",
      pricingPolicy: "阶梯定价策略",
      pricingProject: "技术服务定价",
      pricingApplicablePeriod: "2025-01-01至2025-12-31",
      attribute: "增值",
      category: "服务",
      name: "人力外包服务",
      status: true,
      regions: ["北京", "上海", "深圳", "广州"],
      businessType: "人力服务",
      billingRule: "按人天计费",
      billingUnit: "元/人/天",
      billingDescription: "专业人力外包服务",
      updater: "孙七",
      updateTime: "2025-01-08 11:20",
      productId: "HR-004",
      listingTime: "2025-01-04 00:00",
      nature: "服务资源",
      level1: "技术服务",
      level2: "IT支持",
      level3: "现场服务",
      location: "全国-各办公区域",
      relatedProduct: "设备维护",
      source: "服务管理系统",
      assetType: "服务资产",
      description: "提供现场IT问题解决、设备调试等技术支持",
      contact: "吴经理",
      budgetLevel1: "运营成本",
      budgetLevel2: "技术服务费",
      pricingMode: "阶梯定价",
      participateBilling: true,
      unitPrice: 500,
      priceUnit: "元/次",
      currency: "CNY",
      unitPriceUnit: "次",
      billingTimeType: "签约日期-合同到期日期",
      monthlyBilling: 22,
      cumulativeBillingTime: 264,
      usageBillingMethod: "已分配数量",
      billingUsage: 1,
      usageUnit: "人",
      availableRegions: ["北京", "上海", "深圳", "广州", "杭州"],
      availableDepartments: ["全部门"]
    }
  ];

  // 模拟价格变更记录数据
  const changeRecordsData: ChangeRecord[] = [
    {
      id: "1",
      propertyZone: "华北区",
      country: "中国",
      city: "北京",
      pricingPolicy: "标准定价策略",
      pricingProject: "办公空间���价",
      pricingApplicablePeriod: "2025-01-01至2025-12-31",
      attribute: "标准",
      category: "工位",
      name: "标准工位-北京总部",
      status: true,
      regions: ["北京", "上海"],
      businessType: "办公空间",
      billingRule: "按天计费",
      billingUnit: "元/天/个",
      billingDescription: "标准办公工位日租金",
      operator: "张三",
      operateTime: "2025-01-15 14:30",
      changeType: "价格调整",
      oldValue: "150元/天/个",
      newValue: "180元/天/个"
    },
    {
      id: "2",
      propertyZone: "华东区",
      country: "中国",
      city: "上海",
      pricingPolicy: "动态定价策略",
      pricingProject: "会议室服务定价",
      pricingApplicablePeriod: "2025-01-01至2025-06-30",
      attribute: "高级",
      category: "空间",
      name: "高级会议室-上海分公司",
      status: true,
      regions: ["上海"],
      businessType: "会议服务",
      billingRule: "按小时计费",
      billingUnit: "元/小时",
      billingDescription: "高级会议室时租金",
      operator: "王五",
      operateTime: "2025-01-12 09:15",
      changeType: "状态变更",
      oldValue: "停用",
      newValue: "启用"
    },
    {
      id: "3",
      propertyZone: "华南区",
      country: "中国",
      city: "深圳",
      pricingPolicy: "固定定价策略",
      pricingProject: "运营服务定价",
      pricingApplicablePeriod: "2025-01-01至2025-12-31",
      attribute: "标准",
      category: "运营",
      name: "清洁服务-深圳办公区",
      status: false,
      regions: ["深圳"],
      businessType: "运营服务",
      billingRule: "按月计费",
      billingUnit: "元/月",
      billingDescription: "办公区域清洁维护服务",
      operator: "赵六",
      operateTime: "2025-01-10 16:45",
      changeType: "区域调整",
      oldValue: "深圳、东莞",
      newValue: "深圳"
    }
  ];

  const openProductDetail = (product: Product) => {
    setSelectedProduct(product);
    setIsDetailDialogOpen(true);
  };

  const closeProductDetail = () => {
    setSelectedProduct(null);
    setIsDetailDialogOpen(false);
  };

  return (
    <div className="space-y-4" style={{ maxWidth: '1300px', margin: '0 auto' }}>
      {/* 页面标题 */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-[15px]">定价管理</h1>
        </div>
        <div className="flex items-center gap-3">
          <Button 
            variant="outline"
            className="text-blue-600 border-blue-600 hover:bg-blue-50"
            onClick={() => {
              console.log("定价小工具按钮被点击");
              onNavigate?.("pricing-calculator");
            }}
          >
            定价小工具
          </Button>
          <Button 
            className="bg-blue-600 hover:bg-blue-700 text-white"
            onClick={() => {
              console.log("空间SKU管理按钮被点击");
              onNavigate?.("space-sku-management");
            }}
          >
            空间SKU管理
          </Button>
        </div>
      </div>

      <Tabs defaultValue="price-management" className="w-full">
        <TabsList className="grid w-fit grid-cols-2">
          <TabsTrigger value="price-management">价格管理</TabsTrigger>
          <TabsTrigger value="price-change-records">价格变更记录</TabsTrigger>
        </TabsList>

        {/* Tab 1: 价格管理 */}
        <TabsContent value="price-management" className="space-y-4">
          <Card className="p-[0px] mx-[0px] my-[21px]">
            <CardHeader className="pb-3">


              {/* 筛选区域 */}
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/30">
                <div className="relative flex-1 max-w-80">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="模糊搜索商品名称、商品ID..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 h-8"
                  />
                </div>
                
                <Select value={productType} onValueChange={setProductType}>
                  <SelectTrigger className="w-32 h-8">
                    <SelectValue placeholder="商品类型" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部类型</SelectItem>
                    <SelectItem value="workstation">工位</SelectItem>
                    <SelectItem value="space">空间</SelectItem>
                    <SelectItem value="operation">运营</SelectItem>
                    <SelectItem value="service">服务</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={selectedWorkArea} onValueChange={setSelectedWorkArea}>
                  <SelectTrigger className="w-36 h-8">
                    <SelectValue placeholder="选择工区" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部工区</SelectItem>
                    <SelectItem value="WA-BJ001">北京总部工区</SelectItem>
                    <SelectItem value="WA-SH002">上海分公司工区</SelectItem>
                    <SelectItem value="WA-SZ003">深圳科技园工区</SelectItem>
                    <SelectItem value="WA-GZ004">广州天河工区</SelectItem>
                  </SelectContent>
                </Select>

                <Button variant="outline" size="sm" className="h-8">
                  筛选
                </Button>
                
                <Button variant="outline" size="sm" className="h-8">
                  <Download className="h-4 w-4 mr-1" />
                  导出
                </Button>
              </div>
            </CardHeader>

            <CardContent>
              {/* 商品���表表格 */}
              <div className="border rounded-lg overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="min-w-[100px]">定价年度</TableHead>
                      <TableHead className="min-w-[100px]">定价月份</TableHead>
                      <TableHead className="min-w-[100px]">房产分区</TableHead>
                      <TableHead className="min-w-[80px]">国家</TableHead>
                      <TableHead className="min-w-[80px]">城市</TableHead>
                      <TableHead className="min-w-[100px]">工区编码</TableHead>
                      <TableHead className="min-w-[120px]">工区名称</TableHead>
                      <TableHead className="min-w-[100px]">工区楼层</TableHead>
                      <TableHead className="min-w-[100px]">楼层状态</TableHead>
                      <TableHead className="min-w-[100px]">属性</TableHead>
                      <TableHead className="min-w-[120px]">商品大类</TableHead>
                      <TableHead className="min-w-[100px]">商品类型</TableHead>
                      <TableHead className="min-w-[100px]">商品ID</TableHead>
                      <TableHead className="min-w-[150px]">商品SKU名称</TableHead>
                      <TableHead className="min-w-[120px]">定价方式</TableHead>
                      <TableHead className="min-w-[100px]">单价</TableHead>
                      <TableHead className="min-w-[120px]">计价单位-P</TableHead>
                      <TableHead className="min-w-[120px]">用量计费方式-Q</TableHead>
                      <TableHead className="min-w-[100px]">用量单位-Q</TableHead>
                      <TableHead className="min-w-[140px]">计费时间类型-T</TableHead>
                      <TableHead className="min-w-[140px]">定价有效期</TableHead>
                      <TableHead className="min-w-[120px]">默认货币类型</TableHead>
                      <TableHead className="min-w-[120px]">折扣策略</TableHead>
                      <TableHead className="min-w-[120px]">计费策略</TableHead>
                      <TableHead className="min-w-[120px]">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {productsData.map((product) => (
                      <TableRow key={product.id} className="hover:bg-muted/30">
                        <TableCell>2025</TableCell>
                        <TableCell>08月</TableCell>
                        <TableCell>{product.propertyZone}</TableCell>
                        <TableCell>{product.country}</TableCell>
                        <TableCell>{product.city}</TableCell>
                        <TableCell>{product.id === "1" ? "WA-BJ001" : product.id === "2" ? "WA-SH002" : product.id === "3" ? "WA-SZ003" : "WA-GZ004"}</TableCell>
                        <TableCell>{product.id === "1" ? "北京总部工区" : product.id === "2" ? "上海分公司工区" : product.id === "3" ? "深圳科技园工区" : "广州天河工区"}</TableCell>
                        <TableCell>{product.id === "1" ? "12F" : product.id === "2" ? "8F" : product.id === "3" ? "全楼层" : "15F"}</TableCell>
                        <TableCell>
                          <Badge variant={product.status ? "default" : "secondary"} className={
                            product.status ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                          }>
                            {product.status ? "启用" : "停用"}
                          </Badge>
                        </TableCell>
                        <TableCell>{product.attribute === "标准" ? "资源类" : product.attribute === "高级" ? "服务类" : "人力类"}</TableCell>
                        <TableCell>{product.category === "工位" ? "资源类-工位" : product.category === "空间" ? "资源类-会议协作" : product.category === "运营" ? "服务类-Day2改造" : "服务类-新交付装修"}</TableCell>
                        <TableCell>{product.category}</TableCell>
                        <TableCell>{product.productId}</TableCell>
                        <TableCell>
                          <Button 
                            variant="link" 
                            className="p-0 h-auto text-blue-600 hover:text-blue-800"
                            onClick={() => onNavigate?.("product-details", { productId: product.productId })}
                          >
                            {product.name}
                          </Button>
                        </TableCell>
                        <TableCell>{product.billingRule}</TableCell>
                        <TableCell className="text-blue-600">¥{product.unitPrice.toLocaleString()}</TableCell>
                        <TableCell>{product.priceUnit}</TableCell>
                        <TableCell>{product.usageBillingMethod}</TableCell>
                        <TableCell>{product.usageUnit}</TableCell>
                        <TableCell>{product.billingTimeType}</TableCell>
                        <TableCell>20230101-20291231</TableCell>
                        <TableCell>RMB</TableCell>
                        <TableCell>按量折扣</TableCell>
                        <TableCell>成本定价-折扣</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 text-blue-600 hover:text-blue-800 hover:bg-blue-50"
                              onClick={() => {
                                console.log("编辑商品:", product.id);
                                onNavigate?.("pricing-product-edit", { productId: product.id });
                              }}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 text-red-600 hover:text-red-800 hover:bg-red-50"
                              onClick={() => {
                                console.log("删除商品:", product.id);
                                // 这里可以添加删除逻辑
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <TablePagination
                total={totalItems}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 2: 价格变更记录 */}
        <TabsContent value="price-change-records" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">


              {/* 筛选区域 */}
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/30">
                <div className="relative flex-1 max-w-80">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="模糊搜索商品名称、商品ID..."
                    value={changeSearchQuery}
                    onChange={(e) => setChangeSearchQuery(e.target.value)}
                    className="pl-10 h-8"
                  />
                </div>
                
                <Select value={changeProductType} onValueChange={setChangeProductType}>
                  <SelectTrigger className="w-32 h-8">
                    <SelectValue placeholder="商品类型" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部类型</SelectItem>
                    <SelectItem value="workstation">工位</SelectItem>
                    <SelectItem value="space">空间</SelectItem>
                    <SelectItem value="operation">运营</SelectItem>
                    <SelectItem value="service">服务</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={changeWorkArea} onValueChange={setChangeWorkArea}>
                  <SelectTrigger className="w-36 h-8">
                    <SelectValue placeholder="选择工区" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部工区</SelectItem>
                    <SelectItem value="WA-BJ001">北京总部工区</SelectItem>
                    <SelectItem value="WA-SH002">上海分公司工区</SelectItem>
                    <SelectItem value="WA-SZ003">深圳科技园工区</SelectItem>
                    <SelectItem value="WA-GZ004">广州天河工区</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={changeRegion} onValueChange={setChangeRegion}>
                  <SelectTrigger className="w-32 h-8">
                    <SelectValue placeholder="所属区域" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部区域</SelectItem>
                    <SelectItem value="beijing">北京</SelectItem>
                    <SelectItem value="shanghai">上海</SelectItem>
                    <SelectItem value="shenzhen">深圳</SelectItem>
                    <SelectItem value="guangzhou">广州</SelectItem>
                  </SelectContent>
                </Select>

                <Input
                  placeholder="操作人"
                  value={changeOperator}
                  onChange={(e) => setChangeOperator(e.target.value)}
                  className="w-32 h-8"
                />

                <Button variant="outline" size="sm" className="h-8">
                  筛选
                </Button>
                
                <Button variant="outline" size="sm" className="h-8">
                  <Download className="h-4 w-4 mr-1" />
                  导出
                </Button>
              </div>
            </CardHeader>

            <CardContent>
              {/* 变更记录表格 */}
              <div className="border rounded-lg overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="min-w-[100px]">房产分区</TableHead>
                      <TableHead className="min-w-[80px]">国家</TableHead>
                      <TableHead className="min-w-[80px]">城市</TableHead>
                      <TableHead className="min-w-[120px]">定价政策</TableHead>
                      <TableHead className="min-w-[120px]">定价项目</TableHead>
                      <TableHead className="min-w-[160px]">定价适用期间</TableHead>
                      <TableHead className="min-w-[80px]">属性</TableHead>
                      <TableHead className="min-w-[100px]">商品分类</TableHead>
                      <TableHead className="min-w-[200px]">名称</TableHead>
                      <TableHead className="min-w-[100px]">状态</TableHead>
                      <TableHead className="min-w-[140px]">所属区域</TableHead>
                      <TableHead className="min-w-[100px]">业务类型</TableHead>
                      <TableHead className="min-w-[120px]">计费规则</TableHead>
                      <TableHead className="min-w-[100px]">计费单位</TableHead>
                      <TableHead className="min-w-[180px]">计费说明</TableHead>
                      <TableHead className="min-w-[100px]">变更类型</TableHead>
                      <TableHead className="min-w-[120px]">变更前</TableHead>
                      <TableHead className="min-w-[120px]">变更后</TableHead>
                      <TableHead className="min-w-[80px]">操作人</TableHead>
                      <TableHead className="min-w-[120px]">操作时间</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {changeRecordsData.map((record) => (
                      <TableRow key={record.id} className="hover:bg-muted/30">
                        <TableCell>{record.propertyZone}</TableCell>
                        <TableCell>{record.country}</TableCell>
                        <TableCell>{record.city}</TableCell>
                        <TableCell>{record.pricingPolicy}</TableCell>
                        <TableCell>{record.pricingProject}</TableCell>
                        <TableCell>{record.pricingApplicablePeriod}</TableCell>
                        <TableCell>{record.attribute}</TableCell>
                        <TableCell>{record.category}</TableCell>
                        <TableCell>{record.name}</TableCell>
                        <TableCell>
                          <Badge variant={record.status ? "default" : "secondary"} className={
                            record.status ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                          }>
                            {record.status ? "启用" : "停用"}
                          </Badge>
                        </TableCell>
                        <TableCell>{record.regions.join("、")}</TableCell>
                        <TableCell>{record.businessType}</TableCell>
                        <TableCell>{record.billingRule}</TableCell>
                        <TableCell>{record.billingUnit}</TableCell>
                        <TableCell>{record.billingDescription}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={
                            record.changeType === "价格调整" ? "border-blue-200 text-blue-800" :
                            record.changeType === "状态变更" ? "border-green-200 text-green-800" :
                            "border-orange-200 text-orange-800"
                          }>
                            {record.changeType}
                          </Badge>
                        </TableCell>
                        <TableCell className="max-w-[120px] truncate">{record.oldValue}</TableCell>
                        <TableCell className="max-w-[120px] truncate">{record.newValue}</TableCell>
                        <TableCell>{record.operator}</TableCell>
                        <TableCell>{record.operateTime}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <TablePagination
                total={changeTotalItems}
                currentPage={changeCurrentPage}
                pageSize={pageSize}
                onPageChange={setChangeCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* 商品详情弹窗 */}
      <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <DialogTitle>商品详情 - {selectedProduct?.name}</DialogTitle>
              <Button variant="ghost" size="sm" onClick={closeProductDetail}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogHeader>

          {selectedProduct && (
            <div className="space-y-6">
              {/* 基本信息 */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-medium mb-4">基本信息</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div>
                      <Label>商品ID</Label>
                      <div className="mt-1">{selectedProduct.productId}</div>
                    </div>
                    <div>
                      <Label>商品名称</Label>
                      <div className="mt-1">{selectedProduct.name}</div>
                    </div>
                    <div>
                      <Label>状态</Label>
                      <div className="mt-1">
                        <Badge variant={selectedProduct.status ? "default" : "secondary"} className={
                          selectedProduct.status ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                        }>
                          {selectedProduct.status ? "启用" : "停用"}
                        </Badge>
                      </div>
                    </div>
                    <div>
                      <Label>上架时间</Label>
                      <div className="mt-1">{selectedProduct.listingTime}</div>
                    </div>
                    <div>
                      <Label>性质</Label>
                      <div className="mt-1">{selectedProduct.nature}</div>
                    </div>
                    <div>
                      <Label>商品-1级</Label>
                      <div className="mt-1">{selectedProduct.level1}</div>
                    </div>
                    <div>
                      <Label>商品-2级</Label>
                      <div className="mt-1">{selectedProduct.level2}</div>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <Label>商品-3级</Label>
                      <div className="mt-1">{selectedProduct.level3}</div>
                    </div>
                    <div>
                      <Label>商品位置</Label>
                      <div className="mt-1">{selectedProduct.location}</div>
                    </div>
                    <div>
                      <Label>关联产品</Label>
                      <div className="mt-1">{selectedProduct.relatedProduct}</div>
                    </div>
                    <div>
                      <Label>商品来源</Label>
                      <div className="mt-1">{selectedProduct.source}</div>
                    </div>
                    <div>
                      <Label>资产类��</Label>
                      <div className="mt-1">{selectedProduct.assetType}</div>
                    </div>
                    <div>
                      <Label>描述</Label>
                      <div className="mt-1">{selectedProduct.description}</div>
                    </div>
                    <div>
                      <Label>对接人</Label>
                      <div className="mt-1">{selectedProduct.contact}</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* 预算信息 */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-medium mb-4">预算信息</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>预算科目-1级</Label>
                    <div className="mt-1">{selectedProduct.budgetLevel1}</div>
                  </div>
                  <div>
                    <Label>预算科目-2级</Label>
                    <div className="mt-1">{selectedProduct.budgetLevel2}</div>
                  </div>
                </div>
              </div>

              {/* 定价信息 */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-medium mb-4">定价信息</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div>
                      <Label>定价方式（计费模式）</Label>
                      <div className="mt-1">{selectedProduct.pricingMode}</div>
                    </div>
                    <div>
                      <Label>是否参与计费</Label>
                      <div className="mt-1">
                        <Badge variant={selectedProduct.participateBilling ? "default" : "secondary"}>
                          {selectedProduct.participateBilling ? "是" : "否"}
                        </Badge>
                      </div>
                    </div>
                    <div>
                      <Label>单价</Label>
                      <div className="mt-1">{selectedProduct.unitPrice}</div>
                    </div>
                    <div>
                      <Label>（元/天/个）</Label>
                      <div className="mt-1">{selectedProduct.priceUnit}</div>
                    </div>
                    <div>
                      <Label>货币类型</Label>
                      <div className="mt-1">{selectedProduct.currency}</div>
                    </div>
                    <div>
                      <Label>单价单位</Label>
                      <div className="mt-1">{selectedProduct.unitPriceUnit}</div>
                    </div>
                    <div>
                      <Label>计费时间类型</Label>
                      <div className="mt-1">{selectedProduct.billingTimeType}</div>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <Label>当月计费</Label>
                      <div className="mt-1">{selectedProduct.monthlyBilling}天</div>
                    </div>
                    <div>
                      <Label>累计计费时间</Label>
                      <div className="mt-1">{selectedProduct.cumulativeBillingTime}天</div>
                    </div>
                    <div>
                      <Label>用量计费方式</Label>
                      <div className="mt-1">{selectedProduct.usageBillingMethod}</div>
                    </div>
                    <div>
                      <Label>计费用量</Label>
                      <div className="mt-1">{selectedProduct.billingUsage}</div>
                    </div>
                    <div>
                      <Label>用量单位</Label>
                      <div className="mt-1">{selectedProduct.usageUnit}</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* 开放范围 */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h3 className="font-medium mb-4">开放范围</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>可售区域</Label>
                    <div className="mt-1">{selectedProduct.availableRegions.join("、")}</div>
                  </div>
                  <div>
                    <Label>可售部门</Label>
                    <div className="mt-1">{selectedProduct.availableDepartments.join("、")}</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}