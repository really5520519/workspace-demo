import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "../ui/breadcrumb";
import { Calendar } from "../ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "../ui/popover";
import { Textarea } from "../ui/textarea";
import { 
  Edit, 
  Save, 
  X,
  Check,
  Calendar as CalendarIcon,
  ArrowLeft,
  User,
  Building,
  Users
} from "lucide-react";
import { cn } from "../ui/utils";

interface ProductDetailsProps {
  productId?: string;
  onNavigateBack: () => void;
}

export function ProductDetailsContent({ productId = "PEK238457103712", onNavigateBack }: ProductDetailsProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState("requirement");
  
  // 表单状态
  const [formData, setFormData] = useState({
    nature: "预算内",
    type: "新工区", 
    resource: "工位",
    startDate: new Date(2025, 2, 1),
    endDate: new Date(2025, 11, 31),
    quantity: 50,
    workspaceFee: 150000,
    spaceFee: 80000,
    operationFee: 25000,
    otherFee: 15000
  });

  const [startDateOpen, setStartDateOpen] = useState(false);
  const [endDateOpen, setEndDateOpen] = useState(false);

  const totalFee = formData.workspaceFee + formData.spaceFee + formData.operationFee + formData.otherFee;

  const handleSave = () => {
    setIsEditing(false);
    // 保存逻辑
  };

  const handleCancel = () => {
    setIsEditing(false);
    // 恢复原始数据
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('zh-CN');
  };

  return (
    <div className="flex-1 space-y-6 p-6" style={{ maxWidth: '1300px', margin: '0 auto' }}>
      {/* 面包屑导航 */}
      <Breadcrumb>
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink 
              href="#" 
              onClick={(e) => {
                e.preventDefault();
                onNavigateBack();
              }}
              className="text-blue-600 hover:text-blue-800"
            >
              定价管理
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbPage>项目详情</BreadcrumbPage>
        </BreadcrumbList>
      </Breadcrumb>

      {/* 编辑模式顶栏 */}
      {isEditing && (
        <div className="flex items-center justify-center gap-2 p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <Button
            size="sm"
            onClick={handleSave}
            className="h-8 bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Check className="h-4 w-4 mr-1" />
            提交
          </Button>
          <Button
            size="sm"
            onClick={handleSave}
            variant="outline"
            className="h-8 border-blue-600 text-blue-600 hover:bg-blue-50"
          >
            <Save className="h-4 w-4 mr-1" />
            保存
          </Button>
          <Button
            size="sm"
            onClick={handleCancel}
            variant="outline"
            className="h-8"
          >
            <X className="h-4 w-4 mr-1" />
            取消
          </Button>
        </div>
      )}

      {/* 顶部标题和操作按钮 */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={onNavigateBack}
            className="text-gray-600 hover:text-gray-800"
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            返回
          </Button>
          <h1>标准工位-北京总部（ID：{productId}）</h1>
        </div>
        
        {!isEditing && (
          <Button
            size="sm"
            onClick={() => setIsEditing(true)}
            variant="outline"
            className="h-8 border-blue-600 text-blue-600 hover:bg-blue-50"
          >
            <Edit className="h-4 w-4 mr-1" />
            编辑
          </Button>
        )}
      </div>

      {/* 基础卡片区（灰色底色）- 横向3个 */}
      <div className="grid grid-cols-3 gap-4">
        {/* 申请人信息 */}
        <Card className="bg-gray-50">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <User className="h-4 w-4" />
              申请人信息
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-600">申请人</span>
              <span className="font-medium">张三</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">部门</span>
              <span>产品研发部</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">联系方式</span>
              <span>zhangsan@company.com</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">申请时间</span>
              <span>2025-01-15</span>
            </div>
          </CardContent>
        </Card>
        
        {/* 项目场地信息 */}
        <Card className="bg-gray-50">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Building className="h-4 w-4" />
              项目场地信息（工区楼层）
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-600">工区</span>
              <span className="font-medium">北京总部办公区</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">楼栋</span>
              <span>A座</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">楼层</span>
              <span>12楼</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">区域</span>
              <span>东区办公区域</span>
            </div>
          </CardContent>
        </Card>
        
        {/* 项目协同人 */}
        <Card className="bg-gray-50">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              项目协同人
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-600">项目经理</span>
              <span className="font-medium">李经理</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">技术负责人</span>
              <span>王工程师</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">设计师</span>
              <span>陈设计师</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">协调人</span>
              <span>赵助理</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 主要标签页内容 */}
      <Card>
        <CardContent className="p-0">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="w-full justify-start border-b rounded-none bg-transparent p-0">
              <TabsTrigger value="requirement" className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-transparent">
                需求信息
              </TabsTrigger>
              <TabsTrigger value="budget" className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-transparent">
                立项与预算
              </TabsTrigger>
              <TabsTrigger value="resources" className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-transparent">
                资源现状
              </TabsTrigger>
              <TabsTrigger value="history" className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-transparent">
                历史关联项目
              </TabsTrigger>
              <TabsTrigger value="process" className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-transparent">
                流程详情
              </TabsTrigger>
            </TabsList>

            {/* 需求信息 */}
            <TabsContent value="requirement" className="p-6 space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="block font-medium mb-2">需求性质（预算内/预算外）</label>
                    <Select value={formData.nature} onValueChange={(value) => setFormData({...formData, nature: value})} disabled={!isEditing}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="预算内">预算内</SelectItem>
                        <SelectItem value="预算外">预算外</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block font-medium mb-2">类型（新工区/已有工区）</label>
                    <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value})} disabled={!isEditing}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="新工区">新工区</SelectItem>
                        <SelectItem value="已有工区">已有工区</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block font-medium mb-2">资源（工位/空间/家具设备/改造）</label>
                    <Select value={formData.resource} onValueChange={(value) => setFormData({...formData, resource: value})} disabled={!isEditing}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="工位">工位</SelectItem>
                        <SelectItem value="空间">空间</SelectItem>
                        <SelectItem value="家具设备">家具设备</SelectItem>
                        <SelectItem value="改造">改造</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block font-medium mb-2">数量（xx个）</label>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        value={formData.quantity}
                        onChange={(e) => setFormData({...formData, quantity: parseInt(e.target.value) || 0})}
                        disabled={!isEditing}
                        className="flex-1"
                      />
                      <span className="text-gray-500">个</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block font-medium mb-2">周期（日期起-日期止）</label>
                    <div className="flex items-center gap-2">
                      <Popover open={startDateOpen} onOpenChange={setStartDateOpen}>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className={cn(
                              "justify-start text-left font-normal flex-1",
                              !formData.startDate && "text-muted-foreground"
                            )}
                            disabled={!isEditing}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {formData.startDate ? formatDate(formData.startDate) : "选择开始日期"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={formData.startDate}
                            onSelect={(date) => {
                              if (date) setFormData({...formData, startDate: date});
                              setStartDateOpen(false);
                            }}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      
                      <span className="text-gray-500">至</span>
                      
                      <Popover open={endDateOpen} onOpenChange={setEndDateOpen}>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className={cn(
                              "justify-start text-left font-normal flex-1",
                              !formData.endDate && "text-muted-foreground"
                            )}
                            disabled={!isEditing}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {formData.endDate ? formatDate(formData.endDate) : "选择结束日期"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={formData.endDate}
                            onSelect={(date) => {
                              if (date) setFormData({...formData, endDate: date});
                              setEndDateOpen(false);
                            }}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>

                  <div>
                    <label className="block font-medium mb-2">费用预估</label>
                    <Card className="bg-blue-50 border-blue-200">
                      <CardContent className="p-4 space-y-3">
                        <div className="flex justify-between items-center">
                          <span>工位费</span>
                          <span className="font-medium">{formData.workspaceFee.toLocaleString()}元</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span>空间费</span>
                          <span className="font-medium">{formData.spaceFee.toLocaleString()}元</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span>运营费</span>
                          <span className="font-medium">{formData.operationFee.toLocaleString()}元</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span>其他费</span>
                          <span className="font-medium">{formData.otherFee.toLocaleString()}元</span>
                        </div>
                        <div className="border-t pt-2">
                          <div className="flex justify-between items-center">
                            <span className="font-medium">总计</span>
                            <span className="font-bold text-lg text-blue-600">{totalFee.toLocaleString()}元</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* 立项与预算 */}
            <TabsContent value="budget" className="p-6">
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>租赁费用</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">月租金</span>
                        <span className="font-medium">50,000元</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">押金</span>
                        <span>100,000元</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">物业费</span>
                        <span>8,000元</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">停车费</span>
                        <span>2,000元</span>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>工程费用</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">装修费</span>
                        <span className="font-medium">120,000元</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">改造费</span>
                        <span>30,000元</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">维护费</span>
                        <span>5,000元</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">检测费</span>
                        <span>3,000元</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>顾问费用</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">设计费</span>
                        <span className="font-medium">25,000元</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">咨询费</span>
                        <span>15,000元</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">监理费</span>
                        <span>8,000元</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">验收费</span>
                        <span>5,000元</span>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>家具/装置/设备费用</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">办公家具</span>
                        <span className="font-medium">80,000元</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">IT设备</span>
                        <span>45,000元</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">装置费</span>
                        <span>20,000元</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">安装费</span>
                        <span>8,000元</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            {/* 资源现状 */}
            <TabsContent value="resources" className="p-6">
              <div className="space-y-6">
                <div className="grid grid-cols-4 gap-4">
                  <Card className="bg-blue-50">
                    <CardContent className="p-4 text-center">
                      <div className="font-bold text-blue-600">120</div>
                      <div className="text-gray-600">业务资源现状</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-green-50">
                    <CardContent className="p-4 text-center">
                      <div className="font-bold text-green-600">85</div>
                      <div className="text-gray-600">已申请</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-orange-50">
                    <CardContent className="p-4 text-center">
                      <div className="font-bold text-orange-600">60</div>
                      <div className="text-gray-600">已分配</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-purple-50">
                    <CardContent className="p-4 text-center">
                      <div className="font-bold text-purple-600">45</div>
                      <div className="text-gray-600">已使用</div>
                    </CardContent>
                  </Card>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>历史记录</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                        <div>
                          <div className="font-medium">资源申请</div>
                          <div className="text-gray-600">申请工位50个</div>
                        </div>
                        <div className="text-gray-500">2025-01-15</div>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                        <div>
                          <div className="font-medium">资源分配</div>
                          <div className="text-gray-600">分配工位30个</div>
                        </div>
                        <div className="text-gray-500">2025-01-18</div>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                        <div>
                          <div className="font-medium">资源使用</div>
                          <div className="text-gray-600">使用工位25个</div>
                        </div>
                        <div className="text-gray-500">2025-01-20</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* 历史关联项目 */}
            <TabsContent value="history" className="p-6">
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>审批记录</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span>初审</span>
                          <Badge variant="default" className="bg-green-100 text-green-800">已通过</Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span>复审</span>
                          <Badge variant="default" className="bg-blue-100 text-blue-800">审批中</Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span>终审</span>
                          <Badge variant="default" className="bg-gray-100 text-gray-800">待审批</Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>其他系统审批回传</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span>财务系统</span>
                          <Badge variant="default" className="bg-green-100 text-green-800">已回传</Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span>HR系统</span>
                          <Badge variant="default" className="bg-orange-100 text-orange-800">待回传</Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span>IT系统</span>
                          <Badge variant="default" className="bg-green-100 text-green-800">已回传</Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            {/* 流程详情 */}
            <TabsContent value="process" className="p-6">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>项目流程阶段</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-6 gap-4">
                      <div className="text-center">
                        <Badge variant="default" className="bg-green-100 text-green-800 mb-2 w-full">阶段1</Badge>
                        <div>需求</div>
                        <div className="text-xs text-gray-500 mt-1">已完成</div>
                      </div>
                      <div className="text-center">
                        <Badge variant="default" className="bg-blue-100 text-blue-800 mb-2 w-full">阶段2</Badge>
                        <div>租赁</div>
                        <div className="text-xs text-gray-500 mt-1">进行中</div>
                      </div>
                      <div className="text-center">
                        <Badge variant="default" className="bg-gray-100 text-gray-800 mb-2 w-full">阶段3</Badge>
                        <div>项目</div>
                        <div className="text-xs text-gray-500 mt-1">待开始</div>
                      </div>
                      <div className="text-center">
                        <Badge variant="default" className="bg-gray-100 text-gray-800 mb-2 w-full">阶段4</Badge>
                        <div>分配</div>
                        <div className="text-xs text-gray-500 mt-1">待开始</div>
                      </div>
                      <div className="text-center">
                        <Badge variant="default" className="bg-gray-100 text-gray-800 mb-2 w-full">阶段5</Badge>
                        <div>搬家</div>
                        <div className="text-xs text-gray-500 mt-1">待开始</div>
                      </div>
                      <div className="text-center">
                        <Badge variant="default" className="bg-gray-100 text-gray-800 mb-2 w-full">阶段6</Badge>
                        <div>计费</div>
                        <div className="text-xs text-gray-500 mt-1">待开始</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="grid grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>当前阶段详情</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">当前阶段</span>
                        <span className="font-medium">租赁</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">开始时间</span>
                        <span>2025-01-18</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">预计完成</span>
                        <span>2025-02-15</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">负责人</span>
                        <span>李经理</span>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>进度追踪</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">整体进度</span>
                        <span className="font-medium">30%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">当前阶段进度</span>
                        <span>60%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">剩余时间</span>
                        <span>18天</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">风险评级</span>
                        <Badge variant="default" className="bg-green-100 text-green-800">低</Badge>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}