import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { TablePagination } from "../ui/table-pagination";
import { Plus } from "lucide-react";

export function SupplyDemandManagementContent() {
  const [activeTab, setActiveTab] = useState("supply-demand-gap");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const totalItems = 25; // 模拟总条数

  // 统计数据
  const statistics = [
    {
      title: "工位",
      items: [
        { label: "总预算", value: "150" },
        { label: "已申请", value: "120" },
        { label: "已分配", value: "95" }
      ]
    },
    {
      title: "空间",
      items: [
        { label: "总预算", value: "8" },
        { label: "已申请", value: "6" },
        { label: "已分配", value: "4" }
      ]
    },
    {
      title: "其他服务",
      items: [
        { label: "注册地", value: "3个" },
        { label: "已占用", value: "60天" }
      ]
    }
  ];

  // 供需差额数据
  const supplyDemandGapData = [
    {
      id: "GAP-2024-001",
      resourceType: "工位",
      location: "北京-总部-A栋-5层",
      supply: "100",
      demand: "120",
      gap: "-20",
      gapStatus: "缺口",
      gapColor: "bg-red-100 text-red-800",
      utilizationRate: "100%",
      lastUpdate: "2024-01-20",
      action: "查看"
    },
    {
      id: "GAP-2024-002",
      resourceType: "会议室",
      location: "上海-分部-B栋-3层",
      supply: "8",
      demand: "6",
      gap: "+2",
      gapStatus: "富余",
      gapColor: "bg-green-100 text-green-800",
      utilizationRate: "75%",
      lastUpdate: "2024-01-19",
      action: "查看"
    },
    {
      id: "GAP-2024-003",
      resourceType: "独立空间",
      location: "深圳-园区-C栋-2层",
      supply: "5",
      demand: "5",
      gap: "0",
      gapStatus: "平衡",
      gapColor: "bg-blue-100 text-blue-800",
      utilizationRate: "100%",
      lastUpdate: "2024-01-18",
      action: "查看"
    },
    {
      id: "GAP-2024-004",
      resourceType: "工位",
      location: "广州-办事处-D栋-1层",
      supply: "50",
      demand: "35",
      gap: "+15",
      gapStatus: "富余",
      gapColor: "bg-green-100 text-green-800",
      utilizationRate: "70%",
      lastUpdate: "2024-01-17",
      action: "查看"
    }
  ];

  // 供给汇总数据
  const supplySummaryData = [
    {
      id: "SUP-2024-001",
      resourceType: "工位",
      location: "北京-总部-A栋",
      totalSupply: "150",
      availableSupply: "30",
      reservedSupply: "20",
      occupancyRate: "80%",
      status: "充足",
      statusColor: "bg-green-100 text-green-800",
      lastUpdate: "2024-01-20",
      action: "查看"
    },
    {
      id: "SUP-2024-002",
      resourceType: "会议室",
      location: "上海-分部-B栋",
      totalSupply: "12",
      availableSupply: "2",
      reservedSupply: "1",
      occupancyRate: "83%",
      status: "紧张",
      statusColor: "bg-yellow-100 text-yellow-800",
      lastUpdate: "2024-01-19",
      action: "查看"
    },
    {
      id: "SUP-2024-003",
      resourceType: "独立空间",
      location: "深圳-园区-C栋",
      totalSupply: "8",
      availableSupply: "0",
      reservedSupply: "0",
      occupancyRate: "100%",
      status: "满载",
      statusColor: "bg-red-100 text-red-800",
      lastUpdate: "2024-01-18",
      action: "查看"
    },
    {
      id: "SUP-2024-004",
      resourceType: "停车位",
      location: "北京-总部-地下车库",
      totalSupply: "200",
      availableSupply: "50",
      reservedSupply: "20",
      occupancyRate: "75%",
      status: "充足",
      statusColor: "bg-green-100 text-green-800",
      lastUpdate: "2024-01-20",
      action: "查看"
    }
  ];

  // 需求汇总数据
  const demandSummaryData = [
    {
      id: "DEM-2024-001",
      department: "技术部",
      resourceType: "工位",
      currentDemand: "120",
      plannedDemand: "150",
      urgentDemand: "20",
      priority: "高",
      priorityColor: "bg-red-100 text-red-800",
      requestDate: "2024-01-15",
      expectedDate: "2024-02-01",
      status: "待分配",
      statusColor: "bg-yellow-100 text-yellow-800",
      action: "查看"
    },
    {
      id: "DEM-2024-002",
      department: "市场部",
      resourceType: "会议室",
      currentDemand: "6",
      plannedDemand: "8",
      urgentDemand: "2",
      priority: "中",
      priorityColor: "bg-yellow-100 text-yellow-800",
      requestDate: "2024-01-10",
      expectedDate: "2024-01-25",
      status: "已分配",
      statusColor: "bg-green-100 text-green-800",
      action: "查看"
    },
    {
      id: "DEM-2024-003",
      department: "研发部",
      resourceType: "独立空间",
      currentDemand: "5",
      plannedDemand: "6",
      urgentDemand: "1",
      priority: "高",
      priorityColor: "bg-red-100 text-red-800",
      requestDate: "2024-01-18",
      expectedDate: "2024-02-10",
      status: "审核中",
      statusColor: "bg-blue-100 text-blue-800",
      action: "查看"
    },
    {
      id: "DEM-2024-004",
      department: "财务部",
      resourceType: "工位",
      currentDemand: "25",
      plannedDemand: "25",
      urgentDemand: "0",
      priority: "低",
      priorityColor: "bg-gray-100 text-gray-800",
      requestDate: "2024-01-12",
      expectedDate: "2024-02-15",
      status: "已分配",
      statusColor: "bg-green-100 text-green-800",
      action: "查看"
    }
  ];

  return (
    <div className="space-y-4">
      {/* 页面标题 */}
      <div>
        <h1 className="text-lg font-medium">供需管理</h1>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-3 gap-4">
        {statistics.map((stat, index) => (
          <Card key={index} className="bg-white border border-gray-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-900">{stat.title}</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-2">
                {stat.items.map((item, itemIndex) => {
                  // 根据标签确定颜色
                  let valueColor = "text-gray-900";
                  if (item.label === "总预算") {
                    valueColor = "text-blue-600";
                  } else if (item.label === "已申请") {
                    valueColor = "text-yellow-600";
                  } else if (item.label === "已分配") {
                    valueColor = "text-green-600";
                  }
                  
                  return (
                    <div key={itemIndex} className="flex justify-between items-center">
                      <span className="text-xs text-gray-600">{item.label}:</span>
                      <span className={`text-xs font-medium ${valueColor}`}>{item.value}</span>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 供需管理数据 */}
      <Card className="bg-white border border-gray-200">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-medium text-gray-900 text-[15px]">供需管理数据</CardTitle>
            <div className="flex items-center gap-2">
              <Button size="sm" className="h-7 text-xs bg-blue-600 text-white hover:bg-blue-700">
                <Plus className="h-3 w-3 mr-1" />
                导出数据
              </Button>
              <Button variant="outline" size="sm" className="h-7 text-xs">
                刷新数据
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent className="pt-0">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-fit grid-cols-3 mb-4">
              <TabsTrigger value="supply-demand-gap" className="text-xs">供需差额</TabsTrigger>
              <TabsTrigger value="supply-summary" className="text-xs">供给汇总</TabsTrigger>
              <TabsTrigger value="demand-summary" className="text-xs">需求汇总</TabsTrigger>
            </TabsList>

            {/* 供需差额Tab */}
            <TabsContent value="supply-demand-gap" className="mt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10">编号</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">资源类型</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">位置</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">供给量</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">需求量</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">差额</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">差额状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">利用率</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">更新时间</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {supplyDemandGapData.map((record) => (
                      <TableRow key={record.id} className="hover:bg-gray-50">
                        <TableCell className="text-xs text-blue-600 font-medium">
                          {record.id}
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{record.resourceType}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.location}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.supply}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.demand}</TableCell>
                        <TableCell className="text-xs text-gray-900 font-medium">{record.gap}</TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`${record.gapColor} text-xs px-2 py-1 font-normal`}
                          >
                            {record.gapStatus}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{record.utilizationRate}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.lastUpdate}</TableCell>
                        <TableCell className="text-xs">
                          <Button 
                            variant="link" 
                            size="sm" 
                            className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                          >
                            {record.action}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <TablePagination
                total={totalItems}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </TabsContent>

            {/* 供给汇总Tab */}
            <TabsContent value="supply-summary" className="mt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10">编号</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">资源类型</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">位置</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">总供给</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">可用供给</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">预留供给</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">占用率</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">更新时间</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {supplySummaryData.map((record) => (
                      <TableRow key={record.id} className="hover:bg-gray-50">
                        <TableCell className="text-xs text-blue-600 font-medium">
                          {record.id}
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{record.resourceType}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.location}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.totalSupply}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.availableSupply}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.reservedSupply}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.occupancyRate}</TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`${record.statusColor} text-xs px-2 py-1 font-normal`}
                          >
                            {record.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{record.lastUpdate}</TableCell>
                        <TableCell className="text-xs">
                          <Button 
                            variant="link" 
                            size="sm" 
                            className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                          >
                            {record.action}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <TablePagination
                total={totalItems}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </TabsContent>

            {/* 需求汇总Tab */}
            <TabsContent value="demand-summary" className="mt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10">编号</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">部门</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">资源类型</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">当前需求</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">计划需求</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">紧急需求</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">优先级</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">申请日期</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">期望日期</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {demandSummaryData.map((record) => (
                      <TableRow key={record.id} className="hover:bg-gray-50">
                        <TableCell className="text-xs text-blue-600 font-medium">
                          {record.id}
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{record.department}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.resourceType}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.currentDemand}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.plannedDemand}</TableCell>
                        <TableCell className="text-xs text-gray-900 font-medium">{record.urgentDemand}</TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`${record.priorityColor} text-xs px-2 py-1 font-normal`}
                          >
                            {record.priority}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{record.requestDate}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.expectedDate}</TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`${record.statusColor} text-xs px-2 py-1 font-normal`}
                          >
                            {record.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs">
                          <Button 
                            variant="link" 
                            size="sm" 
                            className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                          >
                            {record.action}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <TablePagination
                total={totalItems}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}