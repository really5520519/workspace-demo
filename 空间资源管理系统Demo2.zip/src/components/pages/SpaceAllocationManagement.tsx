import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { TablePagination } from "../ui/table-pagination";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "../ui/breadcrumb";
import { 
  Plus, 
  Search, 
  FileText, 
  Building, 
  MapPin,
  CheckCircle, 
  Clock,
  Play,
  Package,
  ArrowRight
} from "lucide-react";

// 统计卡片数据
const statisticsData = [
  {
    title: "待办区",
    value: "12",
    unit: "",
    isSpecial: true,
    subtitle: "待处理空间需求数量",
    hasAction: true
  },
  {
    title: "项目合计",
    value: "50",
    unit: "",
    isSpecial: false
  },
  {
    title: "北区",
    value: "10",
    unit: "",
    isSpecial: false
  },
  {
    title: "东区",
    value: "12",
    unit: "",
    isSpecial: false
  },
  {
    title: "南区",
    value: "8",
    unit: "",
    isSpecial: false
  },
  {
    title: "西区",
    value: "5",
    unit: "",
    isSpecial: false
  }
];

// 分配列表数据
const allocationData = [
  {
    projectId: "ALC-2025-005",
    demandId: "REQ-2026-015",
    requester: "业务",
    stage: "特分配",
    status: "待处理",
    statusColor: "bg-orange-100 text-orange-800",
    demandType: "预算工位",
    demandTime: "2025.04",
    location: "上海-徐汇区",
    department: "市场部",
    projectPlan: "方案F",
    starTime: "2024-07-28",
    lastUpdate: "2024-07-30",
    actions: ["查看"]
  },
  {
    projectId: "ALC-2025-006",
    demandId: "REQ-2025-016",
    requester: "业务",
    stage: "已分配",
    status: "完成",
    statusColor: "bg-green-100 text-green-800",
    demandType: "预算空间",
    demandTime: "2025.03",
    location: "北京-朝阳区",
    department: "法务部",
    projectPlan: "方案G",
    starTime: "2024-07-25",
    lastUpdate: "2024-07-29",
    actions: ["查看"]
  }
];

export function SpaceAllocationManagementContent() {
  const [activeTab, setActiveTab] = useState("budget-workstation");
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const totalItems = 52; // 模拟总条数

  return (
    <div className="space-y-6">


      {/* 页面标题 */}
      <div>
        <h1 className="text-[15px]" className="font-bold">空间分配概况</h1>
      </div>

      {/* 统计区 */}
      <div className="grid grid-cols-6 gap-4">
        {statisticsData.map((item, index) => (
          <Card key={index} className={`hover:shadow-md transition-shadow ${item.isSpecial ? 'border-2 border-orange-200 bg-orange-50' : ''}`}>
            <CardContent className="p-4">
              {item.isSpecial ? (
                <div className="text-center">
                  <p className="text-sm text-gray-600 mb-1">{item.title}</p>
                  <p className="text-sm text-gray-500 mb-2">{item.subtitle}</p>
                  <p className="text-2xl font-semibold">{item.value}</p>
                </div>
              ) : (
                <div className="text-center">
                  <p className="text-sm text-gray-600 mb-1">{item.title}</p>
                  <p className="text-2xl font-semibold">{item.value}{item.unit}</p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 分配列表 */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium">分配列表</CardTitle>
        </CardHeader>
        <CardContent className="mt-[-21px] mr-[0px] mb-[0px] ml-[0px]">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-fit grid-cols-3 mb-4">
              <TabsTrigger value="budget-workstation" className="text-sm">预算工位分配</TabsTrigger>
              <TabsTrigger value="budget-space" className="text-sm">预算空间分配</TabsTrigger>
              <TabsTrigger value="temporary-demand" className="text-sm">临时需求分配</TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="mt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-sm font-medium">项目ID</TableHead>
                      <TableHead className="text-sm font-medium">需求ID</TableHead>
                      <TableHead className="text-sm font-medium">需求方</TableHead>
                      <TableHead className="text-sm font-medium">阶段</TableHead>
                      <TableHead className="text-sm font-medium">状态</TableHead>
                      <TableHead className="text-sm font-medium">需求类型</TableHead>
                      <TableHead className="text-sm font-medium">需求时间</TableHead>
                      <TableHead className="text-sm font-medium">地点</TableHead>
                      <TableHead className="text-sm font-medium">部门</TableHead>
                      <TableHead className="text-sm font-medium">项目方案</TableHead>
                      <TableHead className="text-sm font-medium">星级时间</TableHead>
                      <TableHead className="text-sm font-medium">最近更新时间</TableHead>
                      <TableHead className="text-sm font-medium">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {allocationData.map((item, index) => (
                      <TableRow key={index} className="hover:bg-muted/30">
                        <TableCell className="text-sm font-mono text-blue-600">{item.projectId}</TableCell>
                        <TableCell className="text-sm font-mono text-blue-600">{item.demandId}</TableCell>
                        <TableCell className="text-sm">{item.requester}</TableCell>
                        <TableCell className="text-sm">{item.stage}</TableCell>
                        <TableCell>
                          <Badge variant="default" className={`${item.statusColor} hover:${item.statusColor}`}>
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">{item.demandType}</TableCell>
                        <TableCell className="text-sm">{item.demandTime}</TableCell>
                        <TableCell className="text-sm">{item.location}</TableCell>
                        <TableCell className="text-sm">{item.department}</TableCell>
                        <TableCell className="text-sm">{item.projectPlan}</TableCell>
                        <TableCell className="text-sm">{item.starTime}</TableCell>
                        <TableCell className="text-sm">{item.lastUpdate}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            {item.actions.map((action, actionIndex) => (
                              <Button 
                                key={actionIndex}
                                variant="ghost" 
                                size="sm" 
                                className="h-7 text-xs text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                              >
                                {action}
                              </Button>
                            ))}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <TablePagination
                total={totalItems}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}