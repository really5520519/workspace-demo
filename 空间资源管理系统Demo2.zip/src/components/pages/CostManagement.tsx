import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { FileText, TrendingUp, TrendingDown } from "lucide-react";

export function CostManagementContent() {
  const [activeTab, setActiveTab] = useState("rental");

  // 租赁成本数据
  const rentalCostItems = [
    {
      id: "RL-2024-07",
      project: "RL-2024-07",
      costStatus: "执行中",
      costTitle: "北京办公室Q3租赁成本",
      landlord: "万科企业",
      budgetAmount: "¥3,200,000",
      actualAmount: "¥3,200,000",
      variance: "¥0",
      varianceRate: "0%",
      status: "正常",
      action: "查看"
    },
    {
      id: "RL-2024-06", 
      project: "RL-2024-06",
      costStatus: "已完成",
      costTitle: "上海分部办公楼租赁成本",
      landlord: "绿地集团",
      budgetAmount: "¥2,800,000",
      actualAmount: "¥2,650,000",
      variance: "-¥150,000",
      varianceRate: "-5.4%",
      status: "节约",
      action: "查看"
    },
    {
      id: "RL-2024-08",
      project: "RL-2024-08", 
      costStatus: "计划中",
      costTitle: "深圳分部新租办公室成本",
      landlord: "华润置地",
      budgetAmount: "¥2,500,000",
      actualAmount: "¥0",
      variance: "¥0",
      varianceRate: "0%",
      status: "计划中",
      action: "查看"
    }
  ];

  // 运营成本数据
  const operationCostItems = [
    {
      id: "OC-2024-07",
      project: "OC-2024-07",
      costStatus: "执行中",
      costTitle: "北京办公室Q3运营成本",
      department: "行政部",
      budgetAmount: "¥800,000",
      actualAmount: "¥650,000",
      variance: "-¥150,000",
      varianceRate: "-18.8%",
      status: "节约",
      action: "查看"
    },
    {
      id: "OC-2024-06", 
      project: "OC-2024-06",
      costStatus: "已完成",
      costTitle: "上海分部设施维护成本",
      department: "设施部",
      budgetAmount: "¥450,000",
      actualAmount: "¥520,000",
      variance: "+¥70,000",
      varianceRate: "+15.6%",
      status: "超支",
      action: "查看"
    },
    {
      id: "OC-2024-07-GZ",
      project: "OC-2024-07-GZ", 
      costStatus: "计划中",
      costTitle: "广州办公室清洁服务成本",
      department: "行政部",
      budgetAmount: "¥200,000",
      actualAmount: "¥0",
      variance: "¥0",
      varianceRate: "0%",
      status: "计划中",
      action: "查看"
    }
  ];

  // 装修成本数据
  const renovationCostItems = [
    {
      id: "RC-2024-07",
      project: "RC-2024-07",
      costStatus: "执行中",
      costTitle: "北京办公室装修改造项目",
      contractor: "华建装饰",
      budgetAmount: "¥2,500,000",
      actualAmount: "¥1,800,000",
      variance: "-¥700,000",
      varianceRate: "-28.0%",
      status: "进行中",
      action: "查看"
    },
    {
      id: "RC-2024-06", 
      project: "RC-2024-06",
      costStatus: "已完成",
      costTitle: "深圳分部会议室装修",
      contractor: "鹏程建设",
      budgetAmount: "¥1,200,000",
      actualAmount: "¥1,350,000",
      variance: "+¥150,000",
      varianceRate: "+12.5%",
      status: "已完成",
      action: "查看"
    },
    {
      id: "RC-2024-08",
      project: "RC-2024-08", 
      costStatus: "计划中",
      costTitle: "杭州办公室新区装修",
      contractor: "待确定",
      budgetAmount: "¥1,800,000",
      actualAmount: "¥0",
      variance: "¥0",
      varianceRate: "0%",
      status: "计划中",
      action: "查看"
    }
  ];

  // 租赁成本指标数据
  const rentalCostMetrics = [
    {
      title: "总租赁成本",
      amount: "¥28,500,000",
      progress: 82,
      progressColor: "bg-purple-500"
    },
    {
      title: "办公租赁", 
      amount: "¥18,200,000",
      progress: 85,
      progressColor: "bg-purple-500"
    },
    {
      title: "仓储租赁",
      amount: "¥6,800,000", 
      progress: 75,
      progressColor: "bg-purple-500"
    },
    {
      title: "其他租赁",
      amount: "¥3,500,000",
      progress: 88,
      progressColor: "bg-purple-500"
    }
  ];

  // 运营成本指标数据
  const operationCostMetrics = [
    {
      title: "总运营成本",
      amount: "¥3,200,000",
      progress: 78,
      progressColor: "bg-blue-500"
    },
    {
      title: "人员成本", 
      amount: "¥1,800,000",
      progress: 85,
      progressColor: "bg-blue-500"
    },
    {
      title: "设施成本",
      amount: "¥800,000", 
      progress: 65,
      progressColor: "bg-blue-500"
    },
    {
      title: "服务成本",
      amount: "¥600,000",
      progress: 72,
      progressColor: "bg-blue-500"
    }
  ];

  // 装修成本指标数据
  const renovationCostMetrics = [
    {
      title: "总装修成本",
      amount: "¥8,500,000",
      progress: 68,
      progressColor: "bg-orange-500"
    },
    {
      title: "基础装修", 
      amount: "¥4,200,000",
      progress: 75,
      progressColor: "bg-orange-500"
    },
    {
      title: "设备安装",
      amount: "¥2,800,000", 
      progress: 60,
      progressColor: "bg-orange-500"
    },
    {
      title: "软装配置",
      amount: "¥1,500,000",
      progress: 55,
      progressColor: "bg-orange-500"
    }
  ];

  return (
    <div className="space-y-6 max-w-[1300px] mx-auto p-[0px]">
      {/* 页面标题和说明文档按钮 */}
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-medium">成本管理</h1>

      </div>

      {/* 成本管理标签页 */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="inline-flex mb-6">
          <TabsTrigger value="rental" className="text-xs">租赁成本</TabsTrigger>
          <TabsTrigger value="renovation" className="text-xs">装修成本</TabsTrigger>
          <TabsTrigger value="operation" className="text-xs">运营成本</TabsTrigger>
        </TabsList>

        {/* 租赁成本标签页 */}
        <TabsContent value="rental" className="space-y-6">
          {/* 租赁成本概览区域 */}
          <div className="grid grid-cols-12 gap-6">
            {/* 左侧环形图 */}
            <div className="col-span-3">
              <Card className="bg-white border border-gray-200 h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center h-full">
                  <div className="relative w-32 h-32 mb-4">
                    {/* 环形图 SVG */}
                    <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
                      {/* 背景圆环 */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#e5e7eb"
                        strokeWidth="8"
                        fill="none"
                      />
                      {/* 进度圆环 */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#a855f7"
                        strokeWidth="8"
                        fill="none"
                        strokeDasharray={`${2 * Math.PI * 40 * 0.82} ${2 * Math.PI * 40}`}
                        strokeLinecap="round"
                      />
                    </svg>
                    {/* 中心文字 */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <div className="text-xs text-gray-600">租赁成本执行</div>
                      <div className="text-lg font-medium text-gray-900">82%</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                    <span className="text-gray-600">已执行</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* 右侧租赁成本指标卡片 */}
            <div className="col-span-9">
              <div className="grid grid-cols-2 gap-4 h-full">
                {rentalCostMetrics.map((metric, index) => (
                  <Card key={index} className="bg-white border border-gray-200">
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <div className="text-xs text-gray-600">{metric.title}</div>
                          <div className="text-xs text-gray-500">{metric.progress}%</div>
                        </div>
                        <div className="text-lg font-medium text-gray-900">{metric.amount}</div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${metric.progressColor}`}
                            style={{ width: `${metric.progress}%` }}
                          ></div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          {/* 租赁成本详情表格 */}
          <Card className="bg-white border border-gray-200">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-900">租赁成本明细</CardTitle>
                <div className="flex items-center gap-2">
                  <Button size="sm" className="h-7 text-xs bg-purple-600 hover:bg-purple-700">
                    新增租赁项目
                  </Button>
                  <Button variant="outline" size="sm" className="h-7 text-xs">
                    导出数据
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10">租赁项目</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">执行状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">租赁标题</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">出租方</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">预算金额</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">实际金额</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">差异</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">差异率</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {rentalCostItems.map((item) => (
                      <TableRow key={item.id} className="hover:bg-gray-50">
                        <TableCell className="text-xs text-gray-900">{item.project}</TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`text-xs border ${
                              item.costStatus === "已完成" 
                                ? "bg-green-50 text-green-700 border-green-200" 
                                : item.costStatus === "执行中"
                                ? "bg-blue-50 text-blue-700 border-blue-200" 
                                : "bg-gray-100 text-gray-700 border-gray-200"
                            }`}
                          >
                            {item.costStatus}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{item.costTitle}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.landlord}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.budgetAmount}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.actualAmount}</TableCell>
                        <TableCell className="text-xs">
                          <div className={`flex items-center gap-1 ${
                            item.variance.startsWith('+') ? 'text-red-600' : 
                            item.variance.startsWith('-') ? 'text-green-600' : 'text-gray-600'
                          }`}>
                            {item.variance.startsWith('+') ? <TrendingUp className="h-3 w-3" /> : 
                             item.variance.startsWith('-') ? <TrendingDown className="h-3 w-3" /> : null}
                            {item.variance}
                          </div>
                        </TableCell>
                        <TableCell className={`text-xs ${
                          item.varianceRate.startsWith('+') ? 'text-red-600' : 
                          item.varianceRate.startsWith('-') ? 'text-green-600' : 'text-gray-600'
                        }`}>
                          {item.varianceRate}
                        </TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`text-xs border ${
                              item.status === "节约" 
                                ? "bg-green-50 text-green-700 border-green-200" 
                                : item.status === "正常"
                                ? "bg-blue-50 text-blue-700 border-blue-200" 
                                : "bg-gray-100 text-gray-700 border-gray-200"
                            }`}
                          >
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs">
                          <Button 
                            variant="link" 
                            size="sm" 
                            className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                          >
                            {item.action}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 运营成本标签页 */}
        <TabsContent value="operation" className="space-y-6">
          {/* 运营成本概览区域 */}
          <div className="grid grid-cols-12 gap-6">
            {/* 左侧环形图 */}
            <div className="col-span-3">
              <Card className="bg-white border border-gray-200 h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center h-full">
                  <div className="relative w-32 h-32 mb-4">
                    {/* 环形图 SVG */}
                    <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
                      {/* 背景圆环 */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#e5e7eb"
                        strokeWidth="8"
                        fill="none"
                      />
                      {/* 进度圆环 */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#3b82f6"
                        strokeWidth="8"
                        fill="none"
                        strokeDasharray={`${2 * Math.PI * 40 * 0.78} ${2 * Math.PI * 40}`}
                        strokeLinecap="round"
                      />
                    </svg>
                    {/* 中心文字 */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <div className="text-xs text-gray-600">运营成本执行</div>
                      <div className="text-lg font-medium text-gray-900">78%</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                    <span className="text-gray-600">已执行</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* 右侧运营成本指标卡片 */}
            <div className="col-span-9">
              <div className="grid grid-cols-2 gap-4 h-full">
                {operationCostMetrics.map((metric, index) => (
                  <Card key={index} className="bg-white border border-gray-200">
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <div className="text-xs text-gray-600">{metric.title}</div>
                          <div className="text-xs text-gray-500">{metric.progress}%</div>
                        </div>
                        <div className="text-lg font-medium text-gray-900">{metric.amount}</div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${metric.progressColor}`}
                            style={{ width: `${metric.progress}%` }}
                          ></div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          {/* 运营成本详情表格 */}
          <Card className="bg-white border border-gray-200">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-900">运营成本明细</CardTitle>
                <div className="flex items-center gap-2">
                  <Button size="sm" className="h-7 text-xs bg-blue-600 hover:bg-blue-700">
                    新增成本记录
                  </Button>
                  <Button variant="outline" size="sm" className="h-7 text-xs">
                    导出数据
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10">成本项目</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">执行状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">成本标题</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">负责部门</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">预算金额</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">实际金额</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">差异</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">差异率</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {operationCostItems.map((item) => (
                      <TableRow key={item.id} className="hover:bg-gray-50">
                        <TableCell className="text-xs text-gray-900">{item.project}</TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`text-xs border ${
                              item.costStatus === "已完成" 
                                ? "bg-green-50 text-green-700 border-green-200" 
                                : item.costStatus === "执行中"
                                ? "bg-blue-50 text-blue-700 border-blue-200" 
                                : "bg-gray-100 text-gray-700 border-gray-200"
                            }`}
                          >
                            {item.costStatus}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{item.costTitle}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.department}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.budgetAmount}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.actualAmount}</TableCell>
                        <TableCell className="text-xs">
                          <div className={`flex items-center gap-1 ${
                            item.variance.startsWith('+') ? 'text-red-600' : 
                            item.variance.startsWith('-') ? 'text-green-600' : 'text-gray-600'
                          }`}>
                            {item.variance.startsWith('+') ? <TrendingUp className="h-3 w-3" /> : 
                             item.variance.startsWith('-') ? <TrendingDown className="h-3 w-3" /> : null}
                            {item.variance}
                          </div>
                        </TableCell>
                        <TableCell className={`text-xs ${
                          item.varianceRate.startsWith('+') ? 'text-red-600' : 
                          item.varianceRate.startsWith('-') ? 'text-green-600' : 'text-gray-600'
                        }`}>
                          {item.varianceRate}
                        </TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`text-xs border ${
                              item.status === "节约" 
                                ? "bg-green-50 text-green-700 border-green-200" 
                                : item.status === "超支"
                                ? "bg-red-50 text-red-700 border-red-200" 
                                : "bg-gray-100 text-gray-700 border-gray-200"
                            }`}
                          >
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs">
                          <Button 
                            variant="link" 
                            size="sm" 
                            className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                          >
                            {item.action}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 装修成本标签页 */}
        <TabsContent value="renovation" className="space-y-6">
          {/* 装修成本概览区域 */}
          <div className="grid grid-cols-12 gap-6">
            {/* 左侧环形图 */}
            <div className="col-span-3">
              <Card className="bg-white border border-gray-200 h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center h-full">
                  <div className="relative w-32 h-32 mb-4">
                    {/* 环形图 SVG */}
                    <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
                      {/* 背景圆环 */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#e5e7eb"
                        strokeWidth="8"
                        fill="none"
                      />
                      {/* 进度圆环 */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#f97316"
                        strokeWidth="8"
                        fill="none"
                        strokeDasharray={`${2 * Math.PI * 40 * 0.68} ${2 * Math.PI * 40}`}
                        strokeLinecap="round"
                      />
                    </svg>
                    {/* 中心文字 */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <div className="text-xs text-gray-600">装修成本执行</div>
                      <div className="text-lg font-medium text-gray-900">68%</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                    <span className="text-gray-600">已执行</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* 右侧装修成本指标卡片 */}
            <div className="col-span-9">
              <div className="grid grid-cols-2 gap-4 h-full">
                {renovationCostMetrics.map((metric, index) => (
                  <Card key={index} className="bg-white border border-gray-200">
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <div className="text-xs text-gray-600">{metric.title}</div>
                          <div className="text-xs text-gray-500">{metric.progress}%</div>
                        </div>
                        <div className="text-lg font-medium text-gray-900">{metric.amount}</div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${metric.progressColor}`}
                            style={{ width: `${metric.progress}%` }}
                          ></div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          {/* 装修成本详情表格 */}
          <Card className="bg-white border border-gray-200">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-900">装修成本明细</CardTitle>
                <div className="flex items-center gap-2">
                  <Button size="sm" className="h-7 text-xs bg-orange-600 hover:bg-orange-700">
                    新增装修项目
                  </Button>
                  <Button variant="outline" size="sm" className="h-7 text-xs">
                    导出数据
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10">项目编号</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">执行状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">项目标题</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">承包商</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">预算金额</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">实际金额</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">差异</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">差异率</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {renovationCostItems.map((item) => (
                      <TableRow key={item.id} className="hover:bg-gray-50">
                        <TableCell className="text-xs text-gray-900">{item.project}</TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`text-xs border ${
                              item.costStatus === "已完成" 
                                ? "bg-green-50 text-green-700 border-green-200" 
                                : item.costStatus === "执行中"
                                ? "bg-blue-50 text-blue-700 border-blue-200" 
                                : "bg-gray-100 text-gray-700 border-gray-200"
                            }`}
                          >
                            {item.costStatus}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{item.costTitle}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.contractor}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.budgetAmount}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.actualAmount}</TableCell>
                        <TableCell className="text-xs">
                          <div className={`flex items-center gap-1 ${
                            item.variance.startsWith('+') ? 'text-red-600' : 
                            item.variance.startsWith('-') ? 'text-green-600' : 'text-gray-600'
                          }`}>
                            {item.variance.startsWith('+') ? <TrendingUp className="h-3 w-3" /> : 
                             item.variance.startsWith('-') ? <TrendingDown className="h-3 w-3" /> : null}
                            {item.variance}
                          </div>
                        </TableCell>
                        <TableCell className={`text-xs ${
                          item.varianceRate.startsWith('+') ? 'text-red-600' : 
                          item.varianceRate.startsWith('-') ? 'text-green-600' : 'text-gray-600'
                        }`}>
                          {item.varianceRate}
                        </TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`text-xs border ${
                              item.status === "已完成" 
                                ? "bg-green-50 text-green-700 border-green-200" 
                                : item.status === "进行中"
                                ? "bg-blue-50 text-blue-700 border-blue-200" 
                                : "bg-gray-100 text-gray-700 border-gray-200"
                            }`}
                          >
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs">
                          <Button 
                            variant="link" 
                            size="sm" 
                            className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                          >
                            {item.action}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}