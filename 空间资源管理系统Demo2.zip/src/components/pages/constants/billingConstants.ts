export const billingItems = [
  {
    id: "BILL-2024-07",
    project: "BILL-2024-07",
    city: "2024-07",
    status: "已结算",
    totalAmount: "¥354,167",
    paidAmount: "¥300,000",
    unpaidAmount: "¥50,000",
    overdue: "¥4,167",
    action: "查看"
  },
  {
    id: "BILL-2024-06", 
    project: "BILL-2024-06",
    city: "2024-06",
    status: "待支付",
    totalAmount: "¥354,167",
    paidAmount: "¥300,000",
    unpaidAmount: "¥50,000",
    overdue: "¥4,167",
    action: "查看"
  },
  {
    id: "BILL-2024-07-US",
    project: "BILL-2024-07-US", 
    city: "2024-07",
    status: "已支付",
    totalAmount: "$50,000",
    paidAmount: "$40,000",
    unpaidAmount: "$8,000",
    overdue: "$2,000",
    action: "查看"
  }
];

export const billingMetrics = [
  {
    title: "总费用",
    amount: "¥4,250,000",
    progress: 85,
    progressColor: "bg-blue-500"
  },
  {
    title: "已支付", 
    amount: "¥800,000",
    progress: 60,
    progressColor: "bg-blue-500"
  },
  {
    title: "待支付",
    amount: "¥1,100,000", 
    progress: 75,
    progressColor: "bg-blue-500"
  },
  {
    title: "逾期费用",
    amount: "¥150,000",
    progress: 45,
    progressColor: "bg-blue-500"
  }
];