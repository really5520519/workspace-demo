import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { FileText, Clock, CheckCircle, AlertCircle } from "lucide-react";

export function BusinessBillingContent() {
  const [activeTab, setActiveTab] = useState("workstation");

  // 工位计费数据
  const workstationBillingItems = [
    {
      id: "WB-2024-07-001",
      billCode: "WB-2024-07-001",
      billStatus: "已确认",
      department: "技术部",
      employee: "张三",
      workstationCode: "BJ-A-101",
      billingPeriod: "2024年7月",
      unitPrice: "¥150/天",
      days: 22,
      totalAmount: "¥3,300",
      status: "已支付",
      action: "查看"
    },
    {
      id: "WB-2024-07-002", 
      billCode: "WB-2024-07-002",
      billStatus: "待确认",
      department: "市场部",
      employee: "李四",
      workstationCode: "SH-B-205",
      billingPeriod: "2024年7月",
      unitPrice: "¥120/天",
      days: 20,
      totalAmount: "¥2,400",
      status: "待支付",
      action: "查看"
    },
    {
      id: "WB-2024-07-003",
      billCode: "WB-2024-07-003", 
      billStatus: "已确认",
      department: "财务部",
      employee: "王五",
      workstationCode: "GZ-C-308",
      billingPeriod: "2024年7月",
      unitPrice: "¥100/天",
      days: 23,
      totalAmount: "¥2,300",
      status: "已支付",
      action: "查看"
    }
  ];

  // 空间计费数据
  const spaceBillingItems = [
    {
      id: "SB-2024-07-001",
      billCode: "SB-2024-07-001",
      billStatus: "已确认",
      department: "技术部",
      spaceType: "会议室",
      spaceCode: "BJ-MR-A101",
      billingPeriod: "2024年7月",
      unitPrice: "¥500/小时",
      hours: 48,
      totalAmount: "¥24,000",
      status: "已支付",
      action: "查看"
    },
    {
      id: "SB-2024-07-002", 
      billCode: "SB-2024-07-002",
      billStatus: "待确认",
      department: "市场部",
      spaceType: "培训室",
      spaceCode: "SH-TR-B203",
      billingPeriod: "2024年7月",
      unitPrice: "¥300/小时",
      hours: 32,
      totalAmount: "¥9,600",
      status: "待支付",
      action: "查看"
    },
    {
      id: "SB-2024-07-003",
      billCode: "SB-2024-07-003", 
      billStatus: "已确认",
      department: "人事部",
      spaceType: "活动室",
      spaceCode: "GZ-AR-C105",
      billingPeriod: "2024年7月",
      unitPrice: "¥200/小时",
      hours: 16,
      totalAmount: "¥3,200",
      status: "已支付",
      action: "查看"
    }
  ];

  // 工位计费指标数据
  const workstationBillingMetrics = [
    {
      title: "总工位计费",
      amount: "¥1,250,000",
      progress: 88,
      progressColor: "bg-blue-500"
    },
    {
      title: "普通工位", 
      amount: "¥750,000",
      progress: 92,
      progressColor: "bg-blue-500"
    },
    {
      title: "高级工位",
      amount: "¥350,000", 
      progress: 78,
      progressColor: "bg-blue-500"
    },
    {
      title: "临时工位",
      amount: "¥150,000",
      progress: 65,
      progressColor: "bg-blue-500"
    }
  ];

  // 空间计费指标数据
  const spaceBillingMetrics = [
    {
      title: "总空间计费",
      amount: "¥850,000",
      progress: 75,
      progressColor: "bg-green-500"
    },
    {
      title: "会议室", 
      amount: "¥480,000",
      progress: 85,
      progressColor: "bg-green-500"
    },
    {
      title: "培训室",
      amount: "¥220,000", 
      progress: 68,
      progressColor: "bg-green-500"
    },
    {
      title: "活动空间",
      amount: "¥150,000",
      progress: 62,
      progressColor: "bg-green-500"
    }
  ];

  return (
    <div className="space-y-6 max-w-[1300px] mx-auto py-[0px] p-[0px]">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-medium">业务计费</h1>
      </div>

      {/* 业务计费标签页 */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="inline-flex mb-6">
          <TabsTrigger value="workstation" className="text-xs">工位计费</TabsTrigger>
          <TabsTrigger value="space" className="text-xs">空间计费</TabsTrigger>
        </TabsList>

        {/* 工位计费标签页 */}
        <TabsContent value="workstation" className="space-y-6">
          {/* 工位计费概览区域 */}
          <div className="grid grid-cols-12 gap-6">
            {/* 左侧环形图 */}
            <div className="col-span-3">
              <Card className="bg-white border border-gray-200 h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center h-full">
                  <div className="relative w-32 h-32 mb-4">
                    {/* 环形图 SVG */}
                    <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
                      {/* 背景圆环 */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#e5e7eb"
                        strokeWidth="8"
                        fill="none"
                      />
                      {/* 进度圆环 */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#3b82f6"
                        strokeWidth="8"
                        fill="none"
                        strokeDasharray={`${2 * Math.PI * 40 * 0.88} ${2 * Math.PI * 40}`}
                        strokeLinecap="round"
                      />
                    </svg>
                    {/* 中心文字 */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <div className="text-xs text-gray-600">工位计费完成</div>
                      <div className="text-lg font-medium text-gray-900">88%</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                    <span className="text-gray-600">已计费</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* 右侧工位计费指标卡片 */}
            <div className="col-span-9">
              <div className="grid grid-cols-2 gap-4 h-full">
                {workstationBillingMetrics.map((metric, index) => (
                  <Card key={index} className="bg-white border border-gray-200">
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <div className="text-xs text-gray-600">{metric.title}</div>
                          <div className="text-xs text-gray-500">{metric.progress}%</div>
                        </div>
                        <div className="text-lg font-medium text-gray-900">{metric.amount}</div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${metric.progressColor}`}
                            style={{ width: `${metric.progress}%` }}
                          ></div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          {/* 工位计费详情表格 */}
          <Card className="bg-white border border-gray-200">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-900">工位计费明细</CardTitle>
                <div className="flex items-center gap-2">
                  <Button size="sm" className="h-7 text-xs bg-blue-600 hover:bg-blue-700">
                    生成账单
                  </Button>
                  <Button variant="outline" size="sm" className="h-7 text-xs">
                    导出数据
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10">账单编号</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">账单状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">部门</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">员工</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">工位编号</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">计费周期</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">单价</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">天数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">总金额</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">支付状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {workstationBillingItems.map((item) => (
                      <TableRow key={item.id} className="hover:bg-gray-50">
                        <TableCell className="text-xs text-gray-900">{item.billCode}</TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`text-xs border ${
                              item.billStatus === "已确认" 
                                ? "bg-green-50 text-green-700 border-green-200" 
                                : item.billStatus === "待确认"
                                ? "bg-yellow-50 text-yellow-700 border-yellow-200" 
                                : "bg-gray-100 text-gray-700 border-gray-200"
                            }`}
                          >
                            <div className="flex items-center gap-1">
                              {item.billStatus === "已确认" ? 
                                <CheckCircle className="h-3 w-3" /> : 
                                <Clock className="h-3 w-3" />
                              }
                              {item.billStatus}
                            </div>
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{item.department}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.employee}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.workstationCode}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.billingPeriod}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.unitPrice}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.days}</TableCell>
                        <TableCell className="text-xs text-gray-900 font-medium">{item.totalAmount}</TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`text-xs border ${
                              item.status === "已支付" 
                                ? "bg-blue-50 text-blue-700 border-blue-200" 
                                : "bg-orange-50 text-orange-700 border-orange-200"
                            }`}
                          >
                            {item.status === "已支付" ? 
                              <CheckCircle className="h-3 w-3 mr-1" /> : 
                              <AlertCircle className="h-3 w-3 mr-1" />
                            }
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs">
                          <Button 
                            variant="link" 
                            size="sm" 
                            className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                          >
                            {item.action}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 空间计费标签页 */}
        <TabsContent value="space" className="space-y-6">
          {/* 空间计费概览区域 */}
          <div className="grid grid-cols-12 gap-6">
            {/* 左侧环形图 */}
            <div className="col-span-3">
              <Card className="bg-white border border-gray-200 h-full">
                <CardContent className="p-6 flex flex-col items-center justify-center h-full">
                  <div className="relative w-32 h-32 mb-4">
                    {/* 环形图 SVG */}
                    <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
                      {/* 背景圆环 */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#e5e7eb"
                        strokeWidth="8"
                        fill="none"
                      />
                      {/* 进度圆环 */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#10b981"
                        strokeWidth="8"
                        fill="none"
                        strokeDasharray={`${2 * Math.PI * 40 * 0.75} ${2 * Math.PI * 40}`}
                        strokeLinecap="round"
                      />
                    </svg>
                    {/* 中心文字 */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <div className="text-xs text-gray-600">空间计费完成</div>
                      <div className="text-lg font-medium text-gray-900">75%</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-gray-600">已计费</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* 右侧空间计费指标卡片 */}
            <div className="col-span-9">
              <div className="grid grid-cols-2 gap-4 h-full">
                {spaceBillingMetrics.map((metric, index) => (
                  <Card key={index} className="bg-white border border-gray-200">
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <div className="text-xs text-gray-600">{metric.title}</div>
                          <div className="text-xs text-gray-500">{metric.progress}%</div>
                        </div>
                        <div className="text-lg font-medium text-gray-900">{metric.amount}</div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${metric.progressColor}`}
                            style={{ width: `${metric.progress}%` }}
                          ></div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          {/* 空间计费详情表格 */}
          <Card className="bg-white border border-gray-200">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-900">空间计费明细</CardTitle>
                <div className="flex items-center gap-2">
                  <Button size="sm" className="h-7 text-xs bg-green-600 hover:bg-green-700">
                    生成账单
                  </Button>
                  <Button variant="outline" size="sm" className="h-7 text-xs">
                    导出数据
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10">账单编号</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">账单状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">部门</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">空间类型</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">空间编号</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">计费周期</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">单价</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">小时数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">总金额</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">支付状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {spaceBillingItems.map((item) => (
                      <TableRow key={item.id} className="hover:bg-gray-50">
                        <TableCell className="text-xs text-gray-900">{item.billCode}</TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`text-xs border ${
                              item.billStatus === "已确认" 
                                ? "bg-green-50 text-green-700 border-green-200" 
                                : item.billStatus === "待确认"
                                ? "bg-yellow-50 text-yellow-700 border-yellow-200" 
                                : "bg-gray-100 text-gray-700 border-gray-200"
                            }`}
                          >
                            <div className="flex items-center gap-1">
                              {item.billStatus === "已确认" ? 
                                <CheckCircle className="h-3 w-3" /> : 
                                <Clock className="h-3 w-3" />
                              }
                              {item.billStatus}
                            </div>
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{item.department}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.spaceType}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.spaceCode}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.billingPeriod}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.unitPrice}</TableCell>
                        <TableCell className="text-xs text-gray-900">{item.hours}</TableCell>
                        <TableCell className="text-xs text-gray-900 font-medium">{item.totalAmount}</TableCell>
                        <TableCell className="text-xs">
                          <Badge 
                            variant="secondary" 
                            className={`text-xs border ${
                              item.status === "已支付" 
                                ? "bg-blue-50 text-blue-700 border-blue-200" 
                                : "bg-orange-50 text-orange-700 border-orange-200"
                            }`}
                          >
                            {item.status === "已支付" ? 
                              <CheckCircle className="h-3 w-3 mr-1" /> : 
                              <AlertCircle className="h-3 w-3 mr-1" />
                            }
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs">
                          <Button 
                            variant="link" 
                            size="sm" 
                            className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                          >
                            {item.action}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}