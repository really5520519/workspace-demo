import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { FileText } from "lucide-react";
import { Button } from "../ui/button";

export function SpaceStatisticsContent() {
  // 工位配套数据
  const workstationData = [
    { label: "HC人数", value: "70" },
    { label: "产品投入", value: "0.3" },
    { label: "工位数", value: "70" },
    { label: "预约数", value: "70" },
    { label: "已预约过期人数", value: "0.5" },
    { label: "库存数", value: "0" },
    { label: "评分数", value: "0.3" }
  ];

  // 空间预算统计数据
  const budgetData = [
    { label: "装修", value: "10" },
    { label: "流程签", value: "5" },
    { label: "系统签", value: "2" },
    { label: "驿馆", value: "1" },
    { label: "已预算金额", value: "8" },
    { label: "已通过申请", value: "2" }
  ];

  // 常用地点预约统计表格数据
  const locationData = [
    {
      id: "1",
      city: "北京",
      hcCount: "50",
      allocatedCount: "48",
      estimatedCount: "50",
      independentSpaceCount: "2",
      action: "详情"
    },
    {
      id: "2", 
      city: "上海",
      hcCount: "30",
      allocatedCount: "15",
      estimatedCount: "20",
      independentSpaceCount: "1",
      action: "详情"
    }
  ];

  return (
    <div className="space-y-6 max-w-[1300px] mx-auto p-[0px]">
      {/* 页面标题和说明文档按钮 */}
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-medium">空间资源统计</h1>
        <Button variant="outline" size="sm" className="h-7 text-xs bg-blue-50 text-blue-600 border-blue-200 hover:bg-blue-100">
          <FileText className="h-3 w-3 mr-1" />
          说明文档
        </Button>
      </div>

      {/* 工位配套 */}
      <Card className="bg-white border border-gray-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-gray-900">工位配套</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="grid grid-cols-7 gap-4">
            {workstationData.map((item, index) => (
              <div key={index} className="text-center">
                <div className="text-xs text-gray-600 mb-1">{item.label}</div>
                <div className="text-lg font-medium text-gray-900">{item.value}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 空间预算统计 */}
      <Card className="bg-white border border-gray-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-gray-900">空间预算统计</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="grid grid-cols-6 gap-4">
            {budgetData.map((item, index) => (
              <div key={index} className="text-center">
                <div className="text-xs text-gray-600 mb-1">{item.label}</div>
                <div className="text-lg font-medium text-gray-900">{item.value}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 常用地点预约统计 */}
      <Card className="bg-white border border-gray-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-gray-900">常用地点 预约统计</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">城市</TableHead>
                  <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">HC人数</TableHead>
                  <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">分配人数</TableHead>
                  <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">计划工位数</TableHead>
                  <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">计划空间数</TableHead>
                  <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {locationData.map((record) => (
                  <TableRow key={record.id} className="hover:bg-gray-50">
                    <TableCell className="text-xs text-gray-900 text-center">{record.city}</TableCell>
                    <TableCell className="text-xs text-gray-900 text-center">{record.hcCount}</TableCell>
                    <TableCell className="text-xs text-gray-900 text-center">{record.allocatedCount}</TableCell>
                    <TableCell className="text-xs text-gray-900 text-center">{record.estimatedCount}</TableCell>
                    <TableCell className="text-xs text-gray-900 text-center">{record.independentSpaceCount}</TableCell>
                    <TableCell className="text-xs text-center">
                      <Button 
                        variant="link" 
                        size="sm" 
                        className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                      >
                        {record.action}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}