import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Button } from "../ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { ArrowUpIcon, ArrowDownIcon, TrendingUp, TrendingDown } from "lucide-react";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

// 模拟数据
const summaryMetricsData = {
  revenue: { current: 12500000, ytd: 98500000, growth: 15.2 },
  cost: { current: 8900000, ytd: 68200000, growth: 8.7 },
  profit: { current: 3600000, ytd: 30300000, growth: 28.5 }
};

const monthlyTrendData = [
  { month: "1月", revenue: 8500000, cost: 6200000, profit: 2300000 },
  { month: "2月", revenue: 9200000, cost: 6800000, profit: 2400000 },
  { month: "3月", revenue: 10100000, cost: 7400000, profit: 2700000 },
  { month: "4月", revenue: 11200000, cost: 7900000, profit: 3300000 },
  { month: "5月", revenue: 11800000, cost: 8300000, profit: 3500000 },
  { month: "6月", revenue: 12500000, cost: 8900000, profit: 3600000 }
];

const expenseTypeData = [
  { name: "工位费用", actual: 4200000, budget: 4500000 },
  { name: "空间费用", actual: 2800000, budget: 3000000 },
  { name: "运营费用", actual: 1200000, budget: 1300000 },
  { name: "服务费用", actual: 700000, budget: 800000 }
];

// 收入按费用类型数据
const revenueTypeData = [
  { name: "工位收入", actual: 6800000, budget: 7000000 },
  { name: "空间收入", actual: 3200000, budget: 3500000 },
  { name: "运营收入", actual: 1800000, budget: 1900000 },
  { name: "服务收入", actual: 700000, budget: 900000 }
];

const regionData = [
  { name: "CHN", actual: 5800000, budget: 6000000 },
  { name: "AMS", actual: 1500000, budget: 1600000 },
  { name: "EMEA", actual: 1200000, budget: 1300000 },
  { name: "APAC", actual: 400000, budget: 500000 }
];

// 房产大区收入数据
const regionRevenueData = [
  { name: "CHN", actual: 8500000, budget: 9000000 },
  { name: "AMS", actual: 2200000, budget: 2400000 },
  { name: "EMEA", actual: 1800000, budget: 2000000 },
  { name: "APAC", actual: 700000, budget: 800000 }
];

const workAreaTableData = [
  { time: "2024-06", region: "CHN", country: "中国", city: "北京", workArea: "北京总部A栋", department: "技术部", revenue: 2800000, cost: 1900000, profit: 900000 },
  { time: "2024-06", region: "CHN", country: "中国", city: "北京", workArea: "北京总部B栋", department: "产品部", revenue: 2200000, cost: 1600000, profit: 600000 },
  { time: "2024-06", region: "AMS", country: "美国", city: "纽约", workArea: "纽约办公室", department: "销售部", revenue: 1500000, cost: 1100000, profit: 400000 },
  { time: "2024-06", region: "EMEA", country: "英国", city: "伦敦", workArea: "伦敦分部", department: "市场部", revenue: 1200000, cost: 800000, profit: 400000 }
];

const businessTableData = [
  { time: "2024-06", region: "CHN", country: "中国", city: "北京", department: "技术部", workArea: "北京总部A栋", revenue: 2800000, cost: 1900000, profit: 900000 },
  { time: "2024-06", region: "CHN", country: "中国", city: "北京", department: "产品部", workArea: "北京总部B栋", revenue: 2200000, cost: 1600000, profit: 600000 },
  { time: "2024-06", region: "AMS", country: "美国", city: "纽约", department: "销售部", workArea: "纽约办公室", revenue: 1500000, cost: 1100000, profit: 400000 },
  { time: "2024-06", region: "EMEA", country: "英国", city: "伦敦", department: "市场部", workArea: "伦敦分部", revenue: 1200000, cost: 800000, profit: 400000 }
];

// 收入数据
const revenueMetricsData = {
  total: { current: 12500000, ytd: 98500000, growth: 15.2 },
  workspace: { current: 6800000, ytd: 52000000, growth: 12.5 },
  space: { current: 3200000, ytd: 28500000, growth: 18.7 },
  operation: { current: 1800000, ytd: 12500000, growth: 22.3 },
  service: { current: 700000, ytd: 5500000, growth: 8.9 }
};

const revenueDetailData = {
  furniture: { current: 4200000, ytd: 32000000, growth: 14.2 },
  meeting: { current: 2600000, ytd: 20000000, growth: 10.8 },
  renovation: { current: 1800000, ytd: 14500000, growth: 18.5 },
  otherSpace: { current: 1200000, ytd: 9600000, growth: 12.3 },
  location: { current: 950000, ytd: 7300000, growth: 8.9 },
  otherSpaceSecond: { current: 680000, ytd: 5200000, growth: 15.6 },
  logoRemoval: { current: 420000, ytd: 3100000, growth: 22.4 },
  otherService: { current: 380000, ytd: 2800000, growth: 6.7 }
};

const revenueTrendData = [
  { month: "1月", total: 8500000, workspace: 4600000, space: 2200000, operation: 1200000, service: 500000 },
  { month: "2月", total: 9200000, workspace: 5000000, space: 2400000, operation: 1300000, service: 500000 },
  { month: "3月", total: 10100000, workspace: 5500000, space: 2700000, operation: 1400000, service: 500000 },
  { month: "4月", total: 11200000, workspace: 6100000, space: 2900000, operation: 1600000, service: 600000 },
  { month: "5月", total: 11800000, workspace: 6400000, space: 3100000, operation: 1700000, service: 600000 },
  { month: "6月", total: 12500000, workspace: 6800000, space: 3200000, operation: 1800000, service: 700000 }
];

// 区域收入数据
const areaRevenueData = [
  { area: "A区", zone: "研发中心", seats: 150, utilization: "85%", revenue: 280000, growth: "+12.5%" },
  { area: "B区", zone: "产品部", seats: 120, utilization: "78%", revenue: 220000, growth: "+8.3%" },
  { area: "C区", zone: "销售部", seats: 100, utilization: "92%", revenue: 320000, growth: "+15.8%" },
  { area: "D区", zone: "市场部", seats: 80, utilization: "75%", revenue: 180000, growth: "+5.2%" }
];

// 部门收入数据
const departmentRevenueData = [
  { department: "技术部", area: "A区", seats: 200, utilization: "88%", revenue: 420000, growth: "+18.3%" },
  { department: "产品部", area: "B区", seats: 150, utilization: "82%", revenue: 350000, growth: "+12.7%" },
  { department: "销售部", area: "C区", seats: 180, utilization: "95%", revenue: 480000, growth: "+22.1%" },
  { department: "市场部", area: "D区", seats: 120, utilization: "75%", revenue: 280000, growth: "+8.9%" }
];

// 成本数据
const costMetricsData = {
  total: { current: 8900000, ytd: 68200000, growth: 8.7 },
  workspace: { current: 4200000, ytd: 32500000, growth: 9.2 },
  engineering: { current: 2800000, ytd: 21800000, growth: 7.5 },
  operation: { current: 1500000, ytd: 11200000, growth: 12.3 },
  comprehensive: { current: 400000, ytd: 2700000, growth: 3.8 }
};

const costDetailData = {
  rent: { current: 2800000, ytd: 21000000, growth: 6.8 },
  furniture: { current: 1400000, ytd: 11500000, growth: 11.7 },
  renovation: { current: 2400000, ytd: 18600000, growth: 8.3 },
  staff: { current: 400000, ytd: 2900000, growth: 15.2 },
  property: { current: 900000, ytd: 6800000, growth: 9.5 },
  consultant: { current: 300000, ytd: 2200000, growth: 5.4 },
  ifm: { current: 200000, ytd: 1600000, growth: 18.7 },
  other: { current: 100000, ytd: 800000, growth: 2.1 }
};

const costTrendData = [
  { month: "1月", total: 6200000, workspace: 4200000, engineering: 1800000, operation: 180000, comprehensive: 20000 },
  { month: "2月", total: 6800000, workspace: 4500000, engineering: 1900000, operation: 185000, comprehensive: 215000 },
  { month: "3月", total: 7400000, workspace: 4800000, engineering: 2000000, operation: 190000, comprehensive: 410000 },
  { month: "4月", total: 7900000, workspace: 5100000, engineering: 2100000, operation: 195000, comprehensive: 505000 },
  { month: "5月", total: 8300000, workspace: 5400000, engineering: 2200000, operation: 200000, comprehensive: 500000 },
  { month: "6月", total: 8900000, workspace: 5700000, engineering: 2300000, operation: 205000, comprehensive: 695000 }
];

const formatCurrency = (value: number) => {
  return `¥${(value / 10000).toFixed(1)}万`;
};

const formatNumber = (value: number) => {
  return value.toLocaleString();
};

export function BusinessAnalysis() {
  const [activeTab, setActiveTab] = useState("summary");
  const [listTab, setListTab] = useState("workArea");
  const [revenueDetailTab, setRevenueDetailTab] = useState("area");
  
  const [region, setRegion] = useState("all");
  const [timeType, setTimeType] = useState("month");
  const [currency, setCurrency] = useState("cny");
  const [metricType, setMetricType] = useState("revenue"); // 新增指标切换状态
  const [regionMetricType, setRegionMetricType] = useState("revenue"); // 房产大区图表指标切换状态

  const MetricCard = ({ title, current, ytd, growth, prefix = "¥", showChart = false, currentGrowth, ytdGrowth }) => {
    // 收入占比数据
    const revenueBreakdownData = [
      { name: "工位收入", value: 6800000, color: "#0891b2" },
      { name: "空间收入", value: 3200000, color: "#1e40af" },
      { name: "运营收入", value: 1800000, color: "#60a5fa" },
      { name: "服务收入", value: 700000, color: "#6b7280" }
    ];

    // 成本占比数据
    const costBreakdownData = [
      { name: "工位成本", value: 4200000, color: "#dc2626" },
      { name: "工程成本", value: 2800000, color: "#ea580c" },
      { name: "运营成本", value: 1500000, color: "#d97706" },
      { name: "综合成本", value: 400000, color: "#9ca3af" }
    ];

    const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }) => {
      if (percent < 0.1) return null; // 小于10%不显示标签
      const RADIAN = Math.PI / 180;
      const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
      const x = cx + radius * Math.cos(-midAngle * RADIAN);
      const y = cy + radius * Math.sin(-midAngle * RADIAN);

      return (
        <text 
          x={x} 
          y={y} 
          fill="white" 
          textAnchor={x > cx ? 'start' : 'end'} 
          dominantBaseline="central"
          className="text-xs font-medium"
        >
          {`${(percent * 100).toFixed(0)}%`}
        </text>
      );
    };

    return (
      <Card className={`${title === "总成本" ? "bg-yellow-50" : title === "收支差" ? "bg-green-50" : "bg-blue-50"} border border-gray-200 h-full flex flex-col`}>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-gray-600 font-bold">{title}</CardTitle>
        </CardHeader>
        <CardContent className="pt-0 flex-1 flex flex-col justify-between">
          {showChart && title === "总收入" ? (
            <div className="flex-1 flex flex-col">
              {/* 上方：甜甜圈图区域 */}
              <div className="flex-1 flex flex-col items-center justify-center p-[-5px] mt-[-5px] mr-[-5px] mb-[0px] ml-[-5px]">
                <div className="h-40 w-40">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={revenueBreakdownData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={renderCustomizedLabel}
                        outerRadius={60}
                        innerRadius={36}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {revenueBreakdownData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                
                {/* 图例 */}
                <div className="flex justify-center gap-3 mt-[7px] flex-wrap px-[-5px] py-[0px] mr-[-5px] mb-[0px] ml-[-5px]">
                  {revenueBreakdownData.map((item, index) => (
                    <div key={index} className="flex items-center gap-1">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }}></div>
                      <span className="text-xs text-gray-600">{item.name}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* 下方：数据区域 */}
              <div className="space-y-2 mt-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">本期:</span>
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-medium text-gray-900">
                      {prefix}{formatNumber(current)}
                    </span>
                    <div className="flex items-center gap-1">
                      {(currentGrowth || growth) > 0 ? (
                        <ArrowUpIcon className="h-3 w-3 text-green-500" />
                      ) : (
                        <ArrowDownIcon className="h-3 w-3 text-red-500" />
                      )}
                      <span className={`text-xs ${(currentGrowth || growth) > 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {(currentGrowth || growth) > 0 ? '+' : ''}{currentGrowth || growth}%
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">年累计:</span>
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-medium text-gray-900">
                      {prefix}{formatNumber(ytd)}
                    </span>
                    <div className="flex items-center gap-1">
                      {(ytdGrowth || growth) > 0 ? (
                        <ArrowUpIcon className="h-3 w-3 text-green-500" />
                      ) : (
                        <ArrowDownIcon className="h-3 w-3 text-red-500" />
                      )}
                      <span className={`text-xs ${(ytdGrowth || growth) > 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {(ytdGrowth || growth) > 0 ? '+' : ''}{ytdGrowth || growth}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : showChart && title === "总成本" ? (
            <div className="flex-1 flex flex-col">
              {/* 上方：甜甜圈图区域 */}
              <div className="flex-1 flex flex-col items-center justify-center p-[-5px] mt-[-5px] mr-[-5px] mb-[0px] ml-[-5px]">
                <div className="h-40 w-40">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={costBreakdownData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={renderCustomizedLabel}
                        outerRadius={60}
                        innerRadius={36}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {costBreakdownData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                
                {/* 图例 */}
                <div className="flex justify-center gap-3 mt-[7px] flex-wrap px-[-5px] py-[0px] mr-[-5px] mb-[0px] ml-[-5px]">
                  {costBreakdownData.map((item, index) => (
                    <div key={index} className="flex items-center gap-1">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }}></div>
                      <span className="text-xs text-gray-600">{item.name}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* 下方：数据区域 */}
              <div className="space-y-2 mt-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">本期:</span>
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-medium text-gray-900">
                      {prefix}{formatNumber(current)}
                    </span>
                    <div className="flex items-center gap-1">
                      {(currentGrowth || growth) > 0 ? (
                        <ArrowUpIcon className="h-3 w-3 text-green-500" />
                      ) : (
                        <ArrowDownIcon className="h-3 w-3 text-red-500" />
                      )}
                      <span className={`text-xs ${(currentGrowth || growth) > 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {(currentGrowth || growth) > 0 ? '+' : ''}{currentGrowth || growth}%
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">年累计:</span>
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-medium text-gray-900">
                      {prefix}{formatNumber(ytd)}
                    </span>
                    <div className="flex items-center gap-1">
                      {(ytdGrowth || growth) > 0 ? (
                        <ArrowUpIcon className="h-3 w-3 text-green-500" />
                      ) : (
                        <ArrowDownIcon className="h-3 w-3 text-red-500" />
                      )}
                      <span className={`text-xs ${(ytdGrowth || growth) > 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {(ytdGrowth || growth) > 0 ? '+' : ''}{ytdGrowth || growth}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">本期:</span>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-medium text-gray-900">
                    {prefix}{formatNumber(current)}
                  </span>
                  <div className="flex items-center gap-1">
                    {(currentGrowth || growth) > 0 ? (
                      <ArrowUpIcon className="h-3 w-3 text-green-500" />
                    ) : (
                      <ArrowDownIcon className="h-3 w-3 text-red-500" />
                    )}
                    <span className={`text-xs ${(currentGrowth || growth) > 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {(currentGrowth || growth) > 0 ? '+' : ''}{currentGrowth || growth}%
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">年累计:</span>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-medium text-gray-900">
                    {prefix}{formatNumber(ytd)}
                  </span>
                  <div className="flex items-center gap-1">
                    {(ytdGrowth || growth) > 0 ? (
                      <ArrowUpIcon className="h-3 w-3 text-green-500" />
                    ) : (
                      <ArrowDownIcon className="h-3 w-3 text-red-500" />
                    )}
                    <span className={`text-xs ${(ytdGrowth || growth) > 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {(ytdGrowth || growth) > 0 ? '+' : ''}{ytdGrowth || growth}%
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  const renderFilters = () => (
    <div className="flex items-center gap-4 mb-[21px] mt-[-15px] mr-[0px] ml-[0px]">
      <div>
        <Select value={region} onValueChange={setRegion}>
          <SelectTrigger className="w-32 h-6 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部大区</SelectItem>
            <SelectItem value="CHN">CHN</SelectItem>
            <SelectItem value="AMS">AMS</SelectItem>
            <SelectItem value="EMEA">EMEA</SelectItem>
            <SelectItem value="APAC">APAC</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <Select value={timeType} onValueChange={setTimeType}>
          <SelectTrigger className="w-24 h-6 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="month">月</SelectItem>
            <SelectItem value="quarter">季</SelectItem>
            <SelectItem value="half">半年</SelectItem>
            <SelectItem value="year">年</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <Select value={currency} onValueChange={setCurrency}>
          <SelectTrigger className="w-24 h-6 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="cny">人民币</SelectItem>
            <SelectItem value="usd">美元</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );

  return (
    <div className="flex-1 overflow-auto" style={{ maxWidth: '1300px', margin: '0 auto' }}>
      <div className="space-y-6 p-[0px]">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-medium">经营分析</h1>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="inline-flex mb-6">
            <TabsTrigger value="summary" className="text-xs">汇总</TabsTrigger>
            <TabsTrigger value="revenue" className="text-xs">收入</TabsTrigger>
            <TabsTrigger value="cost" className="text-xs">成本</TabsTrigger>
          </TabsList>

          {/* 全局筛选器 */}
          {renderFilters()}

          {/* 汇总标签页 */}
          <TabsContent value="summary" className="space-y-6">
            
            {/* 统计区域 */}
            <div className="space-y-6">
              {/* 第1行：大指标 */}
              <div className="grid grid-cols-3 gap-6">
                <MetricCard 
                  title="总收入" 
                  current={summaryMetricsData.revenue.current}
                  ytd={summaryMetricsData.revenue.ytd}
                  growth={summaryMetricsData.revenue.growth}
                  currentGrowth={12.8}
                  ytdGrowth={15.2}
                />
                <MetricCard 
                  title="总成本" 
                  current={summaryMetricsData.cost.current}
                  ytd={summaryMetricsData.cost.ytd}
                  growth={summaryMetricsData.cost.growth}
                  currentGrowth={6.5}
                  ytdGrowth={8.7}
                />
                <MetricCard 
                  title="收支差" 
                  current={summaryMetricsData.profit.current}
                  ytd={summaryMetricsData.profit.ytd}
                  growth={summaryMetricsData.profit.growth}
                  currentGrowth={25.3}
                  ytdGrowth={28.5}
                />
              </div>

              {/* 第2行：月度趋势图 */}
              <Card className="bg-white border border-gray-200 mt-[0px] mr-[0px] mb-[21px] ml-[0px]">
                <CardHeader>
                  <CardTitle className="text-sm">月度趋势</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={monthlyTrendData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" className="text-xs" />
                        <YAxis className="text-xs" tickFormatter={formatCurrency} />
                        <Tooltip formatter={(value) => formatCurrency(value)} />
                        <Legend />
                        <Line type="monotone" dataKey="revenue" stroke="#3b82f6" name="总收入" strokeWidth={2} />
                        <Line type="monotone" dataKey="cost" stroke="#ef4444" name="总成本" strokeWidth={2} />
                        <Line type="monotone" dataKey="profit" stroke="#10b981" name="收支差" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* 第3行：对比图表 */}
              <div className="grid grid-cols-2 gap-6">
                <Card className="bg-white border border-gray-200">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm">按费用类型 vs 预算</CardTitle>
                    <Select value={metricType} onValueChange={setMetricType}>
                      <SelectTrigger className="w-20 h-7 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="revenue">收入</SelectItem>
                        <SelectItem value="cost">成本</SelectItem>
                      </SelectContent>
                    </Select>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={metricType === "revenue" ? revenueTypeData : expenseTypeData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" className="text-xs" />
                          <YAxis className="text-xs" tickFormatter={formatCurrency} />
                          <Tooltip formatter={(value) => formatCurrency(value)} />
                          <Legend />
                          <Bar dataKey="actual" fill="#3b82f6" name="实际" />
                          <Bar dataKey="budget" fill="#e5e7eb" name="预算" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white border border-gray-200">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm">按房产大区 vs 预算</CardTitle>
                    <Select value={regionMetricType} onValueChange={setRegionMetricType}>
                      <SelectTrigger className="w-20 h-7 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="revenue">收入</SelectItem>
                        <SelectItem value="cost">成本</SelectItem>
                      </SelectContent>
                    </Select>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={regionMetricType === "revenue" ? regionRevenueData : regionData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" className="text-xs" />
                          <YAxis className="text-xs" tickFormatter={formatCurrency} />
                          <Tooltip formatter={(value) => formatCurrency(value)} />
                          <Legend />
                          <Bar dataKey="actual" fill="#3b82f6" name="实际" />
                          <Bar dataKey="budget" fill="#e5e7eb" name="预算" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* 第4行：职场列表 */}
            <Card className="bg-white border border-gray-200">
              <CardHeader>
                <CardTitle className="text-sm font-bold">职场列表</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs value={listTab} onValueChange={setListTab} className="w-full">
                  <TabsList className="mb-4 w-fit h-auto p-1">
                    <TabsTrigger value="workArea" className="text-xs">职场</TabsTrigger>
                    <TabsTrigger value="business" className="text-xs">业务线</TabsTrigger>
                  </TabsList>
                  <TabsContent value={listTab} className="mt-4">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-muted/50">
                          <TableHead className="text-xs">时间</TableHead>
                          <TableHead className="text-xs">大区</TableHead>
                          <TableHead className="text-xs">国家</TableHead>
                          <TableHead className="text-xs">城市</TableHead>
                          <TableHead className="text-xs">{listTab === "workArea" ? "职场" : "部门"}</TableHead>
                          <TableHead className="text-xs">{listTab === "workArea" ? "部门" : "职场"}</TableHead>
                          <TableHead className="text-xs">收入</TableHead>
                          <TableHead className="text-xs">成本</TableHead>
                          <TableHead className="text-xs">收支差</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {(listTab === "workArea" ? workAreaTableData : businessTableData).map((item, index) => (
                          <TableRow key={index} className="hover:bg-muted/30">
                            <TableCell className="text-xs">{item.time}</TableCell>
                            <TableCell className="text-xs">{item.region}</TableCell>
                            <TableCell className="text-xs">{item.country}</TableCell>
                            <TableCell className="text-xs">{item.city}</TableCell>
                            <TableCell className="text-xs">{listTab === "workArea" ? item.workArea : item.department}</TableCell>
                            <TableCell className="text-xs">{listTab === "workArea" ? item.department : item.workArea}</TableCell>
                            <TableCell className="text-xs">{formatCurrency(item.revenue)}</TableCell>
                            <TableCell className="text-xs">{formatCurrency(item.cost)}</TableCell>
                            <TableCell className="text-xs">{formatCurrency(item.profit)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
            </div>
          </TabsContent>

          {/* 收入标签页 */}
          <TabsContent value="revenue" className="space-y-6">
            {/* 统计区域 */}
            <div className="grid grid-cols-5 gap-6">
              <MetricCard 
                title="总收入" 
                current={revenueMetricsData.total.current}
                ytd={revenueMetricsData.total.ytd}
                growth={revenueMetricsData.total.growth}
                showChart={true}
              />
              <MetricCard 
                title="工位收入" 
                current={revenueMetricsData.workspace.current}
                ytd={revenueMetricsData.workspace.ytd}
                growth={revenueMetricsData.workspace.growth}
              />
              <MetricCard 
                title="空间收入" 
                current={revenueMetricsData.space.current}
                ytd={revenueMetricsData.space.ytd}
                growth={revenueMetricsData.space.growth}
              />
              <MetricCard 
                title="运营收入" 
                current={revenueMetricsData.operation.current}
                ytd={revenueMetricsData.operation.ytd}
                growth={revenueMetricsData.operation.growth}
              />
              <MetricCard 
                title="服务收入" 
                current={revenueMetricsData.service.current}
                ytd={revenueMetricsData.service.ytd}
                growth={revenueMetricsData.service.growth}
              />
            </div>

            {/* 趋势图区域 */}
            <Card className="bg-white border border-gray-200">
              <CardHeader>
                <CardTitle className="text-sm">收入趋势</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={revenueTrendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" className="text-xs" />
                      <YAxis className="text-xs" tickFormatter={formatCurrency} />
                      <Tooltip formatter={(value) => formatCurrency(value)} />
                      <Legend />
                      <Line type="monotone" dataKey="total" stroke="#3b82f6" name="总收入" strokeWidth={2} />
                      <Line type="monotone" dataKey="workspace" stroke="#10b981" name="工位收入" strokeWidth={2} />
                      <Line type="monotone" dataKey="space" stroke="#f59e0b" name="空间收入" strokeWidth={2} />
                      <Line type="monotone" dataKey="operation" stroke="#ef4444" name="运营收入" strokeWidth={2} />
                      <Line type="monotone" dataKey="service" stroke="#8b5cf6" name="服务收入" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* 收入详细数据标签页 */}
            <Card className="bg-white border border-gray-200">
              <CardHeader>
                <CardTitle className="text-sm font-bold">职场列表</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs value={revenueDetailTab} onValueChange={setRevenueDetailTab} className="w-full">
                  <TabsList className="mb-4 w-fit h-auto p-1">
                    <TabsTrigger value="area" className="text-xs">区域</TabsTrigger>
                    <TabsTrigger value="department" className="text-xs">部门</TabsTrigger>
                  </TabsList>
                  <TabsContent value={revenueDetailTab} className="mt-4">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-muted/50">
                          <TableHead className="text-xs">{revenueDetailTab === "area" ? "区域" : "部门"}</TableHead>
                          <TableHead className="text-xs">{revenueDetailTab === "area" ? "功能区" : "区域"}</TableHead>
                          <TableHead className="text-xs">工位数</TableHead>
                          <TableHead className="text-xs">使用率</TableHead>
                          <TableHead className="text-xs">收入</TableHead>
                          <TableHead className="text-xs">增长率</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {(revenueDetailTab === "area" ? areaRevenueData : departmentRevenueData).map((item, index) => (
                          <TableRow key={index} className="hover:bg-muted/30">
                            <TableCell className="text-xs">{item.area || item.department}</TableCell>
                            <TableCell className="text-xs">{item.zone || item.area}</TableCell>
                            <TableCell className="text-xs">{item.seats}</TableCell>
                            <TableCell className="text-xs">{item.utilization}</TableCell>
                            <TableCell className="text-xs">{formatCurrency(item.revenue)}</TableCell>
                            <TableCell className="text-xs text-green-600">{item.growth}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </TabsContent>

          {/* 成本标签页 */}
          <TabsContent value="cost" className="space-y-6">
            {/* 统计区域 */}
            <div className="grid grid-cols-5 gap-6">
              <MetricCard 
                title="总成本" 
                current={costMetricsData.total.current}
                ytd={costMetricsData.total.ytd}
                growth={costMetricsData.total.growth}
                showChart={true}
              />
              <MetricCard 
                title="工位成本" 
                current={costMetricsData.workspace.current}
                ytd={costMetricsData.workspace.ytd}
                growth={costMetricsData.workspace.growth}
              />
              <MetricCard 
                title="工程成本" 
                current={costMetricsData.engineering.current}
                ytd={costMetricsData.engineering.ytd}
                growth={costMetricsData.engineering.growth}
              />
              <MetricCard 
                title="运营成本" 
                current={costMetricsData.operation.current}
                ytd={costMetricsData.operation.ytd}
                growth={costMetricsData.operation.growth}
              />
              <MetricCard 
                title="综合成本" 
                current={costMetricsData.comprehensive.current}
                ytd={costMetricsData.comprehensive.ytd}
                growth={costMetricsData.comprehensive.growth}
              />
            </div>

            {/* 趋势图区域 */}
            <Card className="bg-white border border-gray-200">
              <CardHeader>
                <CardTitle className="text-sm">成本趋势</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={costTrendData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" className="text-xs" />
                      <YAxis className="text-xs" tickFormatter={formatCurrency} />
                      <Tooltip formatter={(value) => formatCurrency(value)} />
                      <Legend />
                      <Line type="monotone" dataKey="total" stroke="#ef4444" name="总成本" strokeWidth={2} />
                      <Line type="monotone" dataKey="workspace" stroke="#dc2626" name="工位成本" strokeWidth={2} />
                      <Line type="monotone" dataKey="engineering" stroke="#ea580c" name="工程成本" strokeWidth={2} />
                      <Line type="monotone" dataKey="operation" stroke="#d97706" name="运营成本" strokeWidth={2} />
                      <Line type="monotone" dataKey="comprehensive" stroke="#9ca3af" name="综合成本" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* 成本详细数据 */}
            <div className="grid grid-cols-2 gap-6">
              <Card className="bg-white border border-gray-200">
                <CardHeader>
                  <CardTitle className="text-sm">成本明细</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-600">租金</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs">{formatCurrency(costDetailData.rent.current)}</span>
                        <span className="text-xs text-green-600">+{costDetailData.rent.growth}%</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-600">家具</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs">{formatCurrency(costDetailData.furniture.current)}</span>
                        <span className="text-xs text-green-600">+{costDetailData.furniture.growth}%</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-600">装修</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs">{formatCurrency(costDetailData.renovation.current)}</span>
                        <span className="text-xs text-green-600">+{costDetailData.renovation.growth}%</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-600">人员</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs">{formatCurrency(costDetailData.staff.current)}</span>
                        <span className="text-xs text-green-600">+{costDetailData.staff.growth}%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white border border-gray-200">
                <CardHeader>
                  <CardTitle className="text-sm">其他成本</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-600">物业</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs">{formatCurrency(costDetailData.property.current)}</span>
                        <span className="text-xs text-green-600">+{costDetailData.property.growth}%</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-600">咨询</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs">{formatCurrency(costDetailData.consultant.current)}</span>
                        <span className="text-xs text-green-600">+{costDetailData.consultant.growth}%</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-600">IFM</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs">{formatCurrency(costDetailData.ifm.current)}</span>
                        <span className="text-xs text-green-600">+{costDetailData.ifm.growth}%</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-600">其他</span>
                      <div className="flex items-center gap-2">
                        <span className="text-xs">${formatCurrency(costDetailData.other.current)}</span>
                        <span className="text-xs text-green-600">+{costDetailData.other.growth}%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}