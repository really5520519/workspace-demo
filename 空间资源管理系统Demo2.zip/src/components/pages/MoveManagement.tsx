import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { TablePagination } from "../ui/table-pagination";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "../ui/breadcrumb";
import { 
  Plus, 
  Search, 
  FileText, 
  Clock,
  CheckCircle, 
  AlertCircle
} from "lucide-react";

// 统计卡片数据
const statisticsData = [
  {
    title: "待办区",
    value: "8",
    unit: "",
    isSpecial: true,
    subtitle: "待处理搬家需求数量",
    hasAction: true
  },
  {
    title: "项目合计",
    value: "205",
    unit: "",
    isSpecial: false
  },
  {
    title: "待处理搬家",
    value: "5",
    unit: "",
    isSpecial: false
  },
  {
    title: "进行中",
    value: "12",
    unit: "",
    isSpecial: false
  },
  {
    title: "已完成",
    value: "180",
    unit: "",
    isSpecial: false
  }
];

// 搬家列表数据
const moveData = [
  {
    projectId: "MOV-2025-007",
    demandId: "REQ-2025-020",
    demandSide: "业务",
    stage: "特搬家",
    status: "进行中",
    statusColor: "bg-blue-100 text-blue-800",
    moveOutLocation: "A座-5F",
    moveOutCount: 50,
    moveInLocation: "B座-10F",
    moveInCount: 50,
    plannedMoveTime: "2025-09-15",
    actualCompletionTime: "2024-08-01",
    lastUpdateTime: "2024-08-03",
    actions: ["查看"]
  },
  {
    projectId: "MOV-2025-006",
    demandId: "REQ-2025-019",
    demandSide: "技术",
    stage: "常规搬家",
    status: "已完成",
    statusColor: "bg-green-100 text-green-800",
    moveOutLocation: "C座-3F",
    moveOutCount: 25,
    moveInLocation: "A座-8F",
    moveInCount: 25,
    plannedMoveTime: "2025-08-20",
    actualCompletionTime: "2024-08-18",
    lastUpdateTime: "2024-08-19",
    actions: ["查看", "详情"]
  },
  {
    projectId: "MOV-2025-005",
    demandId: "REQ-2025-018",
    demandSide: "行政",
    stage: "紧急搬家",
    status: "待处理",
    statusColor: "bg-orange-100 text-orange-800",
    moveOutLocation: "B座-12F",
    moveOutCount: 80,
    moveInLocation: "D座-6F",
    moveInCount: 80,
    plannedMoveTime: "2025-09-30",
    actualCompletionTime: "-",
    lastUpdateTime: "2024-08-05",
    actions: ["查看", "编辑"]
  },
  {
    projectId: "MOV-2025-004",
    demandId: "REQ-2025-017",
    demandSide: "业务",
    stage: "特搬家",
    status: "已暂停",
    statusColor: "bg-red-100 text-red-800",
    moveOutLocation: "A座-2F",
    moveOutCount: 35,
    moveInLocation: "C座-9F",
    moveInCount: 35,
    plannedMoveTime: "2025-10-10",
    actualCompletionTime: "-",
    lastUpdateTime: "2024-08-02",
    actions: ["查看", "恢复"]
  },
  {
    projectId: "MOV-2025-003",
    demandId: "REQ-2025-016",
    demandSide: "技术",
    stage: "常规搬家",
    status: "进行中",
    statusColor: "bg-blue-100 text-blue-800",
    moveOutLocation: "D座-4F",
    moveOutCount: 60,
    moveInLocation: "B座-7F",
    moveInCount: 60,
    plannedMoveTime: "2025-09-05",
    actualCompletionTime: "-",
    lastUpdateTime: "2024-08-04",
    actions: ["查看"]
  },
  {
    projectId: "MOV-2025-002",
    demandId: "REQ-2025-015",
    demandSide: "行政",
    stage: "常规搬家",
    status: "已完成",
    statusColor: "bg-green-100 text-green-800",
    moveOutLocation: "C座-11F",
    moveOutCount: 40,
    moveInLocation: "A座-6F",
    moveInCount: 40,
    plannedMoveTime: "2025-08-15",
    actualCompletionTime: "2024-08-14",
    lastUpdateTime: "2024-08-15",
    actions: ["查看", "详情"]
  },
  {
    projectId: "MOV-2025-001",
    demandId: "REQ-2025-014",
    demandSide: "业务",
    stage: "紧急搬家",
    status: "待审核",
    statusColor: "bg-yellow-100 text-yellow-800",
    moveOutLocation: "B座-1F",
    moveOutCount: 20,
    moveInLocation: "D座-12F",
    moveInCount: 20,
    plannedMoveTime: "2025-09-25",
    actualCompletionTime: "-",
    lastUpdateTime: "2024-08-01",
    actions: ["查看", "审核"]
  },
  {
    projectId: "MOV-2024-156",
    demandId: "REQ-2024-298",
    demandSide: "技术",
    stage: "特搬家",
    status: "已完成",
    statusColor: "bg-green-100 text-green-800",
    moveOutLocation: "A座-10F",
    moveOutCount: 90,
    moveInLocation: "C座-5F",
    moveInCount: 90,
    plannedMoveTime: "2024-07-30",
    actualCompletionTime: "2024-07-28",
    lastUpdateTime: "2024-07-30",
    actions: ["查看", "详情"]
  },
  {
    projectId: "MOV-2024-155",
    demandId: "REQ-2024-297",
    demandSide: "行政",
    stage: "常规搬家",
    status: "进行中",
    statusColor: "bg-blue-100 text-blue-800",
    moveOutLocation: "D座-8F",
    moveOutCount: 45,
    moveInLocation: "B座-3F",
    moveInCount: 45,
    plannedMoveTime: "2025-08-28",
    actualCompletionTime: "-",
    lastUpdateTime: "2024-08-06",
    actions: ["查看", "编辑"]
  },
  {
    projectId: "MOV-2024-154",
    demandId: "REQ-2024-296",
    demandSide: "业务",
    stage: "紧急搬家",
    status: "已完成",
    statusColor: "bg-green-100 text-green-800",
    moveOutLocation: "C座-7F",
    moveOutCount: 70,
    moveInLocation: "A座-4F",
    moveInCount: 70,
    plannedMoveTime: "2024-07-25",
    actualCompletionTime: "2024-07-24",
    lastUpdateTime: "2024-07-26",
    actions: ["查看", "详情"]
  }
];

// 状态徽章配色
const getStatusBadge = (status: string, colorClass: string) => {
  return <Badge variant="default" className={`${colorClass} hover:${colorClass}`}>{status}</Badge>;
};

interface MoveManagementProps {
  onNavigate?: (targetId: string, data?: any) => void;
}

export function MoveManagementContent({ onNavigate }: MoveManagementProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [activeTab, setActiveTab] = useState("move-in");
  const totalItems = 197; // 模拟总条数

  return (
    <div className="space-y-6">


      {/* 页面标题 */}
      <div>
        <h1 className="text-lg font-medium">搬家管理</h1>
        <p className="text-sm text-muted-foreground mt-1">管理和查看所有搬家项目及明细</p>
      </div>

      {/* 统计卡片区域 */}
      <div className="grid grid-cols-5 gap-4">
        {statisticsData.map((item, index) => (
          <Card key={index} className={`hover:shadow-md transition-shadow ${item.isSpecial ? 'border-2 border-orange-200 bg-orange-50' : ''}`}>
            <CardContent className="p-4">
              {item.isSpecial ? (
                <div className="text-center">
                  <p className="text-sm text-gray-600 mb-1">{item.title}</p>
                  <p className="text-sm text-gray-500 mb-2">{item.subtitle}</p>
                  <p className="text-2xl font-semibold">{item.value}</p>
                </div>
              ) : (
                <div className="text-center">
                  <p className="text-sm text-gray-600 mb-1">{item.title}</p>
                  <p className="text-2xl font-semibold">{item.value}{item.unit}</p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 搬家列表区域 */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-bold">
              搬家列表
            </CardTitle>
            <Button size="sm" className="h-8 text-sm bg-blue-600 hover:bg-blue-700 text-white">
              <Plus className="h-4 w-4 mr-1" />
              新建搬家
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-[0px] pr-[21px] pb-[21px] pl-[21px] mt-[-21px] mr-[0px] mb-[0px] ml-[0px]">
          {/* 工区标签页 */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-auto">
            <TabsList className="mb-4">
              <TabsTrigger value="move-in" className="text-sm">
                搬入工区
              </TabsTrigger>
              <TabsTrigger value="move-out" className="text-sm">
                搬出工区
              </TabsTrigger>
            </TabsList>

            <TabsContent value="move-in" className="mt-0">
              {/* 搬家列表数据表格 */}
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-sm font-medium">项目ID</TableHead>
                      <TableHead className="text-sm font-medium">需求ID</TableHead>
                      <TableHead className="text-sm font-medium">需求方</TableHead>
                      <TableHead className="text-sm font-medium">阶段</TableHead>
                      <TableHead className="text-sm font-medium">状态</TableHead>
                      <TableHead className="text-sm font-medium">搬出工区-楼层</TableHead>
                      <TableHead className="text-sm font-medium">搬出人数</TableHead>
                      <TableHead className="text-sm font-medium">搬入工区-楼层</TableHead>
                      <TableHead className="text-sm font-medium">搬入人数</TableHead>
                      <TableHead className="text-sm font-medium">计划搬家时间</TableHead>
                      <TableHead className="text-sm font-medium">实际完成时间</TableHead>
                      <TableHead className="text-sm font-medium">最交时间</TableHead>
                      <TableHead className="text-sm font-medium">最近更新时间</TableHead>
                      <TableHead className="text-sm font-medium">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {moveData.map((item, index) => (
                      <TableRow key={index} className="hover:bg-muted/30">
                        <TableCell 
                          className="text-sm font-mono text-blue-600 hover:text-blue-700 cursor-pointer"
                          onClick={() => onNavigate?.("project-details", { projectId: item.projectId })}
                        >
                          {item.projectId}
                        </TableCell>
                        <TableCell className="text-sm font-mono text-blue-600 hover:text-blue-700 cursor-pointer">{item.demandId}</TableCell>
                        <TableCell className="text-sm">{item.demandSide}</TableCell>
                        <TableCell className="text-sm">{item.stage}</TableCell>
                        <TableCell>{getStatusBadge(item.status, item.statusColor)}</TableCell>
                        <TableCell className="text-sm">{item.moveOutLocation}</TableCell>
                        <TableCell className="text-sm">{item.moveOutCount}</TableCell>
                        <TableCell className="text-sm">{item.moveInLocation}</TableCell>
                        <TableCell className="text-sm">{item.moveInCount}</TableCell>
                        <TableCell className="text-sm">{item.plannedMoveTime}</TableCell>
                        <TableCell className="text-sm">{item.actualCompletionTime}</TableCell>
                        <TableCell className="text-sm">{item.lastUpdateTime}</TableCell>
                        <TableCell className="text-sm">{item.lastUpdateTime}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            {item.actions.map((action, actionIndex) => (
                              <Button 
                                key={actionIndex}
                                variant="ghost" 
                                size="sm" 
                                className="h-7 text-xs text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                              >
                                {action}
                              </Button>
                            ))}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="move-out" className="mt-0">
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-sm font-medium">工区名称</TableHead>
                      <TableHead className="text-sm font-medium">楼层</TableHead>
                      <TableHead className="text-sm font-medium">搬出人数</TableHead>
                      <TableHead className="text-sm font-medium">剩余工位</TableHead>
                      <TableHead className="text-sm font-medium">使用率</TableHead>
                      <TableHead className="text-sm font-medium">预计搬出时间</TableHead>
                      <TableHead className="text-sm font-medium">负责人</TableHead>
                      <TableHead className="text-sm font-medium">状态</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow className="hover:bg-muted/30">
                      <TableCell className="text-sm">A座</TableCell>
                      <TableCell className="text-sm">5F</TableCell>
                      <TableCell className="text-sm">50</TableCell>
                      <TableCell className="text-sm">70</TableCell>
                      <TableCell className="text-sm">60%</TableCell>
                      <TableCell className="text-sm">2025-09-18</TableCell>
                      <TableCell className="text-sm">陈经理</TableCell>
                      <TableCell><Badge variant="default" className="bg-blue-100 text-blue-800">搬出中</Badge></TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/30">
                      <TableCell className="text-sm">C座</TableCell>
                      <TableCell className="text-sm">3F</TableCell>
                      <TableCell className="text-sm">25</TableCell>
                      <TableCell className="text-sm">95</TableCell>
                      <TableCell className="text-sm">80%</TableCell>
                      <TableCell className="text-sm">2025-08-22</TableCell>
                      <TableCell className="text-sm">赵主管</TableCell>
                      <TableCell><Badge variant="default" className="bg-green-100 text-green-800">已搬出</Badge></TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-muted/30">
                      <TableCell className="text-sm">B座</TableCell>
                      <TableCell className="text-sm">12F</TableCell>
                      <TableCell className="text-sm">80</TableCell>
                      <TableCell className="text-sm">40</TableCell>
                      <TableCell className="text-sm">30%</TableCell>
                      <TableCell className="text-sm">2025-10-02</TableCell>
                      <TableCell className="text-sm">孙总监</TableCell>
                      <TableCell><Badge variant="default" className="bg-orange-100 text-orange-800">准备中</Badge></TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>

          <TablePagination
            total={totalItems}
            currentPage={currentPage}
            pageSize={pageSize}
            onPageChange={setCurrentPage}
            onPageSizeChange={setPageSize}
          />
        </CardContent>
      </Card>
    </div>
  );
}