
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../ui/card";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import { Button } from "../ui/button";
import { MapPin, ChevronRight, Truck, X } from "lucide-react";
import { Badge } from "../ui/badge";
import { TablePagination } from "../ui/table-pagination";
import { useState } from "react";

export function MovePlanContent() {
  const [showNotification, setShowNotification] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const totalItems = 25; // 模拟总条数
  const historyData = [
    {
      id: "1",
      applicationTime: "2024-01-19",
      status: "进行中",
      startTime: "2024-01-16",
      completionTime: "2024-01-18",
      fromBuilding: "总部科技园开发中心 A-103",
      toBuilding: "北京望京西路",
      cost: "王安",
      responsibleArea: "王五",
      moveResponsible: "赵六"
    },
    {
      id: "2", 
      applicationTime: "2023-09-10",
      status: "已完成",
      startTime: "2023-09-01",
      completionTime: "2023-09-07",
      fromBuilding: "上海办公室 B-102",
      toBuilding: "北京总部",
      cost: "王安",
      responsibleArea: "刘八",
      moveResponsible: "孙九"
    }
  ];

  return (
    <div className="space-y-4">
      {/* 页面标题 */}
      <div>
        <h1 className="text-lg font-medium">搬家记录表单</h1>
      </div>

      {/* 搬家通知 */}
      {showNotification && (
        <div className="relative p-4 bg-yellow-50 rounded-lg">
          {/* 关闭按钮 */}
          <button
            onClick={() => setShowNotification(false)}
            className="absolute top-3 right-3 w-6 h-6 flex items-center justify-center rounded-full hover:bg-yellow-100 transition-colors"
          >
            <X className="h-4 w-4 text-gray-400 hover:text-gray-600" />
          </button>
          
          <div className="flex items-center gap-3">
            {/* 左侧图标 */}
            <div className="w-16 h-16 bg-[rgba(253,218,32,0.32)] rounded-lg flex items-center justify-center flex-shrink-0">
              <Truck className="h-8 w-8 text-yellow-600" />
            </div>
            
            {/* 右侧内容 */}
            <div className="flex-1 min-w-0">
              {/* 标题和时间 */}
              <div className="flex justify-between items-start mb-3 pr-8">
                <h3 className="text-sm font-medium text-gray-900">搬家通知</h3>
                <span className="text-xs text-gray-500">发送时间：2023-12-30 14:22:43</span>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-3">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-700">搬出工区-位置：</span>
                    <span className="text-xs font-medium text-gray-900">时尚方科-3F</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-700">计划搬出时间：</span>
                    <span className="text-xs font-medium text-gray-900">2026-05-04</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-700">搬入工区-位置：</span>
                    <span className="text-xs font-medium text-blue-600">e世界-1F-732</span>
                    <MapPin className="h-3 w-3 text-blue-600" />
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-700">计划搬入时间：</span>
                    <span className="text-xs font-medium text-gray-900">2026-05-10</span>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button size="sm" className="h-8 px-3 text-xs bg-blue-600 hover:bg-blue-700 text-white">
                  查看详情
                  <ChevronRight className="h-3 w-3 ml-1" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 搬家历史 */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium">搬家历史</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="text-xs">通知时间</TableHead>
                  <TableHead className="text-xs">状态</TableHead>
                  <TableHead className="text-xs">搬家起始时间</TableHead>
                  <TableHead className="text-xs">搬家完成时间</TableHead>
                  <TableHead className="text-xs">搬出楼宇</TableHead>
                  <TableHead className="text-xs">搬入楼宇</TableHead>
                  <TableHead className="text-xs">工位对接人</TableHead>
                  <TableHead className="text-xs">搬入对接人</TableHead>
                  <TableHead className="text-xs">搬出对接人</TableHead>
                  <TableHead className="text-xs">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {historyData.map((record) => (
                  <TableRow key={record.id}>
                    <TableCell className="text-xs">
                      {record.applicationTime}
                    </TableCell>
                    <TableCell className="text-xs">
                      <Badge 
                        variant={record.status === "已完成" ? "secondary" : "default"}
                        className={`text-xs h-5 ${
                          record.status === "已完成" 
                            ? "bg-green-100 text-green-700 hover:bg-green-100" 
                            : "bg-blue-100 text-blue-700 hover:bg-blue-100"
                        }`}
                      >
                        {record.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs">
                      {record.startTime}
                    </TableCell>
                    <TableCell className="text-xs">
                      {record.completionTime}
                    </TableCell>
                    <TableCell className="text-xs">
                      {record.fromBuilding}
                    </TableCell>
                    <TableCell className="text-xs">
                      {record.toBuilding}
                    </TableCell>
                    <TableCell className="text-xs">
                      {record.cost}
                    </TableCell>
                    <TableCell className="text-xs">
                      {record.responsibleArea}
                    </TableCell>
                    <TableCell className="text-xs">
                      {record.moveResponsible}
                    </TableCell>
                    <TableCell className="text-xs">
                      <div className="flex items-center gap-1">
                        <Button variant="link" size="sm" className="h-6 text-xs p-0">
                          查看详情
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            
            {historyData.length === 0 && (
              <div className="text-center py-8 text-muted-foreground text-xs">
                暂��搬家历史记录
              </div>
            )}
          </div>

          <TablePagination
            total={totalItems}
            currentPage={currentPage}
            pageSize={pageSize}
            onPageChange={setCurrentPage}
            onPageSizeChange={setPageSize}
          />
        </CardContent>
      </Card>
    </div>
  );
}