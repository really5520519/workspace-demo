import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { TablePagination } from "../ui/table-pagination";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer } from "recharts";
import { ChevronDown, ChevronRight } from "lucide-react";

export function SpaceBillingContent() {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [activeTab, setActiveTab] = useState("summary");
  const [expandedRows, setExpandedRows] = useState<string[]>([]);

  const toggleRowExpansion = (id: string) => {
    setExpandedRows(prev => 
      prev.includes(id) 
        ? prev.filter(rowId => rowId !== id)
        : [...prev, id]
    );
  };

  // 月度费用数据（年初到现在）
  const monthlyExpenseData = [
    { month: "1月", expense: 480000 },
    { month: "2月", expense: 520000 },
    { month: "3月", expense: 565000 },
    { month: "4月", expense: 542000 },
    { month: "5月", expense: 598000 },
    { month: "6月", expense: 612000 },
    { month: "7月", expense: 630000 }
  ];

  // 月度数据
  const monthlyData = [
    {
      id: "M-2024-07-001",
      period: "2024-07",
      department: "技术部",
      attribute: "资源类",
      category: "工位费用",
      city: "北京",
      workArea: "总部A栋",
      unitPrice: "1,200",
      quantity: "50",
      totalAmount: "60,000",
      isExpandable: true,
      children: [
        {
          id: "M-2024-07-001-001",
          period: "2024-07",
          department: "技术部",
          attribute: "资源类",
          category: "1.2m升降桌",
          city: "北京",
          workArea: "总部A栋",
          unitPrice: "1,100",
          quantity: "25",
          totalAmount: "27,500"
        },
        {
          id: "M-2024-07-001-002",
          period: "2024-07",
          department: "技术部",
          attribute: "资源类",
          category: "1.4m升降桌",
          city: "北京",
          workArea: "总部A栋",
          unitPrice: "1,300",
          quantity: "18",
          totalAmount: "23,400"
        }
      ]
    },
    {
      id: "M-2024-07-002",
      period: "2024-07",
      department: "产品部",
      attribute: "资源类",
      category: "会议室费用",
      city: "上海",
      workArea: "分部B栋",
      unitPrice: "80",
      quantity: "120",
      totalAmount: "9,600"
    }
  ];

  // 汇总数据
  const summaryData = [
    {
      id: "SUM202508001",
      period: "2024",
      attribute: "资源类",
      category: "工位费用",
      totalBudget: "3,200,000",
      actualCost: "2,400,000",
      department: "技术部",
      city: "北京",
      workArea: "总部A栋",
      usageUnit: "个",
      usage: "2,400",
      isExpandable: true,
      children: [
        {
          id: "SUM202508001001",
          period: "2024",
          attribute: "资源类",
          category: "平均费用",
          totalBudget: "1,000,000",
          actualCost: "750,000",
          department: "技术部",
          city: "北京",
          workArea: "总部A栋",
          usageUnit: "个",
          usage: "800"
        },
        {
          id: "SUM202508001002",
          period: "2024",
          attribute: "资源类",
          category: "1.2m升降桌",
          totalBudget: "1,200,000",
          actualCost: "920,000",
          department: "技术部",
          city: "北京",
          workArea: "总部A栋",
          usageUnit: "个",
          usage: "920"
        }
      ]
    },
    {
      id: "SUM202508002", 
      period: "2024",
      attribute: "资源类",
      category: "空间费用",
      totalBudget: "1,500,000",
      actualCost: "980,000",
      department: "产品部",
      city: "上海",
      workArea: "分部B栋",
      usageUnit: "㎡",
      usage: "3,250",
      isExpandable: true,
      children: [
        {
          id: "SUM202508002001",
          period: "2024",
          attribute: "资源类",
          category: "独立办公室",
          totalBudget: "1,200,000",
          actualCost: "800,000",
          department: "产品部",
          city: "上海",
          workArea: "分部B栋",
          usageUnit: "㎡",
          usage: "2,800"
        }
      ]
    }
  ];

  // 账单明细数据
  const billingData = [
    {
      id: "BILL-2024-001",
      status: "已确认",
      statusColor: "bg-green-100 text-green-800",
      costDepartment: "技术部",
      businessLine: "研发业务",
      city: "北京",
      workArea: "总部A栋",
      period: "2024-07",
      resourceType: "工位",
      billingType: "按月计费",
      billingUnit: "个",
      billingPeriod: "2024.7.1-2024.7.31",
      unitPrice: "1,200",
      usage: "50",
      usageArea: "1,500",
      totalRevenue: "60,000"
    },
    {
      id: "BILL-2024-002", 
      status: "待确认",
      statusColor: "bg-yellow-100 text-yellow-800",
      costDepartment: "产品部",
      businessLine: "产品业务",
      city: "上海",
      workArea: "分部B栋",
      period: "2024-07",
      resourceType: "会议室",
      billingType: "按天计费",
      billingUnit: "平米",
      billingPeriod: "2024.7.15-2024.7.31",
      unitPrice: "80",
      usage: "120",
      usageArea: "360",
      totalRevenue: "9,600"
    }
  ];

  return (
    <div className="space-y-4">
      {/* 页面标题 */}
      <div>
        <h1 className="text-lg font-medium">空间费用账单</h1>
      </div>

      {/* 统计区 - 1行4列 */}
      <div className="grid grid-cols-4 gap-4">
        {/* 第1列：甜甜圈图（预算vs实际） */}
        <Card className="bg-white border border-gray-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-900">预算vs实际</CardTitle>
          </CardHeader>
          <CardContent className="pt-0 h-full">
            <div className="flex flex-col items-center h-full">
              <div className="relative w-32 h-32 mb-4">
                <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 128 128">
                  <circle
                    cx="64"
                    cy="64"
                    r="56"
                    fill="none"
                    stroke="#e5e7eb"
                    strokeWidth="12"
                    strokeLinecap="round"
                  />
                  <circle
                    cx="64"
                    cy="64"
                    r="56"
                    fill="none"
                    stroke="#3b82f6"
                    strokeWidth="12"
                    strokeLinecap="round"
                    strokeDasharray="351.86"
                    strokeDashoffset="97.92"
                    className="transition-all duration-500 ease-in-out"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <div className="text-lg font-medium text-gray-900">72%</div>
                  <div className="text-xs text-gray-600">已使用</div>
                </div>
              </div>
              <div className="flex-1"></div>
              <div className="space-y-2 w-full">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-600">预算总额:</span>
                  <span className="text-xs font-medium text-blue-600">¥5,000,000</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-600">实际费用:</span>
                  <span className="text-xs font-medium text-green-600">¥3,600,000</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-600">剩余预算:</span>
                  <span className="text-xs font-medium text-orange-600">¥1,400,000</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 第2列：每月费用柱形图 */}
        <Card className="bg-white border border-gray-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-900">每月费用</CardTitle>
          </CardHeader>
          <CardContent className="pt-0 h-full">
            <div className="flex flex-col h-full">
              <div className="h-48 -ml-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthlyExpenseData} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                    <XAxis 
                      dataKey="month" 
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 12, fill: '#6b7280' }}
                    />
                    <YAxis 
                      axisLine={false}
                      tickLine={false}
                      tick={{ fontSize: 12, fill: '#6b7280' }}
                      tickFormatter={(value) => `${(value / 10000).toFixed(0)}万`}
                    />
                    <Bar 
                      dataKey="expense" 
                      fill="#3b82f6" 
                      radius={[4, 4, 0, 0]}
                      maxBarSize={32}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="flex-1"></div>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-600">本月费用:</span>
                  <span className="text-xs font-medium text-blue-600">¥630,000</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-600">平均月费用:</span>
                  <span className="text-xs font-medium text-gray-900">¥563,857</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-600">环比增长:</span>
                  <span className="text-xs font-medium text-green-600">+2.9%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 第3列：工位费用和空间费用指标块 */}
        <div className="flex flex-col h-full gap-4">
          <Card className="bg-white border border-gray-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-900">工位费用</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs text-gray-600">当前支出</span>
                  <span className="text-xs font-medium text-gray-900">¥2,400,000</span>
                </div>
                <Progress value={75} className="h-2" />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>预算: ¥3,200,000</span>
                  <span>75%</span>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-white border border-gray-200 flex-1">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-900">空间费用</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs text-gray-600">当前支出</span>
                  <span className="text-xs font-medium text-gray-900">¥800,000</span>
                </div>
                <Progress value={60} className="h-2" />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>预算: ¥1,200,000</span>
                  <span>60%</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 第4列：运营费用和服务费用指标块 */}
        <div className="flex flex-col h-full gap-4">
          <Card className="bg-white border border-gray-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-900">运营费用</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs text-gray-600">当前支出</span>
                  <span className="text-xs font-medium text-gray-900">¥300,000</span>
                </div>
                <Progress value={65} className="h-2" />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>预算: ¥500,000</span>
                  <span>65%</span>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-white border border-gray-200 flex-1">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-900">服务费用</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs text-gray-600">当前支出</span>
                  <span className="text-xs font-medium text-gray-900">¥100,000</span>
                </div>
                <Progress value={80} className="h-2" />
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>预算: ¥150,000</span>
                  <span>80%</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* 账单列表 */}
      <Card className="bg-white border border-gray-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-gray-900">账单列表</CardTitle>
        </CardHeader>
        <CardContent className="pt-0 px-5 pb-5 mt-[-21px] mr-[0px] mb-[0px] ml-[0px]">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-fit grid-cols-3 mb-4">
              <TabsTrigger value="summary" className="text-xs">汇总</TabsTrigger>
              <TabsTrigger value="monthly" className="text-xs">月度</TabsTrigger>
              <TabsTrigger value="billing-details" className="text-xs">账单明细</TabsTrigger>
            </TabsList>

            <TabsContent value="summary" className="mt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10">年度</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">属性</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">费用类别</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">预算总额</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">实际费用</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">费用部门</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">城市</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">工区</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">用量</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">用量单位</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {summaryData.map((record) => (
                      <React.Fragment key={record.id}>
                        <TableRow className="hover:bg-gray-50">
                          <TableCell className="text-xs text-gray-900">{record.period}</TableCell>
                          <TableCell className="text-xs text-gray-900">
                            <Badge className={
                              record.attribute === '资源类' ? 'bg-blue-100 text-blue-800' :
                              record.attribute === '服务类' ? 'bg-green-100 text-green-800' :
                              'bg-purple-100 text-purple-800'
                            }>
                              {record.attribute}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-xs text-gray-900 font-medium">
                            <div className="flex items-center gap-2">
                              {record.isExpandable && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-4 w-4 p-0 hover:bg-gray-200"
                                  onClick={() => toggleRowExpansion(record.id)}
                                >
                                  {expandedRows.includes(record.id) ? (
                                    <ChevronDown className="h-3 w-3" />
                                  ) : (
                                    <ChevronRight className="h-3 w-3" />
                                  )}
                                </Button>
                              )}
                              <span>{record.category}</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-xs text-gray-900">¥{record.totalBudget}</TableCell>
                          <TableCell className="text-xs text-gray-900 font-medium">¥{record.actualCost}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.department}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.city}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.workArea}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.usage}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.usageUnit}</TableCell>
                          <TableCell className="text-xs">
                            <Button 
                              variant="link" 
                              size="sm" 
                              className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                            >
                              查看账单
                            </Button>
                          </TableCell>
                        </TableRow>
                        {record.isExpandable && expandedRows.includes(record.id) && record.children?.map((child) => (
                          <TableRow key={child.id} className="bg-gray-25 hover:bg-gray-50">
                            <TableCell className="text-xs text-gray-900 pl-8">{child.period}</TableCell>
                            <TableCell className="text-xs text-gray-900 pl-8">
                              <Badge className={
                                child.attribute === '资源类' ? 'bg-blue-100 text-blue-800' :
                                child.attribute === '服务类' ? 'bg-green-100 text-green-800' :
                                'bg-purple-100 text-purple-800'
                              }>
                                {child.attribute}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-xs text-gray-700 pl-8">
                              <span className="text-gray-500">└─</span> {child.category}
                            </TableCell>
                            <TableCell className="text-xs text-gray-900">¥{child.totalBudget}</TableCell>
                            <TableCell className="text-xs text-gray-900 font-medium">¥{child.actualCost}</TableCell>
                            <TableCell className="text-xs text-gray-900">{child.department}</TableCell>
                            <TableCell className="text-xs text-gray-900">{child.city}</TableCell>
                            <TableCell className="text-xs text-gray-900">{child.workArea}</TableCell>
                            <TableCell className="text-xs text-gray-900">{child.usage}</TableCell>
                            <TableCell className="text-xs text-gray-900">{child.usageUnit}</TableCell>
                            <TableCell className="text-xs">
                              <Button 
                                variant="link" 
                                size="sm" 
                                className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                              >
                                查看账单
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </React.Fragment>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <TablePagination
                total={summaryData.length}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </TabsContent>

            <TabsContent value="monthly" className="mt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10">期间</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">部门</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">属性</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">费用类别</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">城市</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">工区</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">单价</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">数量</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">总金额</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {monthlyData.map((record) => (
                      <React.Fragment key={record.id}>
                        <TableRow className="hover:bg-gray-50">
                          <TableCell className="text-xs text-gray-900">{record.period}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.department}</TableCell>
                          <TableCell className="text-xs text-gray-900">
                            <Badge className={
                              record.attribute === '资源类' ? 'bg-blue-100 text-blue-800' :
                              record.attribute === '服务类' ? 'bg-green-100 text-green-800' :
                              'bg-purple-100 text-purple-800'
                            }>
                              {record.attribute}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-xs text-gray-900 font-medium">
                            <div className="flex items-center gap-2">
                              {record.isExpandable && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-4 w-4 p-0 hover:bg-gray-200"
                                  onClick={() => toggleRowExpansion(record.id)}
                                >
                                  {expandedRows.includes(record.id) ? (
                                    <ChevronDown className="h-3 w-3" />
                                  ) : (
                                    <ChevronRight className="h-3 w-3" />
                                  )}
                                </Button>
                              )}
                              <span>{record.category}</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-xs text-gray-900">{record.city}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.workArea}</TableCell>
                          <TableCell className="text-xs text-gray-900">¥{record.unitPrice}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.quantity}</TableCell>
                          <TableCell className="text-xs text-gray-900 font-medium">¥{record.totalAmount}</TableCell>
                          <TableCell className="text-xs">
                            <Button 
                              variant="link" 
                              size="sm" 
                              className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                            >
                              查看详情
                            </Button>
                          </TableCell>
                        </TableRow>
                        {record.isExpandable && expandedRows.includes(record.id) && record.children?.map((child) => (
                          <TableRow key={child.id} className="bg-gray-25 hover:bg-gray-50">
                            <TableCell className="text-xs text-gray-900 pl-8">{child.period}</TableCell>
                            <TableCell className="text-xs text-gray-900 pl-8">{child.department}</TableCell>
                            <TableCell className="text-xs text-gray-900 pl-8">
                              <Badge className={
                                child.attribute === '资源类' ? 'bg-blue-100 text-blue-800' :
                                child.attribute === '服务类' ? 'bg-green-100 text-green-800' :
                                'bg-purple-100 text-purple-800'
                              }>
                                {child.attribute}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-xs text-gray-700 pl-8">
                              <span className="text-gray-500">└─</span> {child.category}
                            </TableCell>
                            <TableCell className="text-xs text-gray-900">{child.city}</TableCell>
                            <TableCell className="text-xs text-gray-900">{child.workArea}</TableCell>
                            <TableCell className="text-xs text-gray-900">¥{child.unitPrice}</TableCell>
                            <TableCell className="text-xs text-gray-900">{child.quantity}</TableCell>
                            <TableCell className="text-xs text-gray-900 font-medium">¥{child.totalAmount}</TableCell>
                            <TableCell className="text-xs">
                              <Button 
                                variant="link" 
                                size="sm" 
                                className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                              >
                                查看详情
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </React.Fragment>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <TablePagination
                total={monthlyData.length}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </TabsContent>

            <TabsContent value="billing-details" className="mt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10">账单编号</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">状态</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">费用部门</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">业务线</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">城市</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">工区</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">期间</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">资源类型</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">计费方式</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">总金额</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {billingData.map((record) => (
                      <TableRow key={record.id} className="hover:bg-gray-50">
                        <TableCell className="text-xs text-gray-900 font-medium">{record.id}</TableCell>
                        <TableCell className="text-xs">
                          <Badge className={record.statusColor}>
                            {record.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-gray-900">{record.costDepartment}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.businessLine}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.city}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.workArea}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.period}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.resourceType}</TableCell>
                        <TableCell className="text-xs text-gray-900">{record.billingType}</TableCell>
                        <TableCell className="text-xs text-gray-900 font-medium">¥{record.totalRevenue}</TableCell>
                        <TableCell className="text-xs">
                          <Button 
                            variant="link" 
                            size="sm" 
                            className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                          >
                            查看账单
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <TablePagination
                total={billingData.length}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}