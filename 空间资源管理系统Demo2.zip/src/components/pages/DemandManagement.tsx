import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { TablePagination } from "../ui/table-pagination";
import { 
  Plus, 
  Search, 
  FileText, 
  CheckCircle, 
  Building, 
  Home, 
  Package,
  Truck
} from "lucide-react";

// 统计卡片数据
const statisticsData = [
  {
    title: "新增需求",
    value: "15",
    icon: FileText,
    color: "text-blue-600"
  },
  {
    title: "已结案",
    value: "152",
    icon: CheckCircle,
    color: "text-green-600"
  },
  {
    title: "已提交租赁",
    value: "8",
    icon: Building,
    color: "text-purple-600"
  },
  {
    title: "已提交装修",
    value: "5",
    icon: Home,
    color: "text-orange-600"
  },
  {
    title: "已提交资产",
    value: "11",
    icon: Package,
    color: "text-cyan-600"
  },
  {
    title: "已提交搬家",
    value: "4",
    icon: Truck,
    color: "text-red-600"
  }
];

// 需求列表数据
const demandData = [
  {
    projectId: "REQ-2025-010",
    projectName: "华南区集群项目扩租",
    projectType: "新租场",
    currentNode: "已提交资产",
    location: "深圳-南山区",
    demandType: "业务需求",
    applicant: "赵六",
    applicantDepartment: "销售部",
    resourceType: "工位",
    quantity: 50,
    duration: "365天",
    applicationTime: "2024-07-10",
    lastUpdateTime: "2024-07-18"
  },
  {
    projectId: "REQ-2025-011",
    projectName: "北京AI Lab扩力升级",
    projectType: "已有工区",
    currentNode: "已提交资产",
    location: "北京-海淀区",
    demandType: "业务需求",
    applicant: "孙七",
    applicantDepartment: "AI Lab",
    resourceType: "改造",
    quantity: 1,
    duration: "60天",
    applicationTime: "2024-07-05",
    lastUpdateTime: "2024-07-15"
  },
  {
    projectId: "REQ-2025-012",
    projectName: "上海研发中心扩建",
    projectType: "新租场",
    currentNode: "已提交租赁",
    location: "上海-浦东新区",
    demandType: "业务需求",
    applicant: "张三",
    applicantDepartment: "研发部",
    resourceType: "工位",
    quantity: 80,
    duration: "180天",
    applicationTime: "2024-07-12",
    lastUpdateTime: "2024-07-20"
  },
  {
    projectId: "REQ-2025-013",
    projectName: "广州分公司办公区域",
    projectType: "已有工区",
    currentNode: "已提交装修",
    location: "广州-天河区",
    demandType: "房产需求",
    applicant: "李四",
    applicantDepartment: "运营部",
    resourceType: "会议室",
    quantity: 5,
    duration: "90天",
    applicationTime: "2024-07-08",
    lastUpdateTime: "2024-07-16"
  },
  {
    projectId: "REQ-2025-014",
    projectName: "成都技术团队工位",
    projectType: "新租场",
    currentNode: "已提交搬家",
    location: "成都-高新区",
    demandType: "业务需求",
    applicant: "王五",
    applicantDepartment: "技术部",
    resourceType: "工位",
    quantity: 30,
    duration: "270天",
    applicationTime: "2024-07-06",
    lastUpdateTime: "2024-07-14"
  },
  {
    projectId: "REQ-2025-015",
    projectName: "杭州办公室升级改造",
    projectType: "已有工区",
    currentNode: "已结案",
    location: "杭州-西湖区",
    demandType: "房产需求",
    applicant: "陈六",
    applicantDepartment: "设计部",
    resourceType: "改造",
    quantity: 1,
    duration: "45天",
    applicationTime: "2024-06-28",
    lastUpdateTime: "2024-07-10"
  },
  {
    projectId: "REQ-2025-016",
    projectName: "苏州研发基地建设",
    projectType: "新租场",
    currentNode: "已提交资产",
    location: "苏州-工业园区",
    demandType: "业务需求",
    applicant: "刘七",
    applicantDepartment: "研发部",
    resourceType: "工位",
    quantity: 120,
    duration: "480天",
    applicationTime: "2024-07-15",
    lastUpdateTime: "2024-07-22"
  },
  {
    projectId: "REQ-2025-017",
    projectName: "武汉客服中心扩容",
    projectType: "已有工区",
    currentNode: "已提交租赁",
    location: "武汉-江汉区",
    demandType: "业务需求",
    applicant: "马八",
    applicantDepartment: "客服部",
    resourceType: "工位",
    quantity: 40,
    duration: "200天",
    applicationTime: "2024-07-11",
    lastUpdateTime: "2024-07-19"
  },
  {
    projectId: "REQ-2025-018",
    projectName: "西安分部会议室改造",
    projectType: "已有工区",
    currentNode: "已提交装修",
    location: "西安-雁塔区",
    demandType: "房产需求",
    applicant: "周九",
    applicantDepartment: "行政部",
    resourceType: "会议室",
    quantity: 3,
    duration: "30天",
    applicationTime: "2024-07-09",
    lastUpdateTime: "2024-07-17"
  },
  {
    projectId: "REQ-2025-019",
    projectName: "天津办公园区规划",
    projectType: "新租场",
    currentNode: "新增需求",
    location: "天津-滨海新区",
    demandType: "业务需求",
    applicant: "吴十",
    applicantDepartment: "战略部",
    resourceType: "工位",
    quantity: 200,
    duration: "730天",
    applicationTime: "2024-07-20",
    lastUpdateTime: "2024-07-25"
  }
];

// 状态徽章配色
const getStatusBadge = (status: string) => {
  switch (status) {
    case "已提交资产":
      return <Badge variant="default" className="bg-cyan-100 text-cyan-800 hover:bg-cyan-100">{status}</Badge>;
    case "已提交租赁":
      return <Badge variant="default" className="bg-purple-100 text-purple-800 hover:bg-purple-100">{status}</Badge>;
    case "已提交装修":
      return <Badge variant="default" className="bg-orange-100 text-orange-800 hover:bg-orange-100">{status}</Badge>;
    case "已提交搬家":
      return <Badge variant="default" className="bg-red-100 text-red-800 hover:bg-red-100">{status}</Badge>;
    case "已结案":
      return <Badge variant="default" className="bg-green-100 text-green-800 hover:bg-green-100">{status}</Badge>;
    case "新增需求":
      return <Badge variant="default" className="bg-blue-100 text-blue-800 hover:bg-blue-100">{status}</Badge>;
    case "新租场":
      return <Badge variant="default" className="bg-blue-100 text-blue-800 hover:bg-blue-100">{status}</Badge>;
    case "已有工区":
      return <Badge variant="secondary" className="bg-green-100 text-green-800 hover:bg-green-100">{status}</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

export function DemandManagementContent() {
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const totalItems = 235; // 模拟总条数

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div>
        <h1 className="text-[15px] font-bold">需求管理</h1>
      </div>

      {/* 统计卡片区域 */}
      <div className="grid grid-cols-6 gap-4">
        {statisticsData.map((item, index) => {
          const Icon = item.icon;
          return (
            <Card key={index} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{item.title}</p>
                    <p className="text-2xl font-semibold">{item.value}</p>
                  </div>
                  <Icon className={`h-8 w-8 ${item.color}`} />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* 需求列表区域 */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="font-bold">
              需求列表
            </CardTitle>
            <Button size="sm" className="h-8 text-sm bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-1" />
              新建需求
            </Button>
          </div>
        </CardHeader>
        
        {/* 全局操作栏 */}
        <div className="px-[25px]">
          <div className="flex items-center gap-3 py-[0px] p-[0px] mt-[-21px] mr-[0px] mb-[0px] ml-[0px]">
            {/* 搜索框 */}
            <div className="relative flex-1 max-w-80">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="搜索项目名称/编码"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-8 text-sm"
              />
            </div>
            
            {/* 项目类型 */}
            <Select defaultValue="project-type">
              <SelectTrigger className="w-32 h-8 text-sm">
                <SelectValue placeholder="项目类型" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="project-type">全部类型</SelectItem>
                <SelectItem value="new-lease">新租场</SelectItem>
                <SelectItem value="existing">已有工区</SelectItem>
              </SelectContent>
            </Select>

            {/* 需求状态 */}
            <Select defaultValue="all-status">
              <SelectTrigger className="w-32 h-8 text-sm">
                <SelectValue placeholder="需求状态" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-status">全部状态</SelectItem>
                <SelectItem value="new-demand">新增需求</SelectItem>
                <SelectItem value="submitted-lease">已提交租赁</SelectItem>
                <SelectItem value="submitted-decoration">已提交装修</SelectItem>
                <SelectItem value="submitted-asset">已提交资产</SelectItem>
                <SelectItem value="submitted-move">已提交搬家</SelectItem>
                <SelectItem value="completed">已结案</SelectItem>
              </SelectContent>
            </Select>

            {/* 筛选按钮 */}
            <Button variant="outline" size="sm" className="h-8 text-sm">
              筛选
            </Button>
          </div>
        </div>

        <CardContent className="pt-[0px] pr-[25px] pb-[21px] pl-[25px]">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-fit grid-cols-3 mb-4">
              <TabsTrigger value="all" className="text-xs">
                汇总
              </TabsTrigger>
              <TabsTrigger value="business-demand" className="text-xs">
                业务需求
              </TabsTrigger>
              <TabsTrigger value="property-planning" className="text-xs">
                房产需求
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="all" className="mt-0">

              {/* 数据表格 */}
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-sm font-medium">项目ID</TableHead>
                      <TableHead className="text-sm font-medium">项目名称</TableHead>
                      <TableHead className="text-sm font-medium">项目类型</TableHead>
                      <TableHead className="text-sm font-medium">当前节点</TableHead>
                      <TableHead className="text-sm font-medium">位置-城市工区</TableHead>
                      <TableHead className="text-sm font-medium">需求类型</TableHead>
                      <TableHead className="text-sm font-medium">申请人</TableHead>
                      <TableHead className="text-sm font-medium">申请部门</TableHead>
                      <TableHead className="text-sm font-medium">资源类型</TableHead>
                      <TableHead className="text-sm font-medium">申请数量</TableHead>
                      <TableHead className="text-sm font-medium">申请时长</TableHead>
                      <TableHead className="text-sm font-medium">申请时间</TableHead>
                      <TableHead className="text-sm font-medium">最近更新时间</TableHead>
                      <TableHead className="text-sm font-medium">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {demandData.map((item, index) => (
                      <TableRow key={index} className="hover:bg-muted/30">
                        <TableCell className="text-sm font-mono">{item.projectId}</TableCell>
                        <TableCell className="text-sm text-blue-600 hover:text-blue-700 cursor-pointer font-medium">
                          {item.projectName}
                        </TableCell>
                        <TableCell>{getStatusBadge(item.projectType)}</TableCell>
                        <TableCell>{getStatusBadge(item.currentNode)}</TableCell>
                        <TableCell className="text-sm">{item.location}</TableCell>
                        <TableCell className="text-sm">{item.demandType}</TableCell>
                        <TableCell className="text-sm">{item.applicant}</TableCell>
                        <TableCell className="text-sm">{item.applicantDepartment}</TableCell>
                        <TableCell className="text-sm">{item.resourceType}</TableCell>
                        <TableCell className="text-sm">{item.quantity}</TableCell>
                        <TableCell className="text-sm">{item.duration}</TableCell>
                        <TableCell className="text-sm">{item.applicationTime}</TableCell>
                        <TableCell className="text-sm">{item.lastUpdateTime}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm" className="h-7 text-xs text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                            编辑
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <TablePagination
                total={totalItems}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </TabsContent>
            
            <TabsContent value="business-demand" className="mt-0">

              {/* 业务需求表格 */}
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-sm font-medium">项目ID</TableHead>
                      <TableHead className="text-sm font-medium">项目名称</TableHead>
                      <TableHead className="text-sm font-medium">项目类型</TableHead>
                      <TableHead className="text-sm font-medium">当前节点</TableHead>
                      <TableHead className="text-sm font-medium">位置-城市工区</TableHead>
                      <TableHead className="text-sm font-medium">申请人</TableHead>
                      <TableHead className="text-sm font-medium">申请部门</TableHead>
                      <TableHead className="text-sm font-medium">资源类型</TableHead>
                      <TableHead className="text-sm font-medium">申请数量</TableHead>
                      <TableHead className="text-sm font-medium">申请时长</TableHead>
                      <TableHead className="text-sm font-medium">申请时间</TableHead>
                      <TableHead className="text-sm font-medium">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {demandData.filter(item => item.demandType === "业务需求").map((item, index) => (
                      <TableRow key={index} className="hover:bg-muted/30">
                        <TableCell className="text-sm font-mono">{item.projectId}</TableCell>
                        <TableCell className="text-sm text-blue-600 hover:text-blue-700 cursor-pointer font-medium">
                          {item.projectName}
                        </TableCell>
                        <TableCell>{getStatusBadge(item.projectType)}</TableCell>
                        <TableCell>{getStatusBadge(item.currentNode)}</TableCell>
                        <TableCell className="text-sm">{item.location}</TableCell>
                        <TableCell className="text-sm">{item.applicant}</TableCell>
                        <TableCell className="text-sm">{item.applicantDepartment}</TableCell>
                        <TableCell className="text-sm">{item.resourceType}</TableCell>
                        <TableCell className="text-sm">{item.quantity}</TableCell>
                        <TableCell className="text-sm">{item.duration}</TableCell>
                        <TableCell className="text-sm">{item.applicationTime}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm" className="h-7 text-xs text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                            编辑
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <TablePagination
                total={demandData.filter(item => item.demandType === "业务需求").length}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </TabsContent>
            
            <TabsContent value="property-planning" className="mt-0">

              {/* 房产需求表格 */}
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-sm font-medium">项目ID</TableHead>
                      <TableHead className="text-sm font-medium">项目名称</TableHead>
                      <TableHead className="text-sm font-medium">项目类型</TableHead>
                      <TableHead className="text-sm font-medium">当前节点</TableHead>
                      <TableHead className="text-sm font-medium">位置-城市工区</TableHead>
                      <TableHead className="text-sm font-medium">申请人</TableHead>
                      <TableHead className="text-sm font-medium">申请部门</TableHead>
                      <TableHead className="text-sm font-medium">资源类型</TableHead>
                      <TableHead className="text-sm font-medium">申请数量</TableHead>
                      <TableHead className="text-sm font-medium">申请时长</TableHead>
                      <TableHead className="text-sm font-medium">申请时间</TableHead>
                      <TableHead className="text-sm font-medium">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {demandData.filter(item => item.demandType === "房产需求").map((item, index) => (
                      <TableRow key={index} className="hover:bg-muted/30">
                        <TableCell className="text-sm font-mono">{item.projectId}</TableCell>
                        <TableCell className="text-sm text-blue-600 hover:text-blue-700 cursor-pointer font-medium">
                          {item.projectName}
                        </TableCell>
                        <TableCell>{getStatusBadge(item.projectType)}</TableCell>
                        <TableCell>{getStatusBadge(item.currentNode)}</TableCell>
                        <TableCell className="text-sm">{item.location}</TableCell>
                        <TableCell className="text-sm">{item.applicant}</TableCell>
                        <TableCell className="text-sm">{item.applicantDepartment}</TableCell>
                        <TableCell className="text-sm">{item.resourceType}</TableCell>
                        <TableCell className="text-sm">{item.quantity}</TableCell>
                        <TableCell className="text-sm">{item.duration}</TableCell>
                        <TableCell className="text-sm">{item.applicationTime}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm" className="h-7 text-xs text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                            编辑
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <TablePagination
                total={demandData.filter(item => item.demandType === "房产需求").length}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}