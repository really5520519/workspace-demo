import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { TablePagination } from "../ui/table-pagination";
import { Search, Plus, Download } from "lucide-react";

export function BuildingPersonnelManagementContent() {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [searchQuery, setSearchQuery] = useState("");
  const totalItems = 156; // 模拟总条数

  // 模拟数据
  const personnelData = [
    {
      id: "1",
      workspaceName: "北京总部办公区",
      location: "中国-北京-望京SOHO",
      propertyZone: "A区",
      country: "中国",
      province: "北京市",
      city: "北京",
      regionPlan: "核心办公区",
      planOperation: "正式运营",
      facilityManager: "张经理/李楼长",
      facilityEngineer: "王工程师/赵助理/孙领班",
      facilityTechnician: "陈技师",
      facilityAsset: "设备001-050",
      facilityDrawing: "图纸-BJ-001",
      leaseManager: "刘经理",
      designManager: "周经理",
      projectManager: "吴经理",
      securityManager: "徐经理",
      itManager: "马经理",
      creator: "管理员",
      createTime: "2025-01-15 10:30",
      updater: "张三"
    },
    {
      id: "2",
      workspaceName: "深圳研发中心",
      location: "中国-深圳-南山科技园",
      propertyZone: "B区",
      country: "中国",
      province: "广东省",
      city: "深圳",
      regionPlan: "研发办公区",
      planOperation: "筹备中",
      facilityManager: "林经理/何楼长",
      facilityEngineer: "梁工程师/郑助理/黄领班",
      facilityTechnician: "谢技师",
      facilityAsset: "设备051-100",
      facilityDrawing: "图纸-SZ-001",
      leaseManager: "邓经理",
      designManager: "罗经理",
      projectManager: "韩经理",
      securityManager: "冯经理",
      itManager: "曾经理",
      creator: "管理员",
      createTime: "2025-02-20 14:15",
      updater: "李四"
    },
    {
      id: "3",
      workspaceName: "上海分公司办公楼",
      location: "中国-上海-浦东新区",
      propertyZone: "C区",
      country: "中国",
      province: "上海市",
      city: "上海",
      regionPlan: "分公司办公区",
      planOperation: "正式运营",
      facilityManager: "蔡经理/许楼长",
      facilityEngineer: "侯工程师/段助理/薛领班",
      facilityTechnician: "雷技师",
      facilityAsset: "设备101-150",
      facilityDrawing: "图纸-SH-001",
      leaseManager: "沈经理",
      designManager: "范经理",
      projectManager: "彭经理",
      securityManager: "苗经理",
      itManager: "鲍经理",
      creator: "管理员",
      createTime: "2025-01-08 09:45",
      updater: "王五"
    },
    {
      id: "4",
      workspaceName: "广州业务中心",
      location: "中国-广州-天河区",
      propertyZone: "D区",
      country: "中国",
      province: "广东省",
      city: "广州",
      regionPlan: "业务办公区",
      planOperation: "装修中",
      facilityManager: "史经理/龚楼长",
      facilityEngineer: "程工程师/汪助理/毛领班",
      facilityTechnician: "邱技师",
      facilityAsset: "设备151-200",
      facilityDrawing: "图纸-GZ-001",
      leaseManager: "康经理",
      designManager: "汤经理",
      projectManager: "姚经理",
      securityManager: "邵经理",
      itManager: "袁经理",
      creator: "管理员",
      createTime: "2025-03-01 16:20",
      updater: "赵六"
    },
    {
      id: "5",
      workspaceName: "杭州技术办公室",
      location: "中国-杭州-西湖区",
      propertyZone: "E区",
      country: "中国",
      province: "浙江省",
      city: "杭州",
      regionPlan: "技术办公区",
      planOperation: "规划中",
      facilityManager: "黎经理/万楼长",
      facilityEngineer: "顾工程师/方助理/石领班",
      facilityTechnician: "任技师",
      facilityAsset: "设备201-250",
      facilityDrawing: "图纸-HZ-001",
      leaseManager: "覃经理",
      designManager: "谭经理",
      projectManager: "娄经理",
      securityManager: "蒋经理",
      itManager: "韦经理",
      creator: "管理员",
      createTime: "2025-02-28 11:30",
      updater: "孙七"
    },
    {
      id: "6",
      workspaceName: "成都运营中心",
      location: "中国-成都-高新区",
      propertyZone: "F区",
      country: "中国",
      province: "四川省",
      city: "成都",
      regionPlan: "运营办公区",
      planOperation: "正式运营",
      facilityManager: "齐经理/卜楼长",
      facilityEngineer: "阮工程师/魏助理/蓝领班",
      facilityTechnician: "管技师",
      facilityAsset: "设备251-300",
      facilityDrawing: "图纸-CD-001",
      leaseManager: "景经理",
      designManager: "詹经理",
      projectManager: "束经理",
      securityManager: "龙经理",
      itManager: "叶经理",
      creator: "管理员",
      createTime: "2025-01-25 13:45",
      updater: "周八"
    },
    {
      id: "7",
      workspaceName: "西安研发基地",
      location: "中国-西安-高新技术开发区",
      propertyZone: "G区",
      country: "中国",
      province: "陕西省",
      city: "西安",
      regionPlan: "研发基地",
      planOperation: "筹备中",
      facilityManager: "幸经理/司楼长",
      facilityEngineer: "韶工程师/危助理/宫领班",
      facilityTechnician: "聂技师",
      facilityAsset: "设备301-350",
      facilityDrawing: "图纸-XA-001",
      leaseManager: "宁经理",
      designManager: "廉经理",
      projectManager: "乔经理",
      securityManager: "栾经理",
      itManager: "暴经理",
      creator: "管理员",
      createTime: "2025-03-10 08:15",
      updater: "钱九"
    },
    {
      id: "8",
      workspaceName: "武汉分支机构",
      location: "中国-武汉-江汉区",
      propertyZone: "H区",
      country: "中国",
      province: "湖北省",
      city: "武汉",
      regionPlan: "分支办公区",
      planOperation: "正式运营",
      facilityManager: "甘经理/钭楼长",
      facilityEngineer: "厉工程师/戎助理/祖领班",
      facilityTechnician: "武技师",
      facilityAsset: "设备351-400",
      facilityDrawing: "图纸-WH-001",
      leaseManager: "符经理",
      designManager: "刘经理",
      projectManager: "景经理",
      securityManager: "谷经理",
      itManager: "车经理",
      creator: "管理员",
      createTime: "2025-02-15 15:20",
      updater: "李十"
    },
    {
      id: "9",
      workspaceName: "南京技术中心",
      location: "中国-南京-江宁区",
      propertyZone: "I区",
      country: "中国",
      province: "江苏省",
      city: "南京",
      regionPlan: "技术中心",
      planOperation: "正式运营",
      facilityManager: "伏经理/能楼长",
      facilityEngineer: "苍工程师/双助理/闻领班",
      facilityTechnician: "莘技师",
      facilityAsset: "设备401-450",
      facilityDrawing: "图纸-NJ-001",
      leaseManager: "钞经理",
      designManager: "贡经理",
      projectManager: "劳经理",
      securityManager: "逄经理",
      itManager: "奚经理",
      creator: "管理员",
      createTime: "2025-01-30 12:00",
      updater: "刘十一"
    },
    {
      id: "10",
      workspaceName: "天津制造基地",
      location: "中国-天津-滨海新区",
      propertyZone: "J区",
      country: "中国",
      province: "天津市",
      city: "天津",
      regionPlan: "制造基地",
      planOperation: "装修中",
      facilityManager: "郝经理/解楼长",
      facilityEngineer: "应工程师/宗助理/丁领班",
      facilityTechnician: "宣技师",
      facilityAsset: "设备451-500",
      facilityDrawing: "图纸-TJ-001",
      leaseManager: "贲经理",
      designManager: "邸经理",
      projectManager: "富经理",
      securityManager: "蒿经理",
      itManager: "衡经理",
      creator: "管理员",
      createTime: "2025-03-05 10:45",
      updater: "王十二"
    }
  ];

  return (
    <div className="space-y-4" style={{ maxWidth: '1300px', margin: '0 auto' }}>
      {/* 页面标题 */}
      <div>
        <h1 className="text-[15px] font-bold" className="text-[16px]">楼宇人员管理</h1>
        <p className="text-muted-foreground">管理各工区的人员配置和职责分工</p>
      </div>

      {/* 统计概览 */}
      <div className="grid grid-cols-5 gap-4">
        <div className="bg-[#e1f5fe] rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-gray-900">156</div>
          <div className="text-xs text-gray-600 mt-1">总工区数</div>
        </div>
        <div className="bg-[#e8f5e8] rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-gray-900">128</div>
          <div className="text-xs text-gray-600 mt-1">已配置人员</div>
        </div>
        <div className="bg-[#fff8e1] rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-gray-900">1: 5.1</div>
          <div className="text-xs text-gray-600 mt-1">人均楼宇配比</div>
        </div>
        <div className="bg-[#fce4ec] rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-gray-900">856</div>
          <div className="text-xs text-gray-600 mt-1">字节人员总数</div>
        </div>
        <div className="bg-[#e3f2fd] rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-gray-900">95%</div>
          <div className="text-xs text-gray-600 mt-1">人员配置率</div>
        </div>
      </div>

      {/* 人员信息列表 */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle>工区人员配置列表</CardTitle>
            <div className="flex items-center gap-2">
              <Button size="sm" className="h-8 bg-blue-600 hover:bg-blue-700 text-white">
                <Plus className="h-4 w-4 mr-1" />
                新增配置
              </Button>
              <Button variant="outline" size="sm" className="h-8">
                <Download className="h-4 w-4 mr-1" />
                导出数据
              </Button>
            </div>
          </div>

          {/* 搜索和筛选 */}
          <div className="flex items-center gap-3 pt-3 border-t">
            <div className="relative flex-1 max-w-80">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="搜索工区名称、城市、人员姓名..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-8"
              />
            </div>
            
            <Select defaultValue="all-region">
              <SelectTrigger className="w-32 h-8">
                <SelectValue placeholder="地区" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-region">全部地区</SelectItem>
                <SelectItem value="north">华北</SelectItem>
                <SelectItem value="south">华南</SelectItem>
                <SelectItem value="east">华东</SelectItem>
                <SelectItem value="west">华西</SelectItem>
              </SelectContent>
            </Select>

            <Select defaultValue="all-status">
              <SelectTrigger className="w-32 h-8">
                <SelectValue placeholder="运营状态" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-status">全部状态</SelectItem>
                <SelectItem value="operating">正式运营</SelectItem>
                <SelectItem value="preparing">筹备中</SelectItem>
                <SelectItem value="decorating">装修中</SelectItem>
                <SelectItem value="planning">规划中</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline" size="sm" className="h-8">
              筛选
            </Button>
          </div>
        </CardHeader>

        <CardContent>
          {/* 数据表格 */}
          <div className="border rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="min-w-[120px]">工区名称</TableHead>
                  <TableHead className="min-w-[140px]">国家-城市-职场</TableHead>
                  <TableHead className="min-w-[100px]">房产分区</TableHead>
                  <TableHead className="min-w-[100px]">国家/地区</TableHead>
                  <TableHead className="min-w-[80px]">省份</TableHead>
                  <TableHead className="min-w-[80px]">城市</TableHead>
                  <TableHead className="min-w-[100px]">区域规划</TableHead>
                  <TableHead className="min-w-[100px]">规划运营</TableHead>
                  <TableHead className="min-w-[140px]">设施经理/行政楼长</TableHead>
                  <TableHead className="min-w-[160px]">设施工程师/助理/领班</TableHead>
                  <TableHead className="min-w-[100px]">设施技师</TableHead>
                  <TableHead className="min-w-[100px]">设施资产</TableHead>
                  <TableHead className="min-w-[100px]">设施修图</TableHead>
                  <TableHead className="min-w-[100px]">租赁经理</TableHead>
                  <TableHead className="min-w-[100px]">设计经理</TableHead>
                  <TableHead className="min-w-[100px]">项目经理</TableHead>
                  <TableHead className="min-w-[100px]">安防经理</TableHead>
                  <TableHead className="min-w-[100px]">IT经理</TableHead>
                  <TableHead className="min-w-[80px]">创建人</TableHead>
                  <TableHead className="min-w-[120px]">创建时间</TableHead>
                  <TableHead className="min-w-[80px]">更新人</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {personnelData.map((item) => (
                  <TableRow key={item.id} className="hover:bg-muted/30">
                    <TableCell className="font-medium">{item.workspaceName}</TableCell>
                    <TableCell>{item.location}</TableCell>
                    <TableCell>{item.propertyZone}</TableCell>
                    <TableCell>{item.country}</TableCell>
                    <TableCell>{item.province}</TableCell>
                    <TableCell>{item.city}</TableCell>
                    <TableCell>{item.regionPlan}</TableCell>
                    <TableCell>
                      <Badge variant="default" className={
                        item.planOperation === '正式运营' ? 'bg-green-100 text-green-800' :
                        item.planOperation === '筹备中' ? 'bg-blue-100 text-blue-800' :
                        item.planOperation === '装修中' ? 'bg-orange-100 text-orange-800' :
                        item.planOperation === '规划中' ? 'bg-purple-100 text-purple-800' :
                        'bg-gray-100 text-gray-800'
                      }>
                        {item.planOperation}
                      </Badge>
                    </TableCell>
                    <TableCell>{item.facilityManager}</TableCell>
                    <TableCell>{item.facilityEngineer}</TableCell>
                    <TableCell>{item.facilityTechnician}</TableCell>
                    <TableCell>{item.facilityAsset}</TableCell>
                    <TableCell>{item.facilityDrawing}</TableCell>
                    <TableCell>{item.leaseManager}</TableCell>
                    <TableCell>{item.designManager}</TableCell>
                    <TableCell>{item.projectManager}</TableCell>
                    <TableCell>{item.securityManager}</TableCell>
                    <TableCell>{item.itManager}</TableCell>
                    <TableCell>{item.creator}</TableCell>
                    <TableCell>{item.createTime}</TableCell>
                    <TableCell>{item.updater}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* 分页控件 */}
          <TablePagination
            total={totalItems}
            currentPage={currentPage}
            pageSize={pageSize}
            onPageChange={setCurrentPage}
            onPageSizeChange={setPageSize}
          />
        </CardContent>
      </Card>
    </div>
  );
}