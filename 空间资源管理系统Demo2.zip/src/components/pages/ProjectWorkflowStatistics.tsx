import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { ArrowLeft } from "lucide-react";
import * as d3 from "d3";
import { sankey, sankeyLinkHorizontal } from "d3-sankey";

interface ProjectWorkflowStatisticsProps {
  onNavigate?: (targetId: string, data?: any) => void;
}

// 桑基图数据结构
const sankeyData = {
  nodes: [
    // 第一层：需求数量 (1200)
    { id: 0, name: "需求数量", value: 1200, color: "#3b82f6" },
    
    // 第二层：分配数量 (800) + 新增需求 (400) = 1200
    { id: 1, name: "分配数量", value: 800, color: "#10b981" },
    { id: 2, name: "新增需求", value: 400, color: "#f59e0b" },
    
    // 第三层：库存分配 (600) + 新增需求分配 (200) + 租赁需求 (200) + 项目装修需求1 (200) = 1200
    { id: 3, name: "库存分配", value: 600, color: "#8b5cf6" },
    { id: 4, name: "新增需求分配", value: 200, color: "#22d3ee" },
    { id: 5, name: "租赁需求", value: 200, color: "#ef4444" },
    { id: 6, name: "项目装修需求1", value: 200, color: "#06b6d4" },
    
    // 第四层：租赁类型 (200) + 装修类型 (200)
    { id: 7, name: "新租", value: 80, color: "#84cc16" },
    { id: 8, name: "扩租", value: 50, color: "#a855f7" },
    { id: 9, name: "续租", value: 45, color: "#ec4899" },
    { id: 10, name: "退租", value: 25, color: "#f97316" },
    
    { id: 11, name: "新交付装修", value: 80, color: "#14b8a6" },
    { id: 12, name: "Day2改造", value: 60, color: "#6366f1" },
    { id: 13, name: "退租还原", value: 35, color: "#f43f5e" },
    { id: 14, name: "其他改造", value: 25, color: "#64748b" },
    
    // 第五层：项目装修需求2（汇聚装修类型）(200)
    { id: 15, name: "项目装修需求2", value: 200, color: "#06b6d4" },
    
    // 第六层：交付需求 (库存分配600 + 新增需求分配200 + 项目装修需求2的200) = 1000
    { id: 16, name: "交付需求", value: 1000, color: "#22c55e" },
    
    // 第七层：建设状态 (建设中350 + 已交付650) = 1000
    { id: 17, name: "建设中", value: 350, color: "#fbbf24" },
    { id: 18, name: "已交付", value: 650, color: "#34d399" },
    
    // 第八层：分配状态 (已分配需求400 + 未分配250) = 650
    { id: 19, name: "已分配需求", value: 400, color: "#60a5fa" },
    { id: 20, name: "未分配", value: 250, color: "#94a3b8" },
    { id: 21, name: "已分配", value: 400, color: "#4ade80" },
    
    // 第九层：搬入状态 (未搬入160 + 已搬入240) = 400
    { id: 22, name: "搬家需求", value: 400, color: "#f472b6" },
    { id: 23, name: "未搬入", value: 160, color: "#fb7185" },
    { id: 24, name: "已搬入", value: 240, color: "#38bdf8" }
  ],
  links: [
    // 第1层 → 第2层：需求数量(1200) → 分配数量(800) + 新增需求(400)
    { source: 0, target: 1, value: 800 },
    { source: 0, target: 2, value: 400 },
    
    // 第2层 → 第3层：分配数量(800) → 库存分配(600) + 新增需求分配(200)
    { source: 1, target: 3, value: 600 },
    { source: 1, target: 4, value: 200 },
    
    // 第2层 → 第3层：新增需求(400) → 租赁需求(200) + 项目装修需求1(200)
    { source: 2, target: 5, value: 200 },
    { source: 2, target: 6, value: 200 },
    
    // 第3层 → 第4层：租赁需求(200) → 租赁类型
    { source: 5, target: 7, value: 80 },
    { source: 5, target: 8, value: 50 },
    { source: 5, target: 9, value: 45 },
    { source: 5, target: 10, value: 25 },
    
    // 第3层 → 第4层：项目装修需求1(200) → 装修类型
    { source: 6, target: 11, value: 80 },
    { source: 6, target: 12, value: 60 },
    { source: 6, target: 13, value: 35 },
    { source: 6, target: 14, value: 25 },
    
    // 第4层 → 第5层：装修类型 → 项目装修需求2(200)
    { source: 11, target: 15, value: 80 },
    { source: 12, target: 15, value: 60 },
    { source: 13, target: 15, value: 35 },
    { source: 14, target: 15, value: 25 },
    
    // 第3层,5层 → 第6层：库存分配(600) + 新增需求分配(200) + 项目装修需求2(200) → 交付需求(1000)
    { source: 3, target: 16, value: 600 },
    { source: 4, target: 16, value: 200 },
    { source: 15, target: 16, value: 200 },
    
    // 第6层 → 第7层：交付需求(1000) → 建设中(350) + 已交付(650)
    { source: 16, target: 17, value: 350 },
    { source: 16, target: 18, value: 650 },
    
    // 第7层 → 第8层：已交付(650) → 已分配需求(400) + 未分配(250)
    { source: 18, target: 19, value: 400 },
    { source: 18, target: 20, value: 250 },
    
    // 第8层 → 第8层：已分配需求(400) → 已分配(400)
    { source: 19, target: 21, value: 400 },
    
    // 第8层 → 第9层：已分配(400) → 搬家需求(400)
    { source: 21, target: 22, value: 400 },
    
    // 第9层 → 第9层：搬家需求(400) → 未搬入(160) + 已搬入(240)
    { source: 22, target: 23, value: 160 },
    { source: 22, target: 24, value: 240 }
  ]
};

export function ProjectWorkflowStatisticsContent({ onNavigate }: ProjectWorkflowStatisticsProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [selectedMetric, setSelectedMetric] = useState("workstations");
  const [selectedNode, setSelectedNode] = useState<any>(null);
  const [hoveredNode, setHoveredNode] = useState<any>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const width = svgRef.current.clientWidth;
    const height = 600;
    const margin = { top: 20, right: 120, bottom: 20, left: 120 };

    // 创建桑基图布局
    const sankeyGenerator = sankey()
      .nodeWidth(20)
      .nodePadding(20)
      .extent([[margin.left, margin.top], [width - margin.right, height - margin.bottom]]);

    // 处理数据
    const graph = sankeyGenerator(sankeyData as any);

    // 绘制链接
    const link = svg.append("g")
      .selectAll("path")
      .data(graph.links)
      .enter().append("path")
      .attr("d", sankeyLinkHorizontal())
      .attr("stroke", "#94a3b8")
      .attr("stroke-opacity", 0.6)
      .attr("fill", "none")
      .attr("stroke-width", (d: any) => Math.max(1, d.width))
      .on("mouseover", function(event, d: any) {
        d3.select(this).attr("stroke-opacity", 0.8);
        // 显示tooltip
        const tooltip = svg.append("g")
          .attr("id", "tooltip")
          .attr("transform", `translate(${event.layerX},${event.layerY})`);
        
        const rect = tooltip.append("rect")
          .attr("fill", "rgba(0,0,0,0.8)")
          .attr("rx", 4)
          .attr("ry", 4);
        
        const text = tooltip.append("text")
          .attr("fill", "white")
          .attr("font-size", "12px")
          .attr("dx", 8)
          .attr("dy", 16)
          .text(`${d.source.name} → ${d.target.name}: ${d.value} 工位`);

        const bbox = text.node()?.getBBox();
        if (bbox) {
          rect.attr("width", bbox.width + 16).attr("height", bbox.height + 8);
        }
      })
      .on("mouseout", function() {
        d3.select(this).attr("stroke-opacity", 0.6);
        svg.select("#tooltip").remove();
      });

    // 绘制节点
    const node = svg.append("g")
      .selectAll("g")
      .data(graph.nodes)
      .enter().append("g")
      .attr("transform", (d: any) => `translate(${d.x0},${d.y0})`)
      .call(d3.drag<any, any>()
        .on("start", function(event, d: any) {
          d3.select(this).raise();
        })
        .on("drag", function(event, d: any) {
          const x = Math.max(0, Math.min(width - (d.x1 - d.x0), event.x));
          const y = Math.max(0, Math.min(height - (d.y1 - d.y0), event.y));
          d.x0 = x;
          d.x1 = x + (d.x1 - d.x0);
          d.y0 = y;
          d.y1 = y + (d.y1 - d.y0);
          d3.select(this).attr("transform", `translate(${d.x0},${d.y0})`);
          sankeyGenerator.update(graph as any);
          link.attr("d", sankeyLinkHorizontal());
        }));

    // 节点矩形
    node.append("rect")
      .attr("width", (d: any) => d.x1 - d.x0)
      .attr("height", (d: any) => d.y1 - d.y0)
      .attr("fill", (d: any) => d.color)
      .attr("stroke", "#fff")
      .attr("stroke-width", 1)
      .attr("rx", 4)
      .attr("ry", 4)
      .style("cursor", "pointer")
      .on("mouseover", function(event, d: any) {
        setHoveredNode(d);
        d3.select(this).attr("opacity", 0.8);
      })
      .on("mouseout", function() {
        setHoveredNode(null);
        d3.select(this).attr("opacity", 1);
      })
      .on("click", function(event, d: any) {
        setSelectedNode(d);
      });

    // 节点标签
    node.append("text")
      .attr("x", (d: any) => (d.x1 - d.x0) / 2)
      .attr("y", (d: any) => (d.y1 - d.y0) / 2)
      .attr("dy", "0.35em")
      .attr("text-anchor", "middle")
      .attr("font-size", "11px")
      .attr("font-weight", "500")
      .attr("fill", "white")
      .text((d: any) => d.name);

    // 节点数值标签
    node.append("text")
      .attr("x", (d: any) => (d.x1 - d.x0) / 2)
      .attr("y", (d: any) => (d.y1 - d.y0) / 2 + 15)
      .attr("dy", "0.35em")
      .attr("text-anchor", "middle")
      .attr("font-size", "9px")
      .attr("fill", "white")
      .text((d: any) => `${d.value}`);

  }, [selectedMetric]);

  // 获取选中节点的上下游关系
  const getNodeRelations = (node: any) => {
    if (!node) return null;

    const upstream = sankeyData.links
      .filter(link => link.target === node.id)
      .map(link => sankeyData.nodes.find(n => n.id === link.source))
      .filter(Boolean);

    const downstream = sankeyData.links
      .filter(link => link.source === node.id)
      .map(link => sankeyData.nodes.find(n => n.id === link.target))
      .filter(Boolean);

    return { upstream, downstream };
  };

  const relations = selectedNode ? getNodeRelations(selectedNode) : null;

  return (
    <div className="space-y-6 max-w-[1300px] mx-auto p-[0px]">
      {/* 页面标题和返回按钮 */}
      <div className="flex items-center gap-3">
        <Button
          variant="outline"
          size="sm"
          className="h-7 text-xs"
          onClick={() => onNavigate?.("project-management")}
        >
          <ArrowLeft className="h-3 w-3 mr-1" />
          返回
        </Button>
        <h1 className="text-[15px] font-bold">项目全流程统计</h1>
      </div>

      {/* 主要内容区域 */}
      <div className="grid grid-cols-4 gap-6">
        {/* 桑基图区域 */}
        <div className="col-span-3">
          <Card className="bg-white border border-gray-200">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-900">工位流向分布图</CardTitle>
                <Select value={selectedMetric} onValueChange={setSelectedMetric}>
                  <SelectTrigger className="w-32 h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="workstations">工位数</SelectItem>
                    <SelectItem value="area">面积</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="w-full overflow-x-auto">
                <svg
                  ref={svgRef}
                  width="100%"
                  height="600"
                  className="border rounded-lg"
                  style={{ minWidth: "800px" }}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 右侧说明区域 */}
        <div className="col-span-1 space-y-4">
          {/* 操作说明 */}
          <Card className="bg-white border border-gray-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-900">操作说明</CardTitle>
            </CardHeader>
            <CardContent className="pt-0 space-y-3">
              <div className="text-xs text-gray-600">
                • 鼠标悬浮查看节点详情
              </div>
              <div className="text-xs text-gray-600">
                • 点击节点查看上下游关系
              </div>
              <div className="text-xs text-gray-600">
                • 拖拽节点调整位置
              </div>
              <div className="text-xs text-gray-600">
                • 悬浮连线查看流向数据
              </div>
              <div className="text-xs text-gray-600">
                • 切换指标查看不同维度
              </div>
              <div className="border-t pt-2 mt-2">
                <div className="text-xs text-gray-500">
                  展示工位从需求到最终分配的完整流程
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 当前选中节点信息 */}
          {selectedNode && (
            <Card className="bg-white border border-gray-200">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-900">节点详情</CardTitle>
              </CardHeader>
              <CardContent className="pt-0 space-y-3">
                <div>
                  <div className="text-xs text-gray-600">节点名称</div>
                  <div className="text-sm font-medium text-gray-900">{selectedNode.name}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-600">工位数量</div>
                  <div className="text-sm font-medium text-gray-900">{selectedNode.value} 个</div>
                </div>
                {relations?.upstream && relations.upstream.length > 0 && (
                  <div>
                    <div className="text-xs text-gray-600 mb-1">上游节点</div>
                    <div className="space-y-1">
                      {relations.upstream.map((node: any, index: number) => (
                        <div key={index} className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded">
                          {node.name}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {relations?.downstream && relations.downstream.length > 0 && (
                  <div>
                    <div className="text-xs text-gray-600 mb-1">下游节点</div>
                    <div className="space-y-1">
                      {relations.downstream.map((node: any, index: number) => (
                        <div key={index} className="text-xs bg-green-50 text-green-700 px-2 py-1 rounded">
                          {node.name}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* 悬浮节点信息 */}
          {hoveredNode && !selectedNode && (
            <Card className="bg-white border border-gray-200">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-900">悬浮信息</CardTitle>
              </CardHeader>
              <CardContent className="pt-0 space-y-2">
                <div>
                  <div className="text-xs text-gray-600">节点</div>
                  <div className="text-sm font-medium text-gray-900">{hoveredNode.name}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-600">数量</div>
                  <div className="text-sm font-medium text-gray-900">{hoveredNode.value} 个工位</div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* 图例 */}
          <Card className="bg-white border border-gray-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-900">流程图例</CardTitle>
            </CardHeader>
            <CardContent className="pt-0 space-y-2">
              <div className="space-y-2">
                <div className="text-xs font-medium text-gray-700 mb-2">流程层级说明：</div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-500 rounded"></div>
                  <div className="text-xs text-gray-600">需求收集</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded"></div>
                  <div className="text-xs text-gray-600">需求分配</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-500 rounded"></div>
                  <div className="text-xs text-gray-600">租赁流程</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-cyan-500 rounded"></div>
                  <div className="text-xs text-gray-600">装修流程</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-emerald-500 rounded"></div>
                  <div className="text-xs text-gray-600">交付验收</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-yellow-500 rounded"></div>
                  <div className="text-xs text-gray-600">空间分配</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-pink-500 rounded"></div>
                  <div className="text-xs text-gray-600">搬迁安排</div>
                </div>
              </div>
              <div className="border-t pt-2 mt-3">
                <div className="text-xs text-gray-500">
                  数据关系：需求数量 = 分配数量 + 新增需求
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}