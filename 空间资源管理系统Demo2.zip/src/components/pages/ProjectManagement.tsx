import { useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Search, BarChart3 } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import { TablePagination } from "../ui/table-pagination";


interface ProjectManagementProps {
  onNavigate?: (targetId: string, data?: any) => void;
}

export function ProjectManagementContent({ onNavigate }: ProjectManagementProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const [searchQuery, setSearchQuery] = useState("");
  const [projectType, setProjectType] = useState("all-types");
  const [projectStatus, setProjectStatus] = useState("all-status");
  const [statusSort, setStatusSort] = useState("default");
  const totalItems = 735; // 模拟总条数

  return (
    <div className="space-y-4">
      {/* 页面标题 */}
      <div className="flex items-center gap-3">
        <h1 className="text-[15px] font-bold">项目管理</h1>
        <Button 
          variant="outline" 
          size="sm" 
          className="h-7 text-xs bg-blue-50 border-blue-300 text-blue-700 hover:bg-blue-100 hover:border-blue-400"
          onClick={() => onNavigate?.("project-workflow-statistics")}
        >
          <BarChart3 className="h-3 w-3 mr-1" />
          项目全流程统计
        </Button>
      </div>

      {/* 统计区 */}
      <div className="space-y-3">


        <div className="grid grid-cols-7 gap-4">
          <div className="bg-[#e1f5fe] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600 mb-1">
              历史项目合计
            </div>
            <div className="text-2xl font-bold text-gray-900">
              156个
            </div>
          </div>
          <div className="bg-[#e8f5e8] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600 mb-1">
              新增需求
            </div>
            <div className="text-2xl font-bold text-gray-900">
              23个
            </div>
          </div>
          <div className="bg-[#fff8e1] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600 mb-1">
              租赁项目
            </div>
            <div className="text-2xl font-bold text-gray-900">
              12个
            </div>
          </div>
          <div className="bg-[#e3f2fd] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600 mb-1">
              持续自动化
            </div>
            <div className="text-2xl font-bold text-gray-900">
              8个
            </div>
          </div>
          <div className="bg-[#fce4ec] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600 mb-1">
              存文档项目
            </div>
            <div className="text-2xl font-bold text-gray-900">
              15个
            </div>
          </div>
          <div className="bg-[#e8f5e8] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600 mb-1">
              待分配项目
            </div>
            <div className="text-2xl font-bold text-gray-900">
              9个
            </div>
          </div>
          <div className="bg-[#e1f5fe] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600 mb-1">
              待调度项目
            </div>
            <div className="text-2xl font-bold text-gray-900">
              6个
            </div>
          </div>
        </div>
      </div>

      {/* 项目列表 */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-medium text-[14px]">
            项目列表
            </CardTitle>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2">

                <Button
                  size="sm"
                  className="h-7 text-xs bg-blue-600 hover:bg-blue-700"
                >
                  + 新增项目
                </Button>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="mt-[-21px] mr-[0px] mb-[0px] ml-[0px]">
          {/* 筛选区域 */}
          <div className="flex items-center gap-3 mb-4">
            {/* 搜索框 */}
            <div className="relative flex-1 max-w-80">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="搜索项目名称/编码"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-8 text-sm"
              />
            </div>
            
            {/* 项目类型 */}
            <Select value={projectType} onValueChange={setProjectType}>
              <SelectTrigger className="w-32 h-8 text-sm">
                <SelectValue placeholder="项目类型" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-types">全部类型</SelectItem>
                <SelectItem value="new-demand">新增需求</SelectItem>
                <SelectItem value="storage">存储资料</SelectItem>
                <SelectItem value="automation">持续自动化</SelectItem>
                <SelectItem value="document">存���档项目</SelectItem>
              </SelectContent>
            </Select>

            {/* 项目状态 */}
            <Select value={projectStatus} onValueChange={setProjectStatus}>
              <SelectTrigger className="w-32 h-8 text-sm">
                <SelectValue placeholder="项目状态" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-status">全部状态</SelectItem>
                <SelectItem value="pending">待分配</SelectItem>
                <SelectItem value="processing">进行中</SelectItem>
                <SelectItem value="completed">已完成</SelectItem>
                <SelectItem value="decision">决策中</SelectItem>
              </SelectContent>
            </Select>

            {/* 筛选按钮 */}
            <Button 
              variant="outline" 
              size="sm" 
              className="h-8 text-sm"
            >
              筛选
            </Button>

            {/* 按状态排序 */}
            <Select value={statusSort} onValueChange={setStatusSort}>
              <SelectTrigger className="w-32 h-8 text-sm">
                <SelectValue placeholder="按状态" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="default">默认排序</SelectItem>
                <SelectItem value="status-asc">状态升序</SelectItem>
                <SelectItem value="status-desc">状态降序</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* 项目列表表格 */}
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="text-xs">
                    项目编号
                  </TableHead>
                  <TableHead className="text-xs">
                    项目名称
                  </TableHead>
                  <TableHead className="text-xs">
                    状态
                  </TableHead>
                  <TableHead className="text-xs">
                    阶段
                  </TableHead>
                  <TableHead className="text-xs">
                    需求编号
                  </TableHead>
                  <TableHead className="text-xs">
                    需求类型
                  </TableHead>
                  <TableHead className="text-xs">
                    执行人
                  </TableHead>
                  <TableHead className="text-xs">
                    现阶段金额
                  </TableHead>
                  <TableHead className="text-xs">
                    业务名称
                  </TableHead>
                  <TableHead className="text-xs">
                    更新时间
                  </TableHead>
                  <TableHead className="text-xs">
                    更多人
                  </TableHead>
                  <TableHead className="text-xs">
                    操作
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {[
                  {
                    id: 1,
                    projectName: "PEKO06高级万芳-生活服务-15-16楼金计划项目",
                    status: "进行中",
                    stage: "装修阶段",
                    demandType: "成套分项",
                    executor: "张明",
                    amount: "68.5万",
                    business: "业务支援",
                    updateTime: "2024-08-15"
                  },
                  {
                    id: 2,
                    projectName: "华南区技术中心办公空间改造项目",
                    status: "已完成",
                    stage: "验收阶段",
                    demandType: "空间改造",
                    executor: "李华",
                    amount: "125.8万",
                    business: "技术研发",
                    updateTime: "2024-08-12"
                  },
                  {
                    id: 3,
                    projectName: "北京总部扩建-新增工位配置项目",
                    status: "待分配",
                    stage: "需求评审",
                    demandType: "工位配置",
                    executor: "王伟",
                    amount: "45.2万",
                    business: "人力资源",
                    updateTime: "2024-08-18"
                  },
                  {
                    id: 4,
                    projectName: "上海分公司会议室升级改造",
                    status: "进行中",
                    stage: "租赁阶段",
                    demandType: "设施升级",
                    executor: "赵敏",
                    amount: "32.6万",
                    business: "行政管理",
                    updateTime: "2024-08-14"
                  },
                  {
                    id: 5,
                    projectName: "广州研发基地空间规划项目",
                    status: "决策中",
                    stage: "方案设计",
                    demandType: "空间规划",
                    executor: "陈杰",
                    amount: "189.3万",
                    business: "研发中心",
                    updateTime: "2024-08-16"
                  },
                  {
                    id: 6,
                    projectName: "深圳办公区智能化系统部署",
                    status: "进行中",
                    stage: "资产配置",
                    demandType: "智能化",
                    executor: "刘强",
                    amount: "76.9万",
                    business: "信息技术",
                    updateTime: "2024-08-13"
                  }
                ].map((project) => (
                  <TableRow key={project.id}>
                    <TableCell className="text-xs">
                      PRJ{String(project.id).padStart(3, "0")}
                    </TableCell>
                    <TableCell className="text-xs">
                      <span 
                        className="text-blue-600 hover:text-blue-800 cursor-pointer"
                        onClick={() => onNavigate?.("project-details", { projectId: `PRJ${String(project.id).padStart(3, "0")}` })}
                      >
                        {project.projectName}
                      </span>
                    </TableCell>
                    <TableCell className="text-xs">
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        project.status === '进行中' ? 'bg-blue-100 text-blue-800' :
                        project.status === '已完成' ? 'bg-green-100 text-green-800' :
                        project.status === '待分配' ? 'bg-yellow-100 text-yellow-800' :
                        project.status === '决策中' ? 'bg-purple-100 text-purple-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {project.status}
                      </span>
                    </TableCell>
                    <TableCell className="text-xs">
                      {project.stage}
                    </TableCell>
                    <TableCell className="text-xs">
                      REQ{String(project.id).padStart(3, "0")}
                    </TableCell>
                    <TableCell className="text-xs">
                      {project.demandType}
                    </TableCell>
                    <TableCell className="text-xs">
                      {project.executor}
                    </TableCell>
                    <TableCell className="text-xs">
                      {project.amount}
                    </TableCell>
                    <TableCell className="text-xs">
                      {project.business}
                    </TableCell>
                    <TableCell className="text-xs">
                      {project.updateTime}
                    </TableCell>
                    <TableCell className="text-xs">
                      协作团队
                    </TableCell>
                    <TableCell className="text-xs">
                      <div className="flex items-center gap-1">
                        <Button
                          variant="link"
                          size="sm"
                          className="h-6 text-xs p-0 text-blue-600"
                        >
                          编辑
                        </Button>
                        <Button
                          variant="link"
                          size="sm"
                          className="h-6 text-xs p-0 text-blue-600"
                        >
                          删除
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* 分页控件 */}
          <TablePagination
            total={totalItems}
            currentPage={currentPage}
            pageSize={pageSize}
            onPageChange={setCurrentPage}
            onPageSizeChange={setPageSize}
          />
        </CardContent>
      </Card>
    </div>
  );
}