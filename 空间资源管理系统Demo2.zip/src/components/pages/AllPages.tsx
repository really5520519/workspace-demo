import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Input } from "../ui/input";
import { TablePagination } from "../ui/table-pagination";
import { 
  MapPin, Car, Building2, Truck, Archive, MessageCircle, Phone, Share2, 
  FileText, Map, Settings, ChevronLeft, ChevronRight, Plus, Download, 
  Grid, Layers, Search, Eye
} from "lucide-react";
import { SeatBindingContent as NewSeatBindingContent } from "./SeatBinding";
import { MovePlanContent as NewMovePlanContent } from "./MovePlan";

// WorkplaceManagement Component
export function WorkplaceManagementContent() {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const totalItems = 186; // 模拟总条数

  const [viewMode, setViewMode] = useState<"table" | "card">("table");

  return (
    <div className="space-y-4">
      {/* 页面标题 */}
      <div>
        <h1 className="text-lg font-medium">工区信息管理</h1>
      </div>



      {/* 工区概况 */}
      <div className="space-y-4">

        
        {/* 第一行 - 工区数量统计 */}
        <div className="grid grid-cols-5 gap-4">
          <div className="bg-[#e1f5fe] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600">工区数量</div>
            <div className="text-2xl font-bold text-gray-900 mt-1">45</div>
          </div>
          <div className="bg-[#e8f5e8] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600">已分配工区</div>
            <div className="text-2xl font-bold text-gray-900 mt-1">38</div>
          </div>
          <div className="bg-[#fff8e1] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600">未分配工区</div>
            <div className="text-2xl font-bold text-gray-900 mt-1">7</div>
          </div>
          <div className="bg-[#e3f2fd] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600">维修工区</div>
            <div className="text-2xl font-bold text-gray-900 mt-1">3</div>
          </div>
          <div className="bg-[#fce4ec] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600">计划新增工区</div>
            <div className="text-2xl font-bold text-gray-900 mt-1">2</div>
          </div>
        </div>

        {/* 第二行 - 工区面积统计 */}
        <div className="grid grid-cols-5 gap-4">
          <div className="bg-[#e1f5fe] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600">工区面积</div>
            <div className="text-2xl font-bold text-gray-900 mt-1">8,500</div>
          </div>
          <div className="bg-[#e8f5e8] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600">已分配面积</div>
            <div className="text-2xl font-bold text-gray-900 mt-1">7,200</div>
          </div>
          <div className="bg-[#fff8e1] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600">未分配面积</div>
            <div className="text-2xl font-bold text-gray-900 mt-1">1,300</div>
          </div>
          <div className="bg-[#e3f2fd] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600">维修面积</div>
            <div className="text-2xl font-bold text-gray-900 mt-1">400</div>
          </div>
          <div className="bg-[#fce4ec] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600">计划新增面积</div>
            <div className="text-2xl font-bold text-gray-900 mt-1">150</div>
          </div>
        </div>

        {/* 第三行 - 工位数量统计 */}
        <div className="grid grid-cols-5 gap-4">
          <div className="bg-[#e1f5fe] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600">工位数量</div>
            <div className="text-2xl font-bold text-gray-900 mt-1">125,000</div>
          </div>
          <div className="bg-[#e8f5e8] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600">已分配工位</div>
            <div className="text-2xl font-bold text-gray-900 mt-1">108,000</div>
          </div>
          <div className="bg-[#fff8e1] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600">未分配工位</div>
            <div className="text-2xl font-bold text-gray-900 mt-1">17,000</div>
          </div>
          <div className="bg-[#e3f2fd] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600">维修工位</div>
            <div className="text-2xl font-bold text-gray-900 mt-1">8,000</div>
          </div>
          <div className="bg-[#fce4ec] rounded-lg p-4 text-center">
            <div className="text-xs text-gray-600">计划新增工位</div>
            <div className="text-2xl font-bold text-gray-900 mt-1">3,500</div>
          </div>
        </div>
      </div>

      {/* 工区详情 */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-bold">工区详情</CardTitle>
            <div className="flex items-center gap-2">
              <Button size="sm" className="h-7 text-xs bg-blue-600 hover:bg-blue-700">
                新增工区
              </Button>
              <Button variant="outline" size="sm" className="h-7 text-xs">
                导出数据
              </Button>
            </div>
          </div>
          
          {/* 筛选器区域 */}
          <div className="mt-3 pt-3">
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-3 w-3 text-muted-foreground" />
                <Input 
                  placeholder="搜索工作区..." 
                  className="w-40 h-7 text-xs pl-7"
                />
              </div>
              <Select defaultValue="all-region">
                <SelectTrigger className="w-32 h-7 text-xs">
                  <SelectValue placeholder="按地区" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-region">按地区</SelectItem>
                  <SelectItem value="north">华北</SelectItem>
                  <SelectItem value="south">华南</SelectItem>
                  <SelectItem value="east">华东</SelectItem>
                  <SelectItem value="west">华西</SelectItem>
                </SelectContent>
              </Select>

              <Select defaultValue="all-city">
                <SelectTrigger className="w-32 h-7 text-xs">
                  <SelectValue placeholder="按城市" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-city">按城市</SelectItem>
                  <SelectItem value="beijing">北京</SelectItem>
                  <SelectItem value="shanghai">上海</SelectItem>
                  <SelectItem value="shenzhen">深圳</SelectItem>
                  <SelectItem value="guangzhou">广州</SelectItem>
                  <SelectItem value="hangzhou">杭州</SelectItem>
                </SelectContent>
              </Select>

              <Select defaultValue="all-compliance">
                <SelectTrigger className="w-36 h-7 text-xs">
                  <SelectValue placeholder="按合规状态" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-compliance">按合规状态</SelectItem>
                  <SelectItem value="compliant">合规</SelectItem>
                  <SelectItem value="non-compliant">不合规</SelectItem>
                  <SelectItem value="pending">待审核</SelectItem>
                </SelectContent>
              </Select>

              <Select defaultValue="all-area-status">
                <SelectTrigger className="w-36 h-7 text-xs">
                  <SelectValue placeholder="按区域状态" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-area-status">按区域状态</SelectItem>
                  <SelectItem value="common">常用</SelectItem>
                  <SelectItem value="premium">高档</SelectItem>
                  <SelectItem value="building-a">A座</SelectItem>
                </SelectContent>
              </Select>

              <Select defaultValue="all-business-status">
                <SelectTrigger className="w-36 h-7 text-xs">
                  <SelectValue placeholder="按业务状态" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-business-status">按业务状态</SelectItem>
                  <SelectItem value="operating">运营中</SelectItem>
                  <SelectItem value="decoration">装修中</SelectItem>
                  <SelectItem value="planned">规划中</SelectItem>
                </SelectContent>
              </Select>

              <Select defaultValue="all-operation">
                <SelectTrigger className="w-32 h-7 text-xs">
                  <SelectValue placeholder="按运营" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-operation">按运营</SelectItem>
                  <SelectItem value="running">运行</SelectItem>
                  <SelectItem value="maintenance">维护</SelectItem>
                  <SelectItem value="stopped">停用</SelectItem>
                </SelectContent>
              </Select>

              <Select defaultValue="all-workstation">
                <SelectTrigger className="w-32 h-7 text-xs">
                  <SelectValue placeholder="按工位" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-workstation">按工位</SelectItem>
                  <SelectItem value="available">可用</SelectItem>
                  <SelectItem value="occupied">占用</SelectItem>
                  <SelectItem value="reserved">预留</SelectItem>
                </SelectContent>
              </Select>

              <Select defaultValue="all-resource">
                <SelectTrigger className="w-36 h-7 text-xs">
                  <SelectValue placeholder="按资源大类" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-resource">按资源大类</SelectItem>
                  <SelectItem value="office">办公空间</SelectItem>
                  <SelectItem value="meeting">会议空间</SelectItem>
                  <SelectItem value="support">支持空间</SelectItem>
                </SelectContent>
              </Select>

              <Button variant="outline" size="sm" className="h-7 text-xs text-red-600 hover:text-red-700">
                筛选清除
              </Button>

              <div className="ml-auto flex items-center gap-2">

              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* 数据表格 */}
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="text-xs">基本信息</TableHead>
                  <TableHead className="text-xs">工区编号</TableHead>
                  <TableHead className="text-xs">数字信息</TableHead>
                  <TableHead className="text-xs">运营信息</TableHead>
                  <TableHead className="text-xs">装修信息</TableHead>
                  <TableHead className="text-xs">合规状态</TableHead>
                  <TableHead className="text-xs">区域状态</TableHead>
                  <TableHead className="text-xs">状态</TableHead>
                  <TableHead className="text-xs">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {/* Simplified table rows - using sample data */}
                {[
                  { id: "1", name: "北京大兴工区", city: "北京", code: "BJ2000", status: "运行" },
                  { id: "2", name: "深圳南山工区", city: "广东", code: "SZ2400", status: "运行" },
                  { id: "3", name: "广州天河工区", city: "广东", code: "GZ1400", status: "装修中" },
                ].map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="text-xs">
                      <div>
                        <div className="font-medium">{item.name}</div>
                        <div className="text-gray-500">{item.city}</div>
                      </div>
                    </TableCell>
                    <TableCell className="text-xs">{item.code}</TableCell>
                    <TableCell className="text-xs">M2500</TableCell>
                    <TableCell className="text-xs">运营中</TableCell>
                    <TableCell className="text-xs">装修方：示例装修信息</TableCell>
                    <TableCell className="text-xs">103000</TableCell>
                    <TableCell className="text-xs">常用</TableCell>
                    <TableCell className="text-xs">
                      <Badge className={`text-xs ${item.status === '运行' ? 'bg-blue-100 text-blue-800' : 'bg-orange-100 text-orange-800'}`}>
                        {item.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs">
                      <div className="flex items-center gap-1">
                        <Button variant="link" size="sm" className="h-6 text-xs p-0">编辑</Button>
                        <Button variant="link" size="sm" className="h-6 text-xs p-0">查看</Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <TablePagination
            total={totalItems}
            currentPage={currentPage}
            pageSize={pageSize}
            onPageChange={setCurrentPage}
            onPageSizeChange={setPageSize}
          />
        </CardContent>
      </Card>
    </div>
  );
}

// SpaceService Component
interface SpaceServiceContentProps {
  onNavigate?: (targetId: string, data?: any) => void;
}

export function SpaceServiceContent({ onNavigate }: SpaceServiceContentProps) {
  const [selectedLocation, setSelectedLocation] = useState("北京-时尚万科大厦-A座12F");

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-lg font-medium">空间服务</h1>

      </div>

      {/* 上侧位置选择行 */}
      <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
        <MapPin className="h-4 w-4 text-primary" />
        <span className="text-xs text-muted-foreground">当前工区位置：</span>
        <Select value={selectedLocation} onValueChange={setSelectedLocation}>
          <SelectTrigger className="w-64 h-7 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="北京-时尚万科大厦-A座12F">北京-时尚万科厦-A-12F</SelectItem>
            <SelectItem value="北京-望京SOHO-T1-18F">北京-望京SOHO-T1-18F</SelectItem>
            <SelectItem value="上海-陆家嘴中心-B座25F">上海-陆家嘴中心-B座25F</SelectItem>
          </SelectContent>
        </Select>
        <Button size="sm" className="h-7 text-xs bg-blue-600 text-white hover:bg-blue-700">
          <Car className="h-3 w-3 mr-1" />
          打车
        </Button>
      </div>

      {/* 中侧应用入口 */}
      <div className="space-y-3">
        <h3 className="text-sm font-medium">应用入口</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => onNavigate?.("seat-binding")}>
            <CardContent className="p-3 h-20 flex flex-col items-center justify-center gap-1.5">
              <div className="w-7 h-7 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <MapPin className="h-3.5 w-3.5 text-blue-600" />
              </div>
              <span className="text-xs font-medium text-center leading-tight">我的工位</span>
            </CardContent>
          </Card>
          <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => onNavigate?.("move-plan")}>
            <CardContent className="p-3 h-20 flex flex-col items-center justify-center gap-1.5">
              <div className="w-7 h-7 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Truck className="h-3.5 w-3.5 text-green-600" />
              </div>
              <span className="text-xs font-medium text-center leading-tight">工位搬家</span>
            </CardContent>
          </Card>
          <Card className="hover:shadow-md transition-shadow cursor-pointer border-2 border-dashed border-primary/30">
            <CardContent className="p-3 h-20 flex flex-col items-center justify-center gap-1.5">
              <div className="w-7 h-7 bg-cyan-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Share2 className="h-3.5 w-3.5 text-cyan-600" />
              </div>
              <span className="text-xs font-medium text-center leading-tight">共享工位</span>
            </CardContent>
          </Card>
          <Card className="hover:shadow-md transition-shadow cursor-pointer border-2 border-dashed border-primary/30">
            <CardContent className="p-3 h-20 flex flex-col items-center justify-center gap-1.5">
              <div className="w-7 h-7 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Archive className="h-3.5 w-3.5 text-purple-600" />
              </div>
              <span className="text-xs font-medium text-center leading-tight">我的智能柜</span>
            </CardContent>
          </Card>
          <Card className="hover:shadow-md transition-shadow cursor-pointer border-2 border-dashed border-primary/30">
            <CardContent className="p-3 h-20 flex flex-col items-center justify-center gap-1.5">
              <div className="w-7 h-7 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Phone className="h-3.5 w-3.5 text-orange-600" />
              </div>
              <span className="text-xs font-medium text-center leading-tight">寻找电话亭</span>
            </CardContent>
          </Card>
          <Card className="hover:shadow-md transition-shadow cursor-pointer border-2 border-dashed border-primary/30">
            <CardContent className="p-3 h-20 flex flex-col items-center justify-center gap-1.5">
              <div className="w-7 h-7 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Car className="h-3.5 w-3.5 text-red-600" />
              </div>
              <span className="text-xs font-medium text-center leading-tight">字节停车</span>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* 下侧区域 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* 最新工区通知 */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">最新工区通知</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="p-2 bg-blue-50 rounded text-xs">
              <div className="font-medium">15-16层空调维护通知</div>
              <div className="text-muted-foreground">明日8:00-10:00进行空调系统维护</div>
              <div className="text-muted-foreground">2小时前</div>
            </div>
            <div className="p-2 bg-green-50 rounded text-xs">
              <div className="font-medium">新员工入职培训</div>
              <div className="text-muted-foreground">本周三下午2:00会议室A</div>
              <div className="text-muted-foreground">1天前</div>
            </div>
            <div className="p-2 bg-orange-50 rounded text-xs">
              <div className="font-medium">消防演练通知</div>
              <div className="text-muted-foreground">下周一上午进行消防演练</div>
              <div className="text-muted-foreground">3天前</div>
            </div>
          </CardContent>
        </Card>

        {/* 楼宇指南 */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">楼宇指南</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button variant="outline" size="sm" className="w-full justify-start h-8 text-xs text-[13px]">
              <FileText className="h-3 w-3 mr-2" />
              消防疏散平面图
            </Button>
            <Button variant="outline" size="sm" className="w-full justify-start h-8 text-xs">
              <MapPin className="h-3 w-3 mr-2" />
              会议室分布
            </Button>
            <Button variant="outline" size="sm" className="w-full justify-start h-8 text-xs">
              <MessageCircle className="h-3 w-3 mr-2" />
              联系方式
            </Button>
            <Button variant="outline" size="sm" className="w-full justify-start h-8 text-xs">
              <Settings className="h-3 w-3 mr-2" />
              设施说明
            </Button>
          </CardContent>
        </Card>

        {/* 生活群 */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">生活群</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button variant="outline" size="sm" className="w-full justify-start h-8 text-xs border-2 border-dashed border-primary/30">
              <MessageCircle className="h-3 w-3 mr-2" />
              生活群1 (飞书群)
            </Button>
            <Button variant="outline" size="sm" className="w-full justify-start h-8 text-xs border-2 border-dashed border-primary/30">
              <MessageCircle className="h-3 w-3 mr-2" />
              生活群2 (飞书群)
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// Simple placeholder components for other pages
export function SeatBindingContent() { return <NewSeatBindingContent />; }
export function MovePlanContent() { return <NewMovePlanContent />; }
export function SpaceResourceServiceContent() { return <div className="p-8 text-center">空间资源与服务页面 - 功能开发中</div>; }
export function SpaceUsageContent() {
  // 工位配套数据
  const workstationData = [
    { label: "在职人数", value: "70" },
    { label: "产品投入", value: "0.3" },
    { label: "工位数", value: "70" },
    { label: "预约数", value: "70" },
    { label: "已预约过期人数", value: "0.5" },
    { label: "库存数", value: "0" },
    { label: "评分数", value: "0.3" }
  ];

  // 空间预算统计数据
  const budgetData = [
    { label: "装修", value: "10" },
    { label: "流程签", value: "5" },
    { label: "系统签", value: "2" },
    { label: "驿馆", value: "1" },
    { label: "已预算金额", value: "8" },
    { label: "已通过申请", value: "2" }
  ];

  // 常用地点预约统计表格数据
  const locationData = [
    {
      id: "1",
      city: "北京",
      hcCount: "50",
      allocatedCount: "48",
      estimatedCount: "50",
      independentSpaceCount: "2",
      action: "详情"
    },
    {
      id: "2", 
      city: "上海",
      hcCount: "30",
      allocatedCount: "15",
      estimatedCount: "20",
      independentSpaceCount: "1",
      action: "详情"
    }
  ];

  return (
    <div className="space-y-4">
      {/* 页面标题 */}
      <div>
        <h1 className="text-lg font-medium">空间资源使用</h1>
      </div>

      {/* 工位配套和空间预算统计横向并列 */}
      <div className="grid grid-cols-2 gap-4">
        {/* 工位配套 */}
        <Card className="bg-white border border-gray-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-900">工位使用</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="grid grid-cols-7 gap-4">
              {workstationData.map((item, index) => (
                <div key={index} className="text-center">
                  <div className="text-xs text-gray-600 mb-1">{item.label}</div>
                  <div className="text-lg font-medium text-gray-900">{item.value}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* 空间预算统计 */}
        <Card className="bg-white border border-gray-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-900">空间使用</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="grid grid-cols-6 gap-4">
              {budgetData.map((item, index) => (
                <div key={index} className="text-center">
                  <div className="text-xs text-gray-600 mb-1">{item.label}</div>
                  <div className="text-lg font-medium text-gray-900">{item.value}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 常用地点预约统计 */}
      <Card className="bg-white border border-gray-200">
        <CardContent className="p-0">
          <Tabs defaultValue="locations" className="w-full">
            <TabsList className="inline-flex items-center justify-center rounded-full bg-gray-100 p-1 mx-6 mt-6 mb-0">
              <TabsTrigger 
                value="locations" 
                className="inline-flex items-center justify-center whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-white data-[state=active]:text-foreground data-[state=active]:shadow-sm text-gray-600"
              >
                常用地点
              </TabsTrigger>
              <TabsTrigger 
                value="reservations" 
                className="inline-flex items-center justify-center whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-white data-[state=active]:text-foreground data-[state=active]:shadow-sm text-gray-600"
              >
                预约统计
              </TabsTrigger>
            </TabsList>
            <TabsContent value="locations" className="mt-0 p-6">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">城市</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">HC人数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">分配人数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">计划工位数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">计划空间数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {locationData.map((record) => (
                      <TableRow key={record.id} className="hover:bg-gray-50">
                        <TableCell className="text-xs text-gray-900 text-center">{record.city}</TableCell>
                        <TableCell className="text-xs text-gray-900 text-center">{record.hcCount}</TableCell>
                        <TableCell className="text-xs text-gray-900 text-center">{record.allocatedCount}</TableCell>
                        <TableCell className="text-xs text-gray-900 text-center">{record.estimatedCount}</TableCell>
                        <TableCell className="text-xs text-gray-900 text-center">{record.independentSpaceCount}</TableCell>
                        <TableCell className="text-xs text-center">
                          <Button 
                            variant="link" 
                            size="sm" 
                            className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                          >
                            {record.action}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
            <TabsContent value="reservations" className="mt-0 p-6">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">预约日期</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">预约人数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">已确认</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">待确认</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">取消数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10 text-center">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow className="hover:bg-gray-50">
                      <TableCell className="text-xs text-gray-900 text-center">2024-01-15</TableCell>
                      <TableCell className="text-xs text-gray-900 text-center">25</TableCell>
                      <TableCell className="text-xs text-gray-900 text-center">20</TableCell>
                      <TableCell className="text-xs text-gray-900 text-center">3</TableCell>
                      <TableCell className="text-xs text-gray-900 text-center">2</TableCell>
                      <TableCell className="text-xs text-center">
                        <Button 
                          variant="link" 
                          size="sm" 
                          className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                        >
                          详情
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow className="hover:bg-gray-50">
                      <TableCell className="text-xs text-gray-900 text-center">2024-01-14</TableCell>
                      <TableCell className="text-xs text-gray-900 text-center">18</TableCell>
                      <TableCell className="text-xs text-gray-900 text-center">15</TableCell>
                      <TableCell className="text-xs text-gray-900 text-center">2</TableCell>
                      <TableCell className="text-xs text-gray-900 text-center">1</TableCell>
                      <TableCell className="text-xs text-center">
                        <Button 
                          variant="link" 
                          size="sm" 
                          className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                        >
                          详情
                        </Button>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
export function SpaceBillingContent() { return <div className="p-8 text-center">空间费用账单页面 - 功能开发中</div>; }