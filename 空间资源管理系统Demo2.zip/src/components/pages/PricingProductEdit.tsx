import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Switch } from "../ui/switch";
import { Badge } from "../ui/badge";
import { ArrowLeft, Save } from "lucide-react";

interface PricingProductEditProps {
  onNavigate?: (page: string, data?: any) => void;
  productId?: string;
}

export function PricingProductEditContent({ onNavigate, productId }: PricingProductEditProps) {
  // 根据productId获取商品数据
  const getProductData = (id?: string) => {
    // 模拟数据，实际应该从API获取
    const products = {
      "1": {
        id: "1",
        pricingYear: "2025",
        pricingMonth: "08月",
        propertyZone: "华北区",
        country: "中国",
        city: "北京",
        workAreaCode: "WA-BJ001",
        workAreaName: "北京总部工区",
        workAreaFloor: "12F",
        floorStatus: true,
        attribute: "资源类",
        productCategory: "资源类-工位",
        productType: "工位",
        productId: "WS-001",
        skuName: "普通挡板工位",
        pricingMethod: "按用量和时间收费",
        unitPrice: 180,
        pricingUnit: "元/天/个",
        usageBillingMethod: "已分配数量",
        usageUnit: "个",
        billingTimeType: "分配日期-退租日期",
        pricingValidPeriod: "20230101-20291231",
        defaultCurrency: "RMB",
        discountStrategy: "按量折扣",
        billingStrategy: "成本定价-折扣"
      },
      "2": {
        id: "2",
        pricingYear: "2025",
        pricingMonth: "08月",
        propertyZone: "华东区",
        country: "中国",
        city: "上海",
        workAreaCode: "WA-SH002",
        workAreaName: "上海分公司工区",
        workAreaFloor: "8F",
        floorStatus: true,
        attribute: "服务类",
        productCategory: "资源类-会议协作",
        productType: "空间",
        productId: "MR-002",
        skuName: "高级会议室-上海分公司",
        pricingMethod: "按小时计费",
        unitPrice: 300,
        pricingUnit: "元/小时",
        usageBillingMethod: "已分配数量",
        usageUnit: "个",
        billingTimeType: "预约日期-使用日期",
        pricingValidPeriod: "20230101-20291231",
        defaultCurrency: "RMB",
        discountStrategy: "阈值限制",
        billingStrategy: "成本定价*档位系数"
      },
      "3": {
        id: "3",
        pricingYear: "2025",
        pricingMonth: "08月",
        propertyZone: "华南区",
        country: "中国",
        city: "深圳",
        workAreaCode: "WA-SZ003",
        workAreaName: "深圳科技园工区",
        workAreaFloor: "全楼层",
        floorStatus: false,
        attribute: "服务类",
        productCategory: "服务类-Day2改造",
        productType: "运营",
        productId: "SV-003",
        skuName: "Day2改造服务",
        pricingMethod: "按项目计费",
        unitPrice: 8000,
        pricingUnit: "元/月",
        usageBillingMethod: "已分配数量",
        usageUnit: "项目",
        billingTimeType: "自然月",
        pricingValidPeriod: "20230101-20291231",
        defaultCurrency: "RMB",
        discountStrategy: "档位系数",
        billingStrategy: "成本定价"
      },
      "4": {
        id: "4",
        pricingYear: "2025",
        pricingMonth: "08月",
        propertyZone: "全国",
        country: "中国",
        city: "全国",
        workAreaCode: "WA-GZ004",
        workAreaName: "广州天河工区",
        workAreaFloor: "15F",
        floorStatus: true,
        attribute: "人力类",
        productCategory: "服务类-新交付装修",
        productType: "服务",
        productId: "HR-004",
        skuName: "人力外包服务",
        pricingMethod: "按人天计费",
        unitPrice: 500,
        pricingUnit: "元/次",
        usageBillingMethod: "已分配数量",
        usageUnit: "人",
        billingTimeType: "签约日期-合同到期日期",
        pricingValidPeriod: "20230101-20291231",
        defaultCurrency: "RMB",
        discountStrategy: "直接抵扣",
        billingStrategy: "成本定价-折扣"
      }
    };
    return products[id as keyof typeof products] || products["1"];
  };

  const [formData, setFormData] = useState(getProductData(productId));

  const handleBack = () => {
    onNavigate?.("pricing-management");
  };

  const handleSave = () => {
    console.log("保存商品数据:", formData);
    // 这里可以添加保存逻辑
    onNavigate?.("pricing-management");
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <div className="space-y-4" style={{ maxWidth: '1300px', margin: '0 auto' }}>
      {/* 页面标题和操作按钮 */}
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleBack}
            className="h-8 px-2"
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            返回
          </Button>
          <div>
            <h1>商品编辑</h1>
            <p className="text-muted-foreground">编辑商品的定价和配置信息</p>
          </div>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700 text-white" onClick={handleSave}>
          <Save className="h-4 w-4 mr-1" />
          保存
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>基本信息</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* 第一行：定价年度、定价月份、房产分区、国家 */}
          <div className="grid grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>定价年度</Label>
              <Input
                value={formData.pricingYear}
                onChange={(e) => handleInputChange('pricingYear', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>定价月份</Label>
              <Select value={formData.pricingMonth} onValueChange={(value) => handleInputChange('pricingMonth', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="01月">01月</SelectItem>
                  <SelectItem value="02月">02月</SelectItem>
                  <SelectItem value="03月">03月</SelectItem>
                  <SelectItem value="04月">04月</SelectItem>
                  <SelectItem value="05月">05月</SelectItem>
                  <SelectItem value="06月">06月</SelectItem>
                  <SelectItem value="07月">07月</SelectItem>
                  <SelectItem value="08月">08月</SelectItem>
                  <SelectItem value="09月">09月</SelectItem>
                  <SelectItem value="10月">10月</SelectItem>
                  <SelectItem value="11月">11月</SelectItem>
                  <SelectItem value="12月">12月</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>房产分区</Label>
              <Select value={formData.propertyZone} onValueChange={(value) => handleInputChange('propertyZone', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="华北区">华北区</SelectItem>
                  <SelectItem value="华东区">华东区</SelectItem>
                  <SelectItem value="华南区">华南区</SelectItem>
                  <SelectItem value="华西区">华西区</SelectItem>
                  <SelectItem value="全国">全国</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>国家</Label>
              <Input
                value={formData.country}
                onChange={(e) => handleInputChange('country', e.target.value)}
              />
            </div>
          </div>

          {/* 第二行：城市、工区编码、工区名称、工区楼层 */}
          <div className="grid grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>城市</Label>
              <Input
                value={formData.city}
                onChange={(e) => handleInputChange('city', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>工区编码</Label>
              <Input
                value={formData.workAreaCode}
                onChange={(e) => handleInputChange('workAreaCode', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>工区名称</Label>
              <Input
                value={formData.workAreaName}
                onChange={(e) => handleInputChange('workAreaName', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>工区楼层</Label>
              <Input
                value={formData.workAreaFloor}
                onChange={(e) => handleInputChange('workAreaFloor', e.target.value)}
              />
            </div>
          </div>

          {/* 第三行：楼层状态、属性、商品大类、商品类型 */}
          <div className="grid grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>楼层状态</Label>
              <div className="flex items-center space-x-2 h-10">
                <Switch
                  checked={formData.floorStatus}
                  onCheckedChange={(checked) => handleInputChange('floorStatus', checked)}
                />
                <Badge variant={formData.floorStatus ? "default" : "secondary"} className={
                  formData.floorStatus ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                }>
                  {formData.floorStatus ? "启用" : "停用"}
                </Badge>
              </div>
            </div>
            <div className="space-y-2">
              <Label>属性</Label>
              <Select value={formData.attribute} onValueChange={(value) => handleInputChange('attribute', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="资源类">资源类</SelectItem>
                  <SelectItem value="服务类">服务类</SelectItem>
                  <SelectItem value="人力类">人力类</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>商品大类</Label>
              <Select value={formData.productCategory} onValueChange={(value) => handleInputChange('productCategory', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="资源类-工位">资源类-工位</SelectItem>
                  <SelectItem value="资源类-会议协作">资源类-会议协作</SelectItem>
                  <SelectItem value="服务类-Day2改造">服务类-Day2改造</SelectItem>
                  <SelectItem value="服务类-新交付装修">服务类-新交付装修</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>商品类型</Label>
              <Input
                value={formData.productType}
                onChange={(e) => handleInputChange('productType', e.target.value)}
              />
            </div>
          </div>

          {/* 第四行：商品ID、商品SKU名称 */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>商品ID</Label>
              <Input
                value={formData.productId}
                onChange={(e) => handleInputChange('productId', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>商品SKU名称</Label>
              <Input
                value={formData.skuName}
                onChange={(e) => handleInputChange('skuName', e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>定价信息</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* 第一行：定价方式、单价、计价单位-P */}
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>定价方式</Label>
              <Select value={formData.pricingMethod} onValueChange={(value) => handleInputChange('pricingMethod', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="按用量和时间收费">按用量和时间收费</SelectItem>
                  <SelectItem value="按小时计费">按小时计费</SelectItem>
                  <SelectItem value="按项目计费">按项目计费</SelectItem>
                  <SelectItem value="按人天计费">按人天计费</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>单价</Label>
              <Input
                type="number"
                value={formData.unitPrice}
                onChange={(e) => handleInputChange('unitPrice', Number(e.target.value))}
                className="text-blue-600"
              />
            </div>
            <div className="space-y-2">
              <Label>计价单位-P</Label>
              <Input
                value={formData.pricingUnit}
                onChange={(e) => handleInputChange('pricingUnit', e.target.value)}
              />
            </div>
          </div>

          {/* 第二行：用量计费方式-Q、用量单位-Q、计费时间类型-T */}
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>用量计费方式-Q</Label>
              <Input
                value={formData.usageBillingMethod}
                onChange={(e) => handleInputChange('usageBillingMethod', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>用量单位-Q</Label>
              <Input
                value={formData.usageUnit}
                onChange={(e) => handleInputChange('usageUnit', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>计费时间类型-T</Label>
              <Input
                value={formData.billingTimeType}
                onChange={(e) => handleInputChange('billingTimeType', e.target.value)}
              />
            </div>
          </div>

          {/* 第三行：定价有效期、默认货币类型 */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>定价有效期</Label>
              <Input
                value={formData.pricingValidPeriod}
                onChange={(e) => handleInputChange('pricingValidPeriod', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>默认货币类型</Label>
              <Select value={formData.defaultCurrency} onValueChange={(value) => handleInputChange('defaultCurrency', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="RMB">RMB</SelectItem>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                  <SelectItem value="HKD">HKD</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* 第四行：折扣策略、计费策略 */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>折扣策略</Label>
              <Select value={formData.discountStrategy} onValueChange={(value) => handleInputChange('discountStrategy', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="按量折扣">按量折扣</SelectItem>
                  <SelectItem value="阈值限制">阈值限制</SelectItem>
                  <SelectItem value="档位系数">档位系数</SelectItem>
                  <SelectItem value="直接抵扣">直接抵扣</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>计费策略</Label>
              <Select value={formData.billingStrategy} onValueChange={(value) => handleInputChange('billingStrategy', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="成本定价-折扣">成本定价-折扣</SelectItem>
                  <SelectItem value="成本定价*档位系数">成本定价*档位系数</SelectItem>
                  <SelectItem value="成本定价">成本定价</SelectItem>
                  <SelectItem value="价格阈值">价格阈值</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}