import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Textarea } from "../ui/textarea";
import { Calendar } from "../ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "../ui/popover";
import { Switch } from "../ui/switch";
import { CalendarIcon, ChevronLeft, CheckCircle } from "lucide-react";
// 简单的日期格式化函数，避免外部依赖
const formatDate = (date: Date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

interface RequirementApplicationProps {
  onBack: () => void;
}

export function RequirementApplication({ onBack }: RequirementApplicationProps) {
  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();
  const [currentStep] = useState(1); // 当前步骤
  const [isWithinBudget, setIsWithinBudget] = useState(false); // 是否预算内
  
  // 计算需求期间天数
  const calculateDays = () => {
    if (startDate && endDate) {
      const diffTime = Math.abs(endDate.getTime() - startDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays;
    }
    return 0;
  };

  const steps = [
    { id: 1, name: "基本信息", completed: currentStep > 1, active: currentStep === 1 },
    { id: 2, name: "业务信息", completed: currentStep > 2, active: currentStep === 2 },
    { id: 3, name: "房产信息", completed: currentStep > 3, active: currentStep === 3 }
  ];

  return (
    <div className="space-y-6">
      {/* 顶栏 */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={onBack}
            className="h-8 w-8 p-0"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-lg font-medium">需求申请</h1>
            <p className="text-sm text-gray-500">ID：PEK238457103712</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button size="sm" className="h-7 text-xs bg-blue-600 text-white hover:bg-blue-700">
            创建
          </Button>
          <Button size="sm" variant="outline" className="h-7 text-xs">
            保存
          </Button>
          <Button size="sm" variant="outline" className="h-7 text-xs" onClick={onBack}>
            取消
          </Button>
        </div>
      </div>

      {/* 进度箭头图 */}
      <div className="p-6">
        <div className="flex items-center justify-center max-w-2xl mx-auto">
          {steps.map((step, index) => (
            <div key={step.id} className="flex items-center">
              {/* 步骤圆圈 */}
              <div className="flex flex-col items-center">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    step.completed
                      ? "bg-green-500 text-white"
                      : step.active
                      ? "bg-blue-600 text-white"
                      : "bg-gray-200 text-gray-500"
                  }`}
                >
                  {step.completed ? (
                    <CheckCircle className="h-4 w-4" />
                  ) : (
                    <span>{step.id}</span>
                  )}
                </div>
                <span className={`mt-2 text-sm ${
                  step.active ? "text-blue-600 font-medium" : step.completed ? "text-green-600" : "text-gray-500"
                }`}>
                  {step.name}
                </span>
              </div>
              
              {/* 连接线 */}
              {index < steps.length - 1 && (
                <div className="flex-1 h-px bg-gray-200 mx-8 min-w-[80px]">
                  <div 
                    className={`h-full transition-all duration-300 ${
                      steps[index + 1].completed ? "bg-green-500" : steps[index + 1].active ? "bg-blue-600" : "bg-gray-200"
                    }`}
                    style={{ width: steps[index + 1].completed ? "100%" : "0%" }}
                  />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* 基本信息卡片 */}
      <Card className="bg-gray-50 border border-gray-200">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-medium text-gray-900">基本信息</CardTitle>
            <div className="flex items-center gap-3">
              <Label className="text-xs text-gray-700">是否预算内</Label>
              <Switch
                checked={isWithinBudget}
                onCheckedChange={setIsWithinBudget}
                className="h-5 w-9"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-6">
            <div className="space-y-4">
              {/* 第一行 - 3列布局 */}
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <Label className="text-xs text-gray-700 mb-2 block">申请人信息</Label>
                  <Input 
                    value="张三" 
                    disabled 
                    className="h-8 text-xs bg-white"
                  />
                </div>
                <div>
                  <Label className="text-xs text-gray-700 mb-2 block">申请部门</Label>
                  <Input 
                    value="技术部" 
                    disabled 
                    className="h-8 text-xs bg-gray-100 text-gray-500"
                  />
                </div>
                <div>
                  <Label className="text-xs text-gray-700 mb-2 block">申请人房产BP</Label>
                  <Input 
                    value="李经理" 
                    disabled 
                    className="h-8 text-xs bg-gray-100 text-gray-500"
                  />
                </div>
              </div>

              {/* 第二行 - 3列布局 */}
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <Label className="text-xs text-gray-700 mb-2 block">需求类型</Label>
                  <Select>
                    <SelectTrigger className="h-8 text-xs bg-white">
                      <SelectValue placeholder="请选择需求类型" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="resource">资源类</SelectItem>
                      <SelectItem value="service">服务类</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs text-gray-700 mb-2 block">二级类型</Label>
                  <Select>
                    <SelectTrigger className="h-8 text-xs bg-white">
                      <SelectValue placeholder="请选择二级类型" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="workstation">资源类-工位</SelectItem>
                      <SelectItem value="independent">资源类-独立空间</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs text-gray-700 mb-2 block">需求期间</Label>
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="h-8 text-xs justify-start bg-white flex-1"
                          >
                            <CalendarIcon className="mr-2 h-3 w-3" />
                            {startDate ? formatDate(startDate) : "开始日期"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={startDate}
                            onSelect={setStartDate}
                          />
                        </PopoverContent>
                      </Popover>
                      
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="h-8 text-xs justify-start bg-white flex-1"
                          >
                            <CalendarIcon className="mr-2 h-3 w-3" />
                            {endDate ? formatDate(endDate) : "结束日期"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={endDate}
                            onSelect={setEndDate}
                          />
                        </PopoverContent>
                      </Popover>
                    </div>

                    {startDate && endDate && (
                      <p className="text-xs text-gray-500">
                        共计 {calculateDays()} 天
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {/* 第三行 - 需求楼宇、需求位置、需求用途并列 */}
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <Label className="text-xs text-gray-700 mb-2 block">需求楼宇</Label>
                  <Select>
                    <SelectTrigger className="h-8 text-xs bg-white">
                      <SelectValue placeholder="请选择楼宇" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beijing-hq">北京总部</SelectItem>
                      <SelectItem value="shanghai-branch">上海分部</SelectItem>
                      <SelectItem value="shenzhen-rd">深圳研发中心</SelectItem>
                      <SelectItem value="guangzhou-office">广州商务区</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs text-gray-700 mb-2 block">需求位置</Label>
                  <Select>
                    <SelectTrigger className="h-8 text-xs bg-white">
                      <SelectValue placeholder="请选择位置" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="a3">A栋-3楼</SelectItem>
                      <SelectItem value="a4">A栋-4楼</SelectItem>
                      <SelectItem value="b2">B栋-2楼</SelectItem>
                      <SelectItem value="b3">B栋-3楼</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs text-gray-700 mb-2 block">需求用途</Label>
                  <Select>
                    <SelectTrigger className="h-8 text-xs bg-white">
                      <SelectValue placeholder="请选择用途" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="temp">临时办公</SelectItem>
                      <SelectItem value="dev">封闭开发</SelectItem>
                      <SelectItem value="event">活动专用</SelectItem>
                      <SelectItem value="fixed">固定空间</SelectItem>
                      <SelectItem value="other">其他</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* 需求说明区域 - 移动到最下方，跨越所有三列的宽度 */}
            <div className="grid grid-cols-3 gap-6">
              <div className="col-span-3">
                <Label className="text-xs text-gray-700 mb-2 block">需求说明</Label>
                <Textarea
                  className="min-h-[80px] text-xs bg-white resize-none"
                  placeholder="请详细描述您的需求..."
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 操作按钮区域 */}
      <div className="flex items-center justify-end gap-3 pt-4">
        <Button 
          variant="outline" 
          size="sm" 
          className="h-8 text-sm px-6"
        >
          保存
        </Button>
        <Button 
          size="sm" 
          className="h-8 text-sm px-6 bg-blue-600 hover:bg-blue-700"
        >
          下一步
        </Button>
      </div>
    </div>
  );
}