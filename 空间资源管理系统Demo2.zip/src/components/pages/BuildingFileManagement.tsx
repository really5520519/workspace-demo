import { useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Checkbox } from "../ui/checkbox";
import { Search, Download, Plus, Filter } from "lucide-react";
import { TablePagination } from "../ui/table-pagination";

export function BuildingFileManagementContent() {
  const [searchQuery, setSearchQuery] = useState("");
  const [fileType, setFileType] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  
  // 全局搜索状态
  const [globalSearchQuery, setGlobalSearchQuery] = useState("");
  const [searchTitleOnly, setSearchTitleOnly] = useState(false);
  const [searchFieldsOnly, setSearchFieldsOnly] = useState(false);
  const [searchFavorites, setSearchFavorites] = useState(false);
  
  // 租赁文件状态
  const [leaseSearchQuery, setLeaseSearchQuery] = useState("");
  const [leaseFileType, setLeaseFileType] = useState("all");
  const [leaseCurrentPage, setLeaseCurrentPage] = useState(1);
  
  // 项目施工文件状态
  const [constructionSearchQuery, setConstructionSearchQuery] = useState("");
  const [constructionFileType, setConstructionFileType] = useState("all");
  const [constructionCurrentPage, setConstructionCurrentPage] = useState(1);

  const totalItems = 87; // 模拟总条数
  const leaseTotalItems = 45; // 租赁文件总数
  const constructionTotalItems = 42; // 项目施工文件总数

  // 租赁文件数据
  const leaseFileData = [
    {
      id: "LEASE-001",
      name: "A区招商主合同",
      type: "租赁合同",
      date: "2022-11-15",
      status: "生效中"
    },
    {
      id: "LEASE-002",
      name: "B区租赁协议",
      type: "租赁协议",
      date: "2023-03-08",
      status: "生效中"
    },
    {
      id: "LEASE-003",
      name: "C区补充协议",
      type: "补充协议",
      date: "2023-06-20",
      status: "已归档"
    },
    {
      id: "LEASE-004",
      name: "租赁终止协议",
      type: "终止协议",
      date: "2023-09-15",
      status: "已归档"
    }
  ];

  // 项目施工文件数据
  const constructionFileData = [
    {
      id: "CON-001", 
      name: "16F装修工程合同",
      type: "装修合同",
      date: "2023-05-20",
      status: "生效中"
    },
    {
      id: "CON-002",
      name: "消防改造施工图纸",
      type: "施工图纸",
      date: "2023-07-12",
      status: "已归档"
    },
    {
      id: "CON-003",
      name: "电气系统验收报告",
      type: "验收报告",
      date: "2023-08-30",
      status: "生效中"
    },
    {
      id: "CON-004",
      name: "空调系统安装合同",
      type: "安装合同",
      date: "2023-04-18",
      status: "已归档"
    }
  ];

  // 租赁文件筛选
  const filteredLeaseData = leaseFileData.filter(file => {
    const matchesSearch = !leaseSearchQuery || 
                         file.name.toLowerCase().includes(leaseSearchQuery.toLowerCase()) || 
                         file.id.toLowerCase().includes(leaseSearchQuery.toLowerCase());
    const matchesType = !leaseFileType || leaseFileType === "all" || file.type === leaseFileType;
    return matchesSearch && matchesType;
  });

  // 项目施工文件筛选
  const filteredConstructionData = constructionFileData.filter(file => {
    const matchesSearch = !constructionSearchQuery || 
                         file.name.toLowerCase().includes(constructionSearchQuery.toLowerCase()) || 
                         file.id.toLowerCase().includes(constructionSearchQuery.toLowerCase());
    const matchesType = !constructionFileType || constructionFileType === "all" || file.type === constructionFileType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-4">
      {/* 页面标题 */}
      <div>
        <h1 className="text-lg font-medium">楼宇文件管理</h1>
      </div>

      {/* 全局搜索区域 */}
      <div className="bg-gray-50 p-4 rounded-lg">
        <div className="flex items-center gap-3">
          <div className="relative flex-1 max-w-3xl">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="输入空格分割多个关键词搜索"
              value={globalSearchQuery}
              onChange={(e) => setGlobalSearchQuery(e.target.value)}
              className="pl-[35px] h-9 text-sm bg-white pt-[3px] pr-[10px] pb-[3px]"
            />
          </div>
          <Button 
            size="sm" 
            className="h-9 px-6 bg-blue-600 hover:bg-blue-700 text-white"
          >
            搜索
          </Button>
          
          {/* 搜索选项 */}
          <div className="flex items-center gap-6 ml-4">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="search-title" 
                checked={searchTitleOnly}
                onCheckedChange={setSearchTitleOnly}
              />
              <label 
                htmlFor="search-title" 
                className="text-sm text-gray-700 cursor-pointer"
              >
                搜索标题
              </label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="search-fields" 
                checked={searchFieldsOnly}
                onCheckedChange={setSearchFieldsOnly}
              />
              <label 
                htmlFor="search-fields" 
                className="text-sm text-gray-700 cursor-pointer"
              >
                搜索文件内容
              </label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="search-favorites" 
                checked={searchFavorites}
                onCheckedChange={setSearchFavorites}
              />
              <label 
                htmlFor="search-favorites" 
                className="text-sm text-gray-700 cursor-pointer"
              >
                我收藏的
              </label>
            </div>
          </div>
        </div>
      </div>

      <Tabs defaultValue="lease-files" className="w-full">
        <TabsList className="grid w-fit grid-cols-2">
          <TabsTrigger value="lease-files">按楼宇</TabsTrigger>
          <TabsTrigger value="construction-files">按阶段</TabsTrigger>
        </TabsList>

        {/* 租赁文件标签页 */}
        <TabsContent value="lease-files" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">
                  楼宇文件列表
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Button size="sm" className="h-7 text-xs bg-blue-600 hover:bg-blue-700">
                    <Plus className="h-3 w-3 mr-1" />
                    上传文件
                  </Button>
                  <Button variant="outline" size="sm" className="h-7 text-xs">
                    <Download className="h-3 w-3 mr-1" />
                    批量导出
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {/* 搜索和筛选区域 */}
              <div className="flex items-center gap-3 mb-4">
                <div className="relative flex-1 max-w-80">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="搜索文件名称/编号..."
                    value={leaseSearchQuery}
                    onChange={(e) => setLeaseSearchQuery(e.target.value)}
                    className="pl-10 h-8 text-sm"
                  />
                </div>
                
                <Select value={leaseFileType} onValueChange={setLeaseFileType}>
                  <SelectTrigger className="w-36 h-8 text-sm">
                    <SelectValue placeholder="文件类型" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部类型</SelectItem>
                    <SelectItem value="租赁合同">租赁合同</SelectItem>
                    <SelectItem value="租赁协议">租赁协议</SelectItem>
                    <SelectItem value="补充协议">补充协议</SelectItem>
                    <SelectItem value="终止协议">终止协议</SelectItem>
                  </SelectContent>
                </Select>

                <Button 
                  variant="outline" 
                  size="sm" 
                  className="h-8 text-sm"
                  onClick={() => {
                    setLeaseSearchQuery("");
                    setLeaseFileType("all");
                  }}
                >
                  <Filter className="h-3 w-3 mr-1" />
                  清除筛选
                </Button>
              </div>

              {/* 文件列表表格 */}
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-sm">文件ID</TableHead>
                      <TableHead className="text-sm">文件名称</TableHead>
                      <TableHead className="text-sm">文件类型</TableHead>
                      <TableHead className="text-sm">更新日期</TableHead>
                      <TableHead className="text-sm">状态</TableHead>
                      <TableHead className="text-sm">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredLeaseData.map((file) => (
                      <TableRow key={file.id}>
                        <TableCell className="text-sm">{file.id}</TableCell>
                        <TableCell className="text-sm font-medium">{file.name}</TableCell>
                        <TableCell className="text-sm">{file.type}</TableCell>
                        <TableCell className="text-sm">{file.date}</TableCell>
                        <TableCell className="text-sm">
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            file.status === "生效中" 
                              ? "bg-green-100 text-green-800" 
                              : "bg-gray-100 text-gray-800"
                          }`}>
                            {file.status}
                          </span>
                        </TableCell>
                        <TableCell className="text-sm">
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 p-0"
                              title="下载"
                            >
                              <Download className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="link"
                              size="sm"
                              className="h-6 text-xs p-0"
                            >
                              查看
                            </Button>
                            <Button
                              variant="link"
                              size="sm"
                              className="h-6 text-xs p-0"
                            >
                              编辑
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                
                {filteredLeaseData.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground text-sm">
                    {leaseSearchQuery || (leaseFileType && leaseFileType !== "all") ? "没有找到匹配的文件" : "暂无租赁文件数据"}
                  </div>
                )}
              </div>

              <TablePagination
                total={leaseTotalItems}
                currentPage={leaseCurrentPage}
                pageSize={pageSize}
                onPageChange={setLeaseCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </CardContent>
          </Card>
        </TabsContent>

        {/* 项目施工文件标签页 */}
        <TabsContent value="construction-files" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium">
                  项目施工文件列表
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Button size="sm" className="h-7 text-xs bg-blue-600 hover:bg-blue-700">
                    <Plus className="h-3 w-3 mr-1" />
                    上传文件
                  </Button>
                  <Button variant="outline" size="sm" className="h-7 text-xs">
                    <Download className="h-3 w-3 mr-1" />
                    批量导出
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {/* 搜索和筛选区域 */}
              <div className="flex items-center gap-3 mb-4">
                <div className="relative flex-1 max-w-80">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="搜索文件名称/编号..."
                    value={constructionSearchQuery}
                    onChange={(e) => setConstructionSearchQuery(e.target.value)}
                    className="pl-10 h-8 text-sm"
                  />
                </div>
                
                <Select value={constructionFileType} onValueChange={setConstructionFileType}>
                  <SelectTrigger className="w-36 h-8 text-sm">
                    <SelectValue placeholder="文件类型" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部类型</SelectItem>
                    <SelectItem value="装修合同">装修合同</SelectItem>
                    <SelectItem value="施工图纸">施工图纸</SelectItem>
                    <SelectItem value="验收报告">验收报告</SelectItem>
                    <SelectItem value="安装合同">安装合同</SelectItem>
                  </SelectContent>
                </Select>

                <Button 
                  variant="outline" 
                  size="sm" 
                  className="h-8 text-sm"
                  onClick={() => {
                    setConstructionSearchQuery("");
                    setConstructionFileType("all");
                  }}
                >
                  <Filter className="h-3 w-3 mr-1" />
                  清除筛选
                </Button>
              </div>

              {/* 文件列表表格 */}
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-sm">文件ID</TableHead>
                      <TableHead className="text-sm">文件名称</TableHead>
                      <TableHead className="text-sm">文件类型</TableHead>
                      <TableHead className="text-sm">更新日期</TableHead>
                      <TableHead className="text-sm">状态</TableHead>
                      <TableHead className="text-sm">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredConstructionData.map((file) => (
                      <TableRow key={file.id}>
                        <TableCell className="text-sm">{file.id}</TableCell>
                        <TableCell className="text-sm font-medium">{file.name}</TableCell>
                        <TableCell className="text-sm">{file.type}</TableCell>
                        <TableCell className="text-sm">{file.date}</TableCell>
                        <TableCell className="text-sm">
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            file.status === "生效中" 
                              ? "bg-green-100 text-green-800" 
                              : "bg-gray-100 text-gray-800"
                          }`}>
                            {file.status}
                          </span>
                        </TableCell>
                        <TableCell className="text-sm">
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 p-0"
                              title="下载"
                            >
                              <Download className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="link"
                              size="sm"
                              className="h-6 text-xs p-0"
                            >
                              查看
                            </Button>
                            <Button
                              variant="link"
                              size="sm"
                              className="h-6 text-xs p-0"
                            >
                              编辑
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                
                {filteredConstructionData.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground text-sm">
                    {constructionSearchQuery || (constructionFileType && constructionFileType !== "all") ? "没有找到匹配的文件" : "暂无项目施工文件数据"}
                  </div>
                )}
              </div>

              <TablePagination
                total={constructionTotalItems}
                currentPage={constructionCurrentPage}
                pageSize={pageSize}
                onPageChange={setConstructionCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}