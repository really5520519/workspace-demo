import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { TablePagination } from "../ui/table-pagination";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { 
  Plus, 
  Search, 
  FileText, 
  Building, 
  Hammer,
  CheckCircle, 
  Clock,
  Play,
  Package,
  CalendarDays,
  Users,
  ArrowLeft,
  Edit,
  Trash2,
  Filter,
  TrendingUp,
  Activity
} from "lucide-react";

// 统计卡片数据
const statisticsData = [
  {
    title: "历史项目合计",
    value: "186",
    unit: "个",
    icon: FileText,
    color: "text-blue-600"
  },
  {
    title: "未开工",
    value: "28",
    unit: "个",
    icon: Clock,
    color: "text-orange-600"
  },
  {
    title: "已交付",
    value: "98",
    unit: "个",
    icon: CheckCircle,
    color: "text-green-600"
  },
  {
    title: "已搬入",
    value: "60",
    unit: "个",
    icon: Building,
    color: "text-teal-600"
  }
];

// 人力统计数据
const manpowerStats = [
  {
    title: "项目数量统计",
    value: "186",
    unit: "个",
    icon: Building,
    color: "text-blue-600"
  },
  {
    title: "人员跟进统计",
    value: "42",
    unit: "人",
    icon: Users,
    color: "text-green-600"
  },
  {
    title: "总人天统计",
    value: "3,280",
    unit: "天",
    icon: Activity,
    color: "text-purple-600"
  }
];

// 甘特图数据
const ganttData = [
  {
    id: "PJ-2024-001",
    name: "北京办公室装修项目",
    phase: "立项",
    startDate: "2024-01-15",
    endDate: "2024-01-25",
    progress: 100,
    status: "已完成"
  },
  {
    id: "PJ-2024-002", 
    name: "上海分部改造项目",
    phase: "采购",
    startDate: "2024-02-01",
    endDate: "2024-02-15",
    progress: 75,
    status: "进行中"
  },
  {
    id: "PJ-2024-003",
    name: "广州办公室退租还原",
    phase: "合同",
    startDate: "2024-02-20",
    endDate: "2024-03-05",
    progress: 50,
    status: "进行中"
  }
];

// 项目列表数据
const projectData = [
  {
    projectId: "PJ-2024-001",
    demandId: "DM-2024-001",
    projectType: "新交付",
    status: "已交付",
    projectName: "北京办公室15-16层装修项目",
    phase: "竣工验收",
    area: "华北",
    workplace: "北京时尚万科大厦",
    building: "A座",
    floor: "15-16层",
    demandDepartment: "技术部",
    demandSubmitter: "张三",
    demandSubmitDate: "2024-01-10",
    csEmailDate: "2024-01-12",
    baselineDeliveryDate: "2024-03-15",
    plannedDeliveryDate: "2024-03-10",
    plannedDays: 60,
    actualDays: 55,
    projectDescription: "办公室装修改造项目",
    attachment: "设计图纸.pdf",
    projectManager: "王经理",
    projectEngineer: "李工程师",
    costManager: "赵成本",
    designManager: "钱设计",
    technicalManager: "孙技术",
    complianceManager: "周合规",
    procurementManager: "吴采购",
    managementCompanyStaff: "郑管理",
    costConsultant: "冯顾问",
    supplierStaff: "陈供应商",
    applicant: "张三",
    createTime: "2024-01-10 09:00",
    updateTime: "2024-03-10 17:30"
  },
  {
    projectId: "PJ-2024-002",
    demandId: "DM-2024-002",
    projectType: "Day2改造",
    status: "未开工",
    projectName: "上海分部会议室改造",
    phase: "立项",
    area: "华东",
    workplace: "上海陆家嘴中心",
    building: "B座",
    floor: "20层",
    demandDepartment: "市场部",
    demandSubmitter: "李四",
    demandSubmitDate: "2024-02-01",
    csEmailDate: "2024-02-03",
    baselineDeliveryDate: "2024-04-30",
    plannedDeliveryDate: "2024-04-25",
    plannedDays: 45,
    actualDays: 0,
    projectDescription: "会议室装修升级",
    attachment: "需求文档.docx",
    projectManager: "刘经理",
    projectEngineer: "王工程师",
    costManager: "张成本",
    designManager: "李设计",
    technicalManager: "赵技术",
    complianceManager: "钱合规",
    procurementManager: "孙采购",
    managementCompanyStaff: "周管理",
    costConsultant: "吴顾问",
    supplierStaff: "郑供应商",
    applicant: "李四",
    createTime: "2024-02-01 10:30",
    updateTime: "2024-02-03 14:20"
  }
];

interface ConstructionManagementProps {
  onNavigate?: (targetId: string, data?: any) => void;
}

// 项目详情组件
function ProjectDetailsView({ projectId, onBack }: { projectId: string; onBack: () => void }) {
  const project = projectData.find(p => p.projectId === projectId);
  
  if (!project) {
    return (
      <div className="p-6 text-center">
        <p>项目不存在</p>
      </div>
    );
  }

  const [activeDetailTab, setActiveDetailTab] = useState("establishment");

  return (
    <div className="space-y-4 p-4 max-w-[1300px] mx-auto">
      {/* 返回按钮和标题 */}
      <div className="flex items-center gap-3">
        <Button variant="outline" size="sm" onClick={onBack} className="h-7">
          <ArrowLeft className="h-3 w-3 mr-1" />
          返回
        </Button>
        <h1 className="text-lg font-medium">{project.projectName}</h1>
      </div>

      {/* 基本信息区域 */}
      <div className="grid grid-cols-2 gap-6">
        {/* 基本信息 */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">基本信息</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div><span className="text-gray-600">房产分区：</span>{project.area}</div>
              <div><span className="text-gray-600">城市：</span>{project.workplace}</div>
              <div><span className="text-gray-600">工区名称：</span>{project.workplace}</div>
              <div><span className="text-gray-600">楼栋：</span>{project.building}</div>
              <div><span className="text-gray-600">楼层：</span>{project.floor}</div>
              <div><span className="text-gray-600">项目类型：</span>{project.projectType}</div>
              <div><span className="text-gray-600">项目阶段：</span>{project.phase}</div>
            </div>
          </CardContent>
        </Card>

        {/* 人员信息 */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">人员信息</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-xs">
            <div className="grid grid-cols-2 gap-2">
              <div><span className="text-gray-600">项目经理：</span>{project.projectManager}</div>
              <div><span className="text-gray-600">项目工程师：</span>{project.projectEngineer}</div>
              <div><span className="text-gray-600">成本经理：</span>{project.costManager}</div>
              <div><span className="text-gray-600">设计经理：</span>{project.designManager}</div>
              <div><span className="text-gray-600">技术经理：</span>{project.technicalManager}</div>
              <div><span className="text-gray-600">合规经理：</span>{project.complianceManager}</div>
              <div><span className="text-gray-600">采购经理：</span>{project.procurementManager}</div>
              <div><span className="text-gray-600">管理公司：</span>{project.managementCompanyStaff}</div>
            </div>
          </CardContent>
        </Card>

        {/* 时间信息 */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">时间信息</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-xs">
            <div className="grid grid-cols-2 gap-2">
              <div><span className="text-gray-600">需求提交日期：</span>{project.demandSubmitDate}</div>
              <div><span className="text-gray-600">CS邮件日期：</span>{project.csEmailDate}</div>
              <div><span className="text-gray-600">基线交付日期：</span>{project.baselineDeliveryDate}</div>
              <div><span className="text-gray-600">计划交付日期：</span>{project.plannedDeliveryDate}</div>
              <div><span className="text-gray-600">计划天数：</span>{project.plannedDays}天</div>
              <div><span className="text-gray-600">实际天数：</span>{project.actualDays}天</div>
            </div>
          </CardContent>
        </Card>

        {/* 需求信息 */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">需求信息</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-xs">
            <div className="grid grid-cols-2 gap-2">
              <div><span className="text-gray-600">需求部门：</span>{project.demandDepartment}</div>
              <div><span className="text-gray-600">需求提交人：</span>{project.demandSubmitter}</div>
              <div><span className="text-gray-600">需求性质：</span>常规需求</div>
              <div><span className="text-gray-600">资源类型：</span>办公空间</div>
              <div><span className="text-gray-600">项目描述：</span>{project.projectDescription}</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 详细标签页 */}
      <Card>
        <CardContent className="p-0">
          <Tabs value={activeDetailTab} onValueChange={setActiveDetailTab} className="w-full">
            <TabsList className="justify-start w-auto bg-gray-50 rounded-none border-b p-1">
              <TabsTrigger value="establishment" className="text-xs px-2 py-1">立项</TabsTrigger>
              <TabsTrigger value="rfi" className="text-xs px-2 py-1">信息需求（RFI）</TabsTrigger>
              <TabsTrigger value="vo" className="text-xs px-2 py-1">变更金额（VO）</TabsTrigger>
              <TabsTrigger value="procurement" className="text-xs px-2 py-1">采购&付款申请</TabsTrigger>
              <TabsTrigger value="contract" className="text-xs px-2 py-1">项目合同</TabsTrigger>
              <TabsTrigger value="design" className="text-xs px-2 py-1">设计审核</TabsTrigger>
              <TabsTrigger value="acceptance" className="text-xs px-2 py-1">竣工验收</TabsTrigger>
              <TabsTrigger value="settlement" className="text-xs px-2 py-1">结算证书</TabsTrigger>
              <TabsTrigger value="dispatch" className="text-xs px-2 py-1">框采派单</TabsTrigger>
              <TabsTrigger value="history" className="text-xs px-2 py-1">历史关联项目</TabsTrigger>
            </TabsList>
            
            {[
              "establishment", "rfi", "vo", "procurement", "contract", 
              "design", "acceptance", "settlement", "dispatch", "history"
            ].map((tab) => (
              <TabsContent key={tab} value={tab} className="p-6">
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 bg-muted rounded-lg flex items-center justify-center mx-auto">
                    <FileText className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="font-medium">{tab === "history" ? "历史关联项目" : "功能开发中"}</p>
                    <p className="text-muted-foreground">此功能正在开发中，敬请期待</p>
                  </div>
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}

export function ConstructionManagementContent({ onNavigate }: ConstructionManagementProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [activeTab, setActiveTab] = useState("new-delivery");
  const [showProgressManagement, setShowProgressManagement] = useState(false);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState("all");
  const [ganttTab, setGanttTab] = useState("establishment");
  const totalItems = 156; // 模拟总条数

  // 如果显示项目详情页
  if (selectedProjectId) {
    return (
      <ProjectDetailsView 
        projectId={selectedProjectId} 
        onBack={() => setSelectedProjectId(null)} 
      />
    );
  }

  return (
    <div className="space-y-4 max-w-[1300px] mx-auto py-[5px] p-[0px]">
      {/* 页面标题 */}
      <div className="flex items-center gap-3">
        <h1 className="text-lg font-medium">项目施工管理</h1>
        <Button 
          variant="outline" 
          size="sm" 
          className="h-7 text-xs bg-blue-50 text-blue-600 border-blue-200 hover:bg-blue-100"
          onClick={() => setShowProgressManagement(!showProgressManagement)}
        >
          <CalendarDays className="h-3 w-3 mr-1" />
          进度管理
        </Button>
      </div>

      {/* 进度管理区域 */}
      {showProgressManagement && (
        <Card className="border-blue-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-blue-600">项目进度管理</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* 项目进度甘特图 */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium">项目进度甘特图</h3>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-600">状态筛选：</span>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-32 h-7 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">全部</SelectItem>
                      <SelectItem value="已交付">已交付</SelectItem>
                      <SelectItem value="未交付">未交付</SelectItem>
                      <SelectItem value="未进场">未进场</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* 甘特图标签页 */}
              <Tabs value={ganttTab} onValueChange={setGanttTab} className="w-full">
                <TabsList className="justify-start w-auto p-1">
                  <TabsTrigger value="establishment" className="text-xs px-3 py-1.5">立项</TabsTrigger>
                  <TabsTrigger value="procurement" className="text-xs px-3 py-1.5">采购</TabsTrigger>
                  <TabsTrigger value="contract" className="text-xs px-3 py-1.5">合同</TabsTrigger>
                  <TabsTrigger value="acceptance" className="text-xs px-3 py-1.5">竣工验收</TabsTrigger>
                  <TabsTrigger value="settlement" className="text-xs px-3 py-1.5">结算</TabsTrigger>
                </TabsList>
                
                <TabsContent value={ganttTab} className="mt-4">
                  <div className="border rounded-lg">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-50">
                          <TableHead className="text-xs font-medium text-gray-700 h-10">项目ID</TableHead>
                          <TableHead className="text-xs font-medium text-gray-700 h-10">项目名称</TableHead>
                          <TableHead className="text-xs font-medium text-gray-700 h-10">阶段</TableHead>
                          <TableHead className="text-xs font-medium text-gray-700 h-10">开始日期</TableHead>
                          <TableHead className="text-xs font-medium text-gray-700 h-10">结束日期</TableHead>
                          <TableHead className="text-xs font-medium text-gray-700 h-10">进度</TableHead>
                          <TableHead className="text-xs font-medium text-gray-700 h-10">状态</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {ganttData.map((item) => (
                          <TableRow key={item.id} className="hover:bg-gray-50">
                            <TableCell className="text-xs text-gray-900">{item.id}</TableCell>
                            <TableCell className="text-xs text-gray-900">{item.name}</TableCell>
                            <TableCell className="text-xs text-gray-900">{item.phase}</TableCell>
                            <TableCell className="text-xs text-gray-900">{item.startDate}</TableCell>
                            <TableCell className="text-xs text-gray-900">{item.endDate}</TableCell>
                            <TableCell className="text-xs">
                              <div className="flex items-center gap-2">
                                <div className="w-20 bg-gray-200 rounded-full h-2">
                                  <div 
                                    className="h-2 rounded-full bg-blue-500"
                                    style={{ width: `${item.progress}%` }}
                                  ></div>
                                </div>
                                <span className="text-xs">{item.progress}%</span>
                              </div>
                            </TableCell>
                            <TableCell className="text-xs">
                              <Badge 
                                variant="secondary" 
                                className={`text-xs border ${
                                  item.status === "已完成" 
                                    ? "bg-green-50 text-green-700 border-green-200" 
                                    : "bg-blue-50 text-blue-700 border-blue-200"
                                }`}
                              >
                                {item.status}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            {/* 项目人力看板 */}
            <div className="space-y-4">
              <h3 className="text-sm font-medium">项目人力看板</h3>
              <div className="grid grid-cols-3 gap-4">
                {manpowerStats.map((item, index) => {
                  const Icon = item.icon;
                  return (
                    <Card key={index} className="bg-white border border-gray-200">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <Icon className={`h-5 w-5 ${item.color}`} />
                          </div>
                          <div>
                            <p className="text-xs text-gray-600">{item.title}</p>
                            <p className="text-lg font-medium text-gray-900">{item.value}<span className="text-xs font-normal ml-1">{item.unit}</span></p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* 统计区 */}
      <div className="grid grid-cols-4 gap-4">
        {statisticsData.map((item, index) => {
          const Icon = item.icon;
          return (
            <Card key={index} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Icon className={`h-5 w-5 ${item.color}`} />
                  </div>
                  <div>
                    <p className="text-xs text-gray-600">{item.title}</p>
                    <p className="text-lg font-medium text-gray-900">{item.value}<span className="text-xs font-normal ml-1">{item.unit}</span></p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* 项目列表区域 */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-medium">项目列表</CardTitle>
            <div className="flex items-center gap-3">
              <Button size="sm" className="h-7 text-xs bg-blue-600 hover:bg-blue-700">
                <Plus className="h-3 w-3 mr-1" />
                新建装修项目
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="mt-[-21px] mr-[0px] mb-[0px] ml-[0px]">
          {/* 横向标签页 */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="w-fit h-auto p-0.5 gap-0.5">
              <TabsTrigger value="new-delivery" className="text-xs px-2.5 py-1">新交付</TabsTrigger>
              <TabsTrigger value="day2-renovation" className="text-xs px-2.5 py-1">Day2维改</TabsTrigger>
              <TabsTrigger value="lease-return" className="text-xs px-2.5 py-1">退租还原</TabsTrigger>
              <TabsTrigger value="other-renovation" className="text-xs px-2.5 py-1">其他改造</TabsTrigger>
            </TabsList>

            {/* 项目列表表格 */}
            <TabsContent value={activeTab} className="mt-4">
              <div className="border rounded-lg">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-gray-50">
                        <TableHead className="text-xs font-medium text-gray-700 h-10">项目ID</TableHead>
                        <TableHead className="text-xs font-medium text-gray-700 h-10">需求ID</TableHead>
                        <TableHead className="text-xs font-medium text-gray-700 h-10">项目类型</TableHead>
                        <TableHead className="text-xs font-medium text-gray-700 h-10">状态</TableHead>
                        <TableHead className="text-xs font-medium text-gray-700 h-10">项目名称</TableHead>
                        <TableHead className="text-xs font-medium text-gray-700 h-10">项目阶段</TableHead>
                        <TableHead className="text-xs font-medium text-gray-700 h-10">区域</TableHead>
                        <TableHead className="text-xs font-medium text-gray-700 h-10">职场</TableHead>
                        <TableHead className="text-xs font-medium text-gray-700 h-10">楼号</TableHead>
                        <TableHead className="text-xs font-medium text-gray-700 h-10">楼层</TableHead>
                        <TableHead className="text-xs font-medium text-gray-700 h-10">需求业务部门</TableHead>
                        <TableHead className="text-xs font-medium text-gray-700 h-10">需求提交人</TableHead>
                        <TableHead className="text-xs font-medium text-gray-700 h-10">计划交付日期</TableHead>
                        <TableHead className="text-xs font-medium text-gray-700 h-10">计划天数</TableHead>
                        <TableHead className="text-xs font-medium text-gray-700 h-10">实际天数</TableHead>
                        <TableHead className="text-xs font-medium text-gray-700 h-10">项目经理</TableHead>
                        <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {projectData.map((item) => (
                        <TableRow key={item.projectId} className="hover:bg-gray-50">
                          <TableCell className="text-xs text-gray-900">{item.projectId}</TableCell>
                          <TableCell className="text-xs text-gray-900">{item.demandId}</TableCell>
                          <TableCell className="text-xs text-gray-900">{item.projectType}</TableCell>
                          <TableCell className="text-xs">
                            <Badge 
                              variant="secondary" 
                              className={`text-xs border ${
                                item.status === "已交付" 
                                  ? "bg-green-50 text-green-700 border-green-200" 
                                  : item.status === "未开工"
                                  ? "bg-orange-50 text-orange-700 border-orange-200" 
                                  : "bg-blue-50 text-blue-700 border-blue-200"
                              }`}
                            >
                              {item.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-xs">
                            <button 
                              className="text-blue-600 hover:text-blue-800 hover:underline font-medium"
                              onClick={() => setSelectedProjectId(item.projectId)}
                            >
                              {item.projectName}
                            </button>
                          </TableCell>
                          <TableCell className="text-xs text-gray-900">{item.phase}</TableCell>
                          <TableCell className="text-xs text-gray-900">{item.area}</TableCell>
                          <TableCell className="text-xs text-gray-900">{item.workplace}</TableCell>
                          <TableCell className="text-xs text-gray-900">{item.building}</TableCell>
                          <TableCell className="text-xs text-gray-900">{item.floor}</TableCell>
                          <TableCell className="text-xs text-gray-900">{item.demandDepartment}</TableCell>
                          <TableCell className="text-xs text-gray-900">{item.demandSubmitter}</TableCell>
                          <TableCell className="text-xs text-gray-900">{item.plannedDeliveryDate}</TableCell>
                          <TableCell className="text-xs text-gray-900">{item.plannedDays}</TableCell>
                          <TableCell className="text-xs text-gray-900">{item.actualDays}</TableCell>
                          <TableCell className="text-xs text-gray-900">{item.projectManager}</TableCell>
                          <TableCell className="text-xs">
                            <div className="flex items-center gap-1">
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="h-6 text-xs text-blue-600 hover:text-blue-700 hover:bg-blue-50 p-1"
                              >
                                <Edit className="h-3 w-3" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="h-6 text-xs text-red-600 hover:text-red-700 hover:bg-red-50 p-1"
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>

              <TablePagination
                total={totalItems}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}