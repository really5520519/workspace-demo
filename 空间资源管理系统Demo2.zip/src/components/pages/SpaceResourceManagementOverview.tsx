import { Card, CardContent } from "../ui/card";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Users, Building2, MapPin, Archive, BarChart2, BarChart3, FolderOpen } from "lucide-react";

export function SpaceResourceManagementOverviewContent() {
  const handleNavigate = (targetId: string) => {
    // 这里可以添加导航逻辑，目前暂时留空
    console.log('Navigate to:', targetId);
  };

  return (
    <div className="space-y-8">
      {/* 页面标题区域 */}
      <div className="text-center space-y-2">
        <h1 className="text-2xl font-bold text-gray-900">空间资源管理系统</h1>
        <p className="text-sm text-gray-600">统一管理空间资源、提升办公效率</p>
      </div>

      {/* 功能卡片区域 */}
      <div className="grid grid-cols-2 gap-8">
        {/* 左侧功能卡片 */}
        <div className="space-y-4">
          {/* 用户端 */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium text-gray-900">用户端</h3>
                  </div>
                  <p className="text-xs text-gray-600 mb-3">
                    为员工和部门提供空间服务管理
                  </p>
                  <Button 
                    size="sm" 
                    className="h-7 text-xs bg-blue-600 hover:bg-blue-700"
                    onClick={() => handleNavigate('user-side')}
                  >
                    进入
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 空间服务 */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Building2 className="h-6 w-6 text-blue-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium text-gray-900">空间服务</h3>
                    <Badge variant="outline" className="text-xs">配置</Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-3">
                    查看工位信息、设备服务的空间服务
                  </p>
                  <Button 
                    size="sm" 
                    className="h-7 text-xs bg-blue-600 hover:bg-blue-700"
                    onClick={() => handleNavigate('space-service')}
                  >
                    进入
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 工位绑定 */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <MapPin className="h-6 w-6 text-blue-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium text-gray-900">工位绑定</h3>
                    <Badge variant="outline" className="text-xs">配置</Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-3">
                    管理个人工位绑定和历史记录
                  </p>
                  <Button 
                    size="sm" 
                    className="h-7 text-xs bg-blue-600 hover:bg-blue-700"
                    onClick={() => handleNavigate('seat-binding')}
                  >
                    进入
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 空间资源服务 */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Archive className="h-6 w-6 text-blue-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium text-gray-900">空间资源服务</h3>
                    <Badge variant="outline" className="text-xs">配置</Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-3">
                    查看和记录房屋资料和入驻信息
                  </p>
                  <Button 
                    size="sm" 
                    className="h-7 text-xs bg-blue-600 hover:bg-blue-700"
                    onClick={() => handleNavigate('space-resource-service')}
                  >
                    进入
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 右侧功能卡片 */}
        <div className="space-y-4">
          {/* 管理端 */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <BarChart2 className="h-6 w-6 text-green-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium text-gray-900">管理端</h3>
                  </div>
                  <p className="text-xs text-gray-600 mb-3">
                    为管理人员提供空间资源管理工具
                  </p>
                  <Button 
                    size="sm" 
                    variant="outline"
                    className="h-7 text-xs"
                    onClick={() => handleNavigate('admin-side')}
                  >
                    进入
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 经营分析 */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <BarChart3 className="h-6 w-6 text-green-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium text-gray-900">经营分析</h3>
                    <Badge className="text-xs bg-green-100 text-green-800">经营管理</Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-3">
                    提供费用分析和决策支持数据
                  </p>
                  <Button 
                    size="sm" 
                    variant="outline"
                    className="h-7 text-xs"
                    onClick={() => handleNavigate('business-analysis')}
                  >
                    进入
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 项目管理 */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <FolderOpen className="h-6 w-6 text-green-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium text-gray-900">项目管理</h3>
                    <Badge className="text-xs bg-green-100 text-green-800">运营管理</Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-3">
                    项目管理、需求、分配等功能模块
                  </p>
                  <Button 
                    size="sm" 
                    variant="outline"
                    className="h-7 text-xs"
                    onClick={() => handleNavigate('project-management')}
                  >
                    进入
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 工区管理 */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Building2 className="h-6 w-6 text-green-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium text-gray-900">工区管理</h3>
                    <Badge className="text-xs bg-green-100 text-green-800">空间管理</Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-3">
                    工区信息、资源配置管理
                  </p>
                  <Button 
                    size="sm" 
                    variant="outline"
                    className="h-7 text-xs"
                    onClick={() => handleNavigate('workplace-management')}
                  >
                    进入
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}