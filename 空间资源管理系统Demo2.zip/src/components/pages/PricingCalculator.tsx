import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Badge } from "../ui/badge";
import { ArrowLeft, Calculator, Download, Trash2, Plus } from "lucide-react";

interface PricingCalculatorProps {
  onNavigate?: (page: string, data?: any) => void;
}

interface ConfigItem {
  id: string;
  productName: string;
  productType: string;
  quantity: number;
  unitPrice: number;
  unit: string;
  duration: number;
  durationType: string;
  discountRate: number;
  totalAmount: number;
}

export function PricingCalculatorContent({ onNavigate }: PricingCalculatorProps) {
  const [configItems, setConfigItems] = useState<ConfigItem[]>([
    {
      id: "1",
      productName: "普通挡板工位",
      productType: "工位",
      quantity: 50,
      unitPrice: 180,
      unit: "元/天/个",
      duration: 30,
      durationType: "天",
      discountRate: 0,
      totalAmount: 270000
    },
    {
      id: "2",
      productName: "高级会议室",
      productType: "空间",
      quantity: 5,
      unitPrice: 300,
      unit: "元/小时",
      duration: 100,
      durationType: "小时",
      discountRate: 10,
      totalAmount: 135000
    }
  ]);

  const [newItem, setNewItem] = useState<Partial<ConfigItem>>({
    productName: "",
    productType: "工位",
    quantity: 1,
    unitPrice: 0,
    unit: "元/天/个",
    duration: 1,
    durationType: "天",
    discountRate: 0
  });

  const handleBack = () => {
    onNavigate?.("pricing-management");
  };

  const calculateTotal = (item: Partial<ConfigItem>) => {
    const { quantity = 0, unitPrice = 0, duration = 0, discountRate = 0 } = item;
    const subtotal = quantity * unitPrice * duration;
    const discount = subtotal * (discountRate / 100);
    return subtotal - discount;
  };

  const updateConfigItem = (id: string, field: keyof ConfigItem, value: any) => {
    setConfigItems(prev => prev.map(item => {
      if (item.id === id) {
        const updated = { ...item, [field]: value };
        updated.totalAmount = calculateTotal(updated);
        return updated;
      }
      return item;
    }));
  };

  const addConfigItem = () => {
    if (!newItem.productName) return;
    
    const id = (configItems.length + 1).toString();
    const totalAmount = calculateTotal(newItem);
    
    setConfigItems(prev => [...prev, {
      id,
      ...newItem as ConfigItem,
      totalAmount
    }]);
    
    setNewItem({
      productName: "",
      productType: "工位",
      quantity: 1,
      unitPrice: 0,
      unit: "元/天/个",
      duration: 1,
      durationType: "天",
      discountRate: 0
    });
  };

  const removeConfigItem = (id: string) => {
    setConfigItems(prev => prev.filter(item => item.id !== id));
  };

  const totalAmount = configItems.reduce((sum, item) => sum + item.totalAmount, 0);
  const totalDiscount = configItems.reduce((sum, item) => {
    const subtotal = item.quantity * item.unitPrice * item.duration;
    return sum + (subtotal * (item.discountRate / 100));
  }, 0);
  const subtotalBeforeDiscount = totalAmount + totalDiscount;

  return (
    <div className="space-y-4" style={{ maxWidth: '1300px', margin: '0 auto' }}>
      {/* 页面标题和操作按钮 */}
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleBack}
            className="h-8 px-2"
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            返回
          </Button>
          <div>
            <h1>定价计算器</h1>
            <p className="text-muted-foreground">配置商品数量和参数，自动计算报价</p>
          </div>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700 text-white">
          <Download className="h-4 w-4 mr-1" />
          导出报价单
        </Button>
      </div>

      {/* 定价配置器 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            定价配置器
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* 新增配置项 */}
          <div className="space-y-4 p-4 bg-muted/30 rounded-lg">
            <h3>添加配置项</h3>
            <div className="grid grid-cols-5 gap-4">
              <div className="space-y-2">
                <Label>商品名称</Label>
                <Select 
                  value={newItem.productName} 
                  onValueChange={(value) => setNewItem(prev => ({ ...prev, productName: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="选择商品" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="普通挡板工位">普通挡板工位</SelectItem>
                    <SelectItem value="高级会议室">高级会议室</SelectItem>
                    <SelectItem value="Day2改造服务">Day2改造服务</SelectItem>
                    <SelectItem value="人力外包服务">人力外包服务</SelectItem>
                    <SelectItem value="茶水间">茶水间</SelectItem>
                    <SelectItem value="打印室">打印室</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>商品类型</Label>
                <Select 
                  value={newItem.productType} 
                  onValueChange={(value) => setNewItem(prev => ({ ...prev, productType: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="工位">工位</SelectItem>
                    <SelectItem value="空间">空间</SelectItem>
                    <SelectItem value="运营">运营</SelectItem>
                    <SelectItem value="服务">服务</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>数量</Label>
                <Input
                  type="number"
                  min="1"
                  value={newItem.quantity || ""}
                  onChange={(e) => setNewItem(prev => ({ ...prev, quantity: Number(e.target.value) }))}
                />
              </div>
              <div className="space-y-2">
                <Label>单价</Label>
                <Input
                  type="number"
                  min="0"
                  step="0.01"
                  value={newItem.unitPrice || ""}
                  onChange={(e) => setNewItem(prev => ({ ...prev, unitPrice: Number(e.target.value) }))}
                  className="text-blue-600"
                />
              </div>
              <div className="space-y-2">
                <Label>单位</Label>
                <Select 
                  value={newItem.unit} 
                  onValueChange={(value) => setNewItem(prev => ({ ...prev, unit: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="元/天/个">元/天/个</SelectItem>
                    <SelectItem value="元/小时">元/小时</SelectItem>
                    <SelectItem value="元/月">元/月</SelectItem>
                    <SelectItem value="元/次">元/次</SelectItem>
                    <SelectItem value="元/项目">元/项目</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label>时长</Label>
                <Input
                  type="number"
                  min="1"
                  value={newItem.duration || ""}
                  onChange={(e) => setNewItem(prev => ({ ...prev, duration: Number(e.target.value) }))}
                />
              </div>
              <div className="space-y-2">
                <Label>时长单位</Label>
                <Select 
                  value={newItem.durationType} 
                  onValueChange={(value) => setNewItem(prev => ({ ...prev, durationType: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="天">天</SelectItem>
                    <SelectItem value="小时">小时</SelectItem>
                    <SelectItem value="月">月</SelectItem>
                    <SelectItem value="次">次</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>折扣率(%)</Label>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={newItem.discountRate || ""}
                  onChange={(e) => setNewItem(prev => ({ ...prev, discountRate: Number(e.target.value) }))}
                />
              </div>
              <div className="space-y-2 flex items-end">
                <Button onClick={addConfigItem} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                  <Plus className="h-4 w-4 mr-1" />
                  添加
                </Button>
              </div>
            </div>
            <div className="pt-2 border-t">
              <div className="text-right">
                <span>预计金额: </span>
                <span className="text-blue-600">¥{calculateTotal(newItem).toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* 当前配置项列表 */}
          <div className="space-y-4">
            <h3>当前配置项</h3>
            <div className="border rounded-lg overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead className="min-w-[150px]">商品名称</TableHead>
                    <TableHead className="min-w-[100px]">商品类型</TableHead>
                    <TableHead className="min-w-[80px]">数量</TableHead>
                    <TableHead className="min-w-[100px]">单价</TableHead>
                    <TableHead className="min-w-[120px]">单位</TableHead>
                    <TableHead className="min-w-[80px]">时长</TableHead>
                    <TableHead className="min-w-[100px]">时长单位</TableHead>
                    <TableHead className="min-w-[100px]">折扣率</TableHead>
                    <TableHead className="min-w-[120px]">总金额</TableHead>
                    <TableHead className="min-w-[80px]">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {configItems.map((item) => (
                    <TableRow key={item.id} className="hover:bg-muted/30">
                      <TableCell>
                        <Input
                          value={item.productName}
                          onChange={(e) => updateConfigItem(item.id, 'productName', e.target.value)}
                          className="border-0 bg-transparent p-0"
                        />
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{item.productType}</Badge>
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) => updateConfigItem(item.id, 'quantity', Number(e.target.value))}
                          className="w-20"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          min="0"
                          step="0.01"
                          value={item.unitPrice}
                          onChange={(e) => updateConfigItem(item.id, 'unitPrice', Number(e.target.value))}
                          className="w-24 text-blue-600"
                        />
                      </TableCell>
                      <TableCell>{item.unit}</TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          min="1"
                          value={item.duration}
                          onChange={(e) => updateConfigItem(item.id, 'duration', Number(e.target.value))}
                          className="w-20"
                        />
                      </TableCell>
                      <TableCell>{item.durationType}</TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          min="0"
                          max="100"
                          step="0.1"
                          value={item.discountRate}
                          onChange={(e) => updateConfigItem(item.id, 'discountRate', Number(e.target.value))}
                          className="w-20"
                        />%
                      </TableCell>
                      <TableCell className="text-blue-600">¥{item.totalAmount.toLocaleString()}</TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0 text-red-600 hover:text-red-800 hover:bg-red-50"
                          onClick={() => removeConfigItem(item.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 报价汇总表 */}
      <Card>
        <CardHeader>
          <CardTitle>报价汇总表</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* 汇总统计 */}
            <div className="grid grid-cols-4 gap-4 p-4 bg-muted/30 rounded-lg">
              <div className="text-center">
                <div className="text-2xl">¥{subtotalBeforeDiscount.toLocaleString()}</div>
                <div className="text-muted-foreground">小计金额</div>
              </div>
              <div className="text-center">
                <div className="text-2xl text-red-600">-¥{totalDiscount.toLocaleString()}</div>
                <div className="text-muted-foreground">优惠金额</div>
              </div>
              <div className="text-center">
                <div className="text-2xl">{configItems.length}</div>
                <div className="text-muted-foreground">配置项数</div>
              </div>
              <div className="text-center">
                <div className="text-3xl text-blue-600">¥{totalAmount.toLocaleString()}</div>
                <div className="text-muted-foreground">合计金额</div>
              </div>
            </div>

            {/* 详细汇总表 */}
            <div className="border rounded-lg overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead>序号</TableHead>
                    <TableHead>商品名称</TableHead>
                    <TableHead>商品类型</TableHead>
                    <TableHead>数量</TableHead>
                    <TableHead>单价</TableHead>
                    <TableHead>时长</TableHead>
                    <TableHead>小计</TableHead>
                    <TableHead>折扣率</TableHead>
                    <TableHead>优惠金额</TableHead>
                    <TableHead>总金额</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {configItems.map((item, index) => {
                    const subtotal = item.quantity * item.unitPrice * item.duration;
                    const discount = subtotal * (item.discountRate / 100);
                    return (
                      <TableRow key={item.id} className="hover:bg-muted/30">
                        <TableCell>{index + 1}</TableCell>
                        <TableCell>{item.productName}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{item.productType}</Badge>
                        </TableCell>
                        <TableCell>{item.quantity} 个</TableCell>
                        <TableCell className="text-blue-600">¥{item.unitPrice.toLocaleString()}</TableCell>
                        <TableCell>{item.duration} {item.durationType}</TableCell>
                        <TableCell>¥{subtotal.toLocaleString()}</TableCell>
                        <TableCell>{item.discountRate}%</TableCell>
                        <TableCell className="text-red-600">-¥{discount.toLocaleString()}</TableCell>
                        <TableCell className="text-blue-600">¥{item.totalAmount.toLocaleString()}</TableCell>
                      </TableRow>
                    );
                  })}
                  {configItems.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={10} className="text-center text-muted-foreground py-8">
                        ��无配置项，请在上方添加商品配置
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>

            {/* 最终汇总 */}
            <div className="flex justify-end">
              <div className="w-80 space-y-2 p-4 border rounded-lg bg-blue-50">
                <div className="flex justify-between">
                  <span>小计金额:</span>
                  <span>¥{subtotalBeforeDiscount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-red-600">
                  <span>优惠金额:</span>
                  <span>-¥{totalDiscount.toLocaleString()}</span>
                </div>
                <div className="border-t pt-2 flex justify-between text-blue-600">
                  <span>合计金额:</span>
                  <span>¥{totalAmount.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}