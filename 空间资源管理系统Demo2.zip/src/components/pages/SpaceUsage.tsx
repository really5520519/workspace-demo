import { useState, Fragment } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { TablePagination } from "../ui/table-pagination";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { ChevronDown, ChevronRight } from "lucide-react";

export function SpaceUsageContent() {
  const [activeTab, setActiveTab] = useState("by-city");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const totalItems = 25; // 模拟总条数

  // 切换行展开状态
  const toggleRowExpansion = (rowId: string) => {
    const newExpandedRows = new Set(expandedRows);
    if (newExpandedRows.has(rowId)) {
      newExpandedRows.delete(rowId);
    } else {
      newExpandedRows.add(rowId);
    }
    setExpandedRows(newExpandedRows);
  };

  // 解析资源类型字符串，分解为独立的资源类型数组
  const parseResourceTypes = (resourceType: string): string[] => {
    return resourceType.split(/[+、,，]/).map(type => type.trim()).filter(type => type.length > 0);
  };

  // 获取单个资源类型的Badge颜色
  const getResourceTypeBadgeColor = (resourceType: string) => {
    const type = resourceType.toLowerCase();
    if (type === "工位") {
      return "bg-blue-100 text-blue-800";
    } else if (type === "会议室") {
      return "bg-green-100 text-green-800";
    } else if (type === "独立办公室") {
      return "bg-purple-100 text-purple-800";
    } else if (type === "实验室") {
      return "bg-orange-100 text-orange-800";
    } else if (type === "展示厅") {
      return "bg-pink-100 text-pink-800";
    } else if (type === "培训室") {
      return "bg-cyan-100 text-cyan-800";
    } else if (type === "停车位") {
      return "bg-indigo-100 text-indigo-800";
    } else if (type === "储物间") {
      return "bg-teal-100 text-teal-800";
    } else if (type === "直播室") {
      return "bg-red-100 text-red-800";
    } else if (type === "摄影棚") {
      return "bg-yellow-100 text-yellow-800";
    } else {
      return "bg-gray-100 text-gray-800";
    }
  };

  // 统计数据
  const statistics = [
    {
      title: "工位使用",
      items: [
        { label: "HC人数", value: "1,250", color: "text-blue-600" },
        { label: "在职人数", value: "1,180", color: "text-green-600" },
        { label: "总预算", value: "1,500", color: "text-blue-600" },
        { label: "已申请", value: "1,200", color: "text-yellow-600" },
        { label: "已分配", value: "1,100", color: "text-green-600" },
        { label: "待分配", value: "100", color: "text-orange-600" },
        { label: "已绑定", value: "980", color: "text-purple-600" }
      ]
    },
    {
      title: "空间使用",
      items: [
        { label: "会议室", value: "45", color: "text-blue-600" },
        { label: "储物间", value: "12", color: "text-green-600" },
        { label: "直播室", value: "8", color: "text-purple-600" },
        { label: "摄影棚", value: "3", color: "text-orange-600" },
        { label: "设备借用", value: "128", color: "text-cyan-600" },
        { label: "其他空间", value: "25", color: "text-gray-600" }
      ]
    },
    {
      title: "空间服务",
      items: [
        { label: "改造项目", value: "15", color: "text-blue-600" },
        { label: "注册地占用", value: "8", color: "text-green-600" },
        { label: "其他服务", value: "22", color: "text-purple-600" }
      ]
    }
  ];

  // 按城市分布数据
  const cityData = [
    {
      id: "1",
      workArea: "总部工区",
      city: "北京",
      department: "技术中心",
      hcCount: "350",
      workingCount: "330",
      outsideCount: "15",
      resourceType: "工位+会议室",
      workstationCount: "350",
      spaceCount: "30",
      workstationArea: "2,450",
      spaceArea: "400",
      location: "总部-A栋",
      hasChildren: true,
      children: [
        {
          id: "1-1",
          workArea: "总部工区",
          city: "北京",
          department: "技术中心-前端团队",
          hcCount: "120",
          workingCount: "115",
          outsideCount: "5",
          resourceType: "工位+会议室",
          workstationCount: "120",
          spaceCount: "10",
          workstationArea: "840",
          spaceArea: "130",
          location: "总部-A栋-3F"
        },
        {
          id: "1-2",
          workArea: "总部工区",
          city: "北京",
          department: "技术中心-后端团队",
          hcCount: "130",
          workingCount: "125",
          outsideCount: "8",
          resourceType: "工位+会议室",
          workstationCount: "130",
          spaceCount: "10",
          workstationArea: "910",
          spaceArea: "135",
          location: "总部-A栋-4F"
        },
        {
          id: "1-3",
          workArea: "总部工区",
          city: "北京",
          department: "技术中心-测试团队",
          hcCount: "100",
          workingCount: "90",
          outsideCount: "2",
          resourceType: "工位+会议室",
          workstationCount: "100",
          spaceCount: "10",
          workstationArea: "700",
          spaceArea: "135",
          location: "总部-A栋-5F"
        }
      ]
    },
    {
      id: "2",
      workArea: "上海工区",
      city: "上海",
      department: "产品中心",
      hcCount: "280",
      workingCount: "265",
      outsideCount: "12",
      resourceType: "工位+独立办公室",
      workstationCount: "280",
      spaceCount: "15",
      workstationArea: "1,960",
      spaceArea: "400",
      location: "分部-B栋",
      hasChildren: false
    },
    {
      id: "3",
      workArea: "深圳工区",
      city: "深圳",
      department: "研发中心",
      hcCount: "420",
      workingCount: "405",
      outsideCount: "18",
      resourceType: "工位+实验室",
      workstationCount: "420",
      spaceCount: "30",
      workstationArea: "2,940",
      spaceArea: "660",
      location: "研发园-C栋",
      hasChildren: false
    },
    {
      id: "4",
      workArea: "广州工区",
      city: "广州",
      department: "销售中心",
      hcCount: "200",
      workingCount: "185",
      outsideCount: "8",
      resourceType: "工位+展示厅",
      workstationCount: "200",
      spaceCount: "20",
      workstationArea: "1,400",
      spaceArea: "360",
      location: "商务区-D栋",
      hasChildren: false
    }
  ];

  // 按部门分布数据
  const departmentData = [
    {
      id: "1",
      workArea: "总部工区",
      department: "技术中心",
      city: "北京",
      hcCount: "350",
      workingCount: "330",
      outsideCount: "15",
      resourceType: "工位+会议室",
      workstationCount: "350",
      spaceCount: "30",
      workstationArea: "2,450",
      spaceArea: "400",
      location: "总部-A栋",
      hasChildren: true,
      children: [
        {
          id: "1-1",
          workArea: "总部工区",
          department: "技术中心-前端团队",
          city: "北京",
          hcCount: "120",
          workingCount: "115",
          outsideCount: "5",
          resourceType: "工位+会议室",
          workstationCount: "120",
          spaceCount: "10",
          workstationArea: "840",
          spaceArea: "130",
          location: "总部-A栋-3F"
        },
        {
          id: "1-2",
          workArea: "总部工区",
          department: "技术中心-后端团队",
          city: "北京",
          hcCount: "130",
          workingCount: "125",
          outsideCount: "8",
          resourceType: "工位+会议室",
          workstationCount: "130",
          spaceCount: "10",
          workstationArea: "910",
          spaceArea: "135",
          location: "总部-A栋-4F"
        },
        {
          id: "1-3",
          workArea: "总部工区",
          department: "技术中心-测试团队",
          city: "北京",
          hcCount: "100",
          workingCount: "90",
          outsideCount: "2",
          resourceType: "工位+会议室",
          workstationCount: "100",
          spaceCount: "10",
          workstationArea: "700",
          spaceArea: "135",
          location: "总部-A栋-5F"
        }
      ]
    },
    {
      id: "2",
      workArea: "上海工区",
      department: "产品中心",
      city: "上海",
      hcCount: "280",
      workingCount: "265",
      outsideCount: "12",
      resourceType: "工位+独立办公室",
      workstationCount: "280",
      spaceCount: "15",
      workstationArea: "1,960",
      spaceArea: "400",
      location: "分部-B栋",
      hasChildren: false
    },
    {
      id: "3",
      workArea: "深圳工区",
      department: "研发中心",
      city: "深圳",
      hcCount: "420",
      workingCount: "405",
      outsideCount: "18",
      resourceType: "工位+实验室",
      workstationCount: "420",
      spaceCount: "30",
      workstationArea: "2,940",
      spaceArea: "660",
      location: "研发园-C栋",
      hasChildren: false
    },
    {
      id: "4",
      workArea: "广州工区",
      department: "销售中心",
      city: "广州",
      hcCount: "200",
      workingCount: "185",
      outsideCount: "8",
      resourceType: "工位+展示厅",
      workstationCount: "200",
      spaceCount: "20",
      workstationArea: "1,400",
      spaceArea: "360",
      location: "商务区-D栋",
      hasChildren: false
    },
    {
      id: "5",
      workArea: "杭州工区",
      department: "运营中心",
      city: "杭州",
      hcCount: "150",
      workingCount: "140",
      outsideCount: "6",
      resourceType: "工位+培训室",
      workstationCount: "150",
      spaceCount: "15",
      workstationArea: "1,050",
      spaceArea: "270",
      location: "科技城-E栋",
      hasChildren: false
    }
  ];

  return (
    <div className="space-y-4">
      {/* 页面标题 */}
      <div>
        <h1 className="text-lg font-medium">空间资源使用</h1>
      </div>

      {/* 统计卡片区 - 1行3列 */}
      <div className="grid grid-cols-3 gap-4">
        {statistics.map((stat, index) => (
          <Card key={index} className="bg-white border border-gray-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-900">{stat.title}</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-2">
                {stat.items.map((item, itemIndex) => (
                  <div key={itemIndex} className="flex justify-between items-center">
                    <span className="text-xs text-muted-foreground">{item.label}:</span>
                    <span className="text-xs font-medium text-primary">{item.value}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 资源分布表 */}
      <Card className="bg-white border border-gray-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-gray-900">资源分布</CardTitle>
        </CardHeader>

        <CardContent className="pt-0 mt-[-21px] mr-[0px] mb-[0px] ml-[0px]">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-fit grid-cols-2 mb-4">
              <TabsTrigger value="by-city" className="text-xs">按城市</TabsTrigger>
              <TabsTrigger value="by-department" className="text-xs">按部门</TabsTrigger>
            </TabsList>

            {/* 按城市Tab */}
            <TabsContent value="by-city" className="mt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10">城市</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">部门</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">HC人数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">在职人数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">编外人数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">资源类型</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">总需求工位</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">已分配工位</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">空间数量</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">空间面积</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">工区</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">位置</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {cityData.map((record) => (
                      <Fragment key={record.id}>
                        <TableRow className="hover:bg-gray-50">
                          <TableCell className="text-xs text-gray-900 font-medium">
                            <div className="flex items-center gap-2">
                              {record.hasChildren && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-4 w-4 p-0 hover:bg-gray-200"
                                  onClick={() => toggleRowExpansion(record.id)}
                                >
                                  {expandedRows.has(record.id) ? (
                                    <ChevronDown className="h-3 w-3" />
                                  ) : (
                                    <ChevronRight className="h-3 w-3" />
                                  )}
                                </Button>
                              )}
                              {!record.hasChildren && <div className="w-4" />}
                              {record.city}
                            </div>
                          </TableCell>
                          <TableCell className="text-xs text-gray-900">{record.department}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.hcCount}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.workingCount}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.outsideCount}</TableCell>
                          <TableCell className="text-xs">
                            <div className="flex flex-wrap gap-1">
                              {parseResourceTypes(record.resourceType).map((type, index) => (
                                <Badge 
                                  key={index}
                                  variant="secondary" 
                                  className={`${getResourceTypeBadgeColor(type)} text-xs px-2 py-1 font-normal`}
                                >
                                  {type}
                                </Badge>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell className="text-xs text-gray-900">{record.workstationCount}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.workstationArea}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.spaceCount}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.spaceArea}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.workArea}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.location}</TableCell>
                          <TableCell className="text-xs">
                            <Button 
                              variant="link" 
                              size="sm" 
                              className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                            >
                              查看
                            </Button>
                          </TableCell>
                        </TableRow>
                        {/* 子行 */}
                        {record.hasChildren && expandedRows.has(record.id) && record.children?.map((child) => (
                          <TableRow key={child.id} className="hover:bg-gray-50 bg-gray-25">
                            <TableCell className="text-xs text-gray-700">
                              <div className="flex items-center gap-2 pl-6">
                                <div className="w-4" />
                                {child.city}
                              </div>
                            </TableCell>
                            <TableCell className="text-xs text-gray-700">{child.department}</TableCell>
                            <TableCell className="text-xs text-gray-700">{child.hcCount}</TableCell>
                            <TableCell className="text-xs text-gray-700">{child.workingCount}</TableCell>
                            <TableCell className="text-xs text-gray-700">{child.outsideCount}</TableCell>
                            <TableCell className="text-xs">
                              <div className="flex flex-wrap gap-1">
                                {parseResourceTypes(child.resourceType).map((type, index) => (
                                  <Badge 
                                    key={index}
                                    variant="secondary" 
                                    className={`${getResourceTypeBadgeColor(type)} text-xs px-2 py-1 font-normal`}
                                  >
                                    {type}
                                  </Badge>
                                ))}
                              </div>
                            </TableCell>
                            <TableCell className="text-xs text-gray-700">{child.workstationCount}</TableCell>
                            <TableCell className="text-xs text-gray-700">{child.workstationArea}</TableCell>
                            <TableCell className="text-xs text-gray-700">{child.spaceCount}</TableCell>
                            <TableCell className="text-xs text-gray-700">{child.spaceArea}</TableCell>
                            <TableCell className="text-xs text-gray-700">{child.workArea}</TableCell>
                            <TableCell className="text-xs text-gray-700">{child.location}</TableCell>
                            <TableCell className="text-xs">
                              <Button 
                                variant="link" 
                                size="sm" 
                                className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                              >
                                查看
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </Fragment>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <TablePagination
                total={totalItems}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </TabsContent>

            {/* 按部门Tab */}
            <TabsContent value="by-department" className="mt-0">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="text-xs font-medium text-gray-700 h-10">部门</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">城市</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">HC人数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">在职人数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">编外人数</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">资源类型</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">工位数量</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">工位面积</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">空间数量</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">空间面积</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">工区</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">位置</TableHead>
                      <TableHead className="text-xs font-medium text-gray-700 h-10">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {departmentData.map((record) => (
                      <Fragment key={record.id}>
                        <TableRow className="hover:bg-gray-50">
                          <TableCell className="text-xs text-gray-900 font-medium">
                            <div className="flex items-center gap-2">
                              {record.hasChildren && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-4 w-4 p-0 hover:bg-gray-200"
                                  onClick={() => toggleRowExpansion(record.id)}
                                >
                                  {expandedRows.has(record.id) ? (
                                    <ChevronDown className="h-3 w-3" />
                                  ) : (
                                    <ChevronRight className="h-3 w-3" />
                                  )}
                                </Button>
                              )}
                              {!record.hasChildren && <div className="w-4" />}
                              {record.department}
                            </div>
                          </TableCell>
                          <TableCell className="text-xs text-gray-900">{record.city}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.hcCount}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.workingCount}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.outsideCount}</TableCell>
                          <TableCell className="text-xs">
                            <div className="flex flex-wrap gap-1">
                              {parseResourceTypes(record.resourceType).map((type, index) => (
                                <Badge 
                                  key={index}
                                  variant="secondary" 
                                  className={`${getResourceTypeBadgeColor(type)} text-xs px-2 py-1 font-normal`}
                                >
                                  {type}
                                </Badge>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell className="text-xs text-gray-900">{record.workstationCount}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.workstationArea}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.spaceCount}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.spaceArea}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.workArea}</TableCell>
                          <TableCell className="text-xs text-gray-900">{record.location}</TableCell>
                          <TableCell className="text-xs">
                            <Button 
                              variant="link" 
                              size="sm" 
                              className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                            >
                              查看
                            </Button>
                          </TableCell>
                        </TableRow>
                        {/* 子行 */}
                        {record.hasChildren && expandedRows.has(record.id) && record.children?.map((child) => (
                          <TableRow key={child.id} className="hover:bg-gray-50 bg-gray-25">
                            <TableCell className="text-xs text-gray-700">
                              <div className="flex items-center gap-2 pl-6">
                                <div className="w-4" />
                                {child.department}
                              </div>
                            </TableCell>
                            <TableCell className="text-xs text-gray-700">{child.city}</TableCell>
                            <TableCell className="text-xs text-gray-700">{child.hcCount}</TableCell>
                            <TableCell className="text-xs text-gray-700">{child.workingCount}</TableCell>
                            <TableCell className="text-xs text-gray-700">{child.outsideCount}</TableCell>
                            <TableCell className="text-xs">
                              <div className="flex flex-wrap gap-1">
                                {parseResourceTypes(child.resourceType).map((type, index) => (
                                  <Badge 
                                    key={index}
                                    variant="secondary" 
                                    className={`${getResourceTypeBadgeColor(type)} text-xs px-2 py-1 font-normal`}
                                  >
                                    {type}
                                  </Badge>
                                ))}
                              </div>
                            </TableCell>
                            <TableCell className="text-xs text-gray-700">{child.workstationCount}</TableCell>
                            <TableCell className="text-xs text-gray-700">{child.workstationArea}</TableCell>
                            <TableCell className="text-xs text-gray-700">{child.spaceCount}</TableCell>
                            <TableCell className="text-xs text-gray-700">{child.spaceArea}</TableCell>
                            <TableCell className="text-xs text-gray-700">{child.workArea}</TableCell>
                            <TableCell className="text-xs text-gray-700">{child.location}</TableCell>
                            <TableCell className="text-xs">
                              <Button 
                                variant="link" 
                                size="sm" 
                                className="h-auto p-0 text-xs text-blue-600 hover:text-blue-800"
                              >
                                查看
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </Fragment>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <TablePagination
                total={totalItems}
                currentPage={currentPage}
                pageSize={pageSize}
                onPageChange={setCurrentPage}
                onPageSizeChange={setPageSize}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}