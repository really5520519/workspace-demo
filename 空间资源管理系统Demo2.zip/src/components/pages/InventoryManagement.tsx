import { useState } from "react";
import { Card, CardContent } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import { Badge } from "../ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  FileText,
  CheckCircle,
  Package,
  Home,
  Box,
  Truck,
  Tag,
  Plus,
  Search,
  Filter,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

export function InventoryManagementContent() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // 库存统计数据
  const statsData = [
    {
      label: "新增需求",
      value: "152",
      icon: FileText,
      iconColor: "text-blue-600",
      bgColor: "bg-blue-50"
    },
    {
      label: "已结算",
      value: "5",
      icon: CheckCircle,
      iconColor: "text-green-600",
      bgColor: "bg-green-50"
    },
    {
      label: "已提交申请",
      value: "5",
      icon: Package,
      iconColor: "text-purple-600",
      bgColor: "bg-purple-50"
    },
    {
      label: "已提交装修",
      value: "11",
      icon: Home,
      iconColor: "text-orange-600",
      bgColor: "bg-orange-50"
    },
    {
      label: "已提交资产",
      value: "4",
      icon: Box,
      iconColor: "text-cyan-600",
      bgColor: "bg-cyan-50"
    },
    {
      label: "已提交配置",
      value: "4",
      icon: Truck,
      iconColor: "text-red-600",
      bgColor: "bg-red-50"
    }
  ];

  // 库存数据
  const inventoryData = [
    {
      id: "REQ-2025-010",
      name: "华南区集团项目",
      type: "新增",
      status: "已提交资产",
      location: "深圳-南山区",
      requestType: "业务需求",
      applicant: "张小",
      department: "销售部",
      category: "工位",
      quantity: "50",
      approvalDays: "365天",
      createTime: "2024-07-10",
      updateTime: "2024-07-18"
    },
    {
      id: "REQ-2025-011",
      name: "北京AI Lab分公司",
      type: "已有工区",
      status: "已提交资产",
      location: "北京-海淀区",
      requestType: "业务需求",
      applicant: "刘七",
      department: "AI Lab",
      category: "改造",
      quantity: "1",
      approvalDays: "60天",
      createTime: "2024-07-05",
      updateTime: "2024-07-15"
    },
    {
      id: "REQ-2025-012",
      name: "上海研发中心扩建",
      type: "新增",
      status: "已提交申请",
      location: "上海-浦东新区",
      requestType: "业务需求",
      applicant: "张三",
      department: "研发部",
      category: "工位",
      quantity: "80",
      approvalDays: "180天",
      createTime: "2024-07-12",
      updateTime: "2024-07-20"
    },
    {
      id: "REQ-2025-013",
      name: "广州分公司办公区域",
      type: "已有工区",
      status: "已提交装修",
      location: "广州-天河区",
      requestType: "客户需求",
      applicant: "李四",
      department: "运营部",
      category: "会议室",
      quantity: "5",
      approvalDays: "90天",
      createTime: "2024-07-08",
      updateTime: "2024-07-16"
    },
    {
      id: "REQ-2025-014",
      name: "成都技术团队工位",
      type: "新增",
      status: "已提交资产",
      location: "成都-高新区",
      requestType: "业务需求",
      applicant: "王五",
      department: "技术部",
      category: "工位",
      quantity: "30",
      approvalDays: "270天",
      createTime: "2024-07-06",
      updateTime: "2024-07-14"
    },
    {
      id: "REQ-2025-015",
      name: "杭州分公司扩建改造",
      type: "已有工区",
      status: "已结算",
      location: "杭州-西湖区",
      requestType: "客户需求",
      applicant: "赵六",
      department: "设计部",
      category: "改造",
      quantity: "1",
      approvalDays: "45天",
      createTime: "2024-06-28",
      updateTime: "2024-07-10"
    },
    {
      id: "REQ-2025-016",
      name: "苏州研发基地建设",
      type: "新增",
      status: "已提交资产",
      location: "苏州-工业园区",
      requestType: "业务需求",
      applicant: "刘七",
      department: "研发部",
      category: "工位",
      quantity: "120",
      approvalDays: "480天",
      createTime: "2024-07-15",
      updateTime: "2024-07-22"
    },
    {
      id: "REQ-2025-017",
      name: "武汉客服中心扩容",
      type: "已有工区",
      status: "已提交申请",
      location: "武汉-江汉区",
      requestType: "业务需求",
      applicant: "马九",
      department: "客服部",
      category: "工位",
      quantity: "40",
      approvalDays: "200天",
      createTime: "2024-07-11",
      updateTime: "2024-07-19"
    },
    {
      id: "REQ-2025-018",
      name: "西安分公司会议室",
      type: "已有工区",
      status: "已提交装修",
      location: "西安-雁塔区",
      requestType: "客户需求",
      applicant: "陈八",
      department: "行政部",
      category: "会议室",
      quantity: "3",
      approvalDays: "30天",
      createTime: "2024-07-09",
      updateTime: "2024-07-17"
    },
    {
      id: "REQ-2025-019",
      name: "天津分公司数据中心",
      type: "新增",
      status: "新增需求",
      location: "天津-滨海新区",
      requestType: "业务需求",
      applicant: "李十",
      department: "运维部",
      category: "工位",
      quantity: "200",
      approvalDays: "730天",
      createTime: "2024-07-20",
      updateTime: "2024-07-25"
    }
  ];

  const getStatusBadge = (status: string) => {
    const statusStyles = {
      "已提交资产": "bg-blue-100 text-blue-800",
      "已提交申请": "bg-purple-100 text-purple-800", 
      "已提交装修": "bg-orange-100 text-orange-800",
      "已结算": "bg-green-100 text-green-800",
      "新增需求": "bg-gray-100 text-gray-800"
    };
    
    return (
      <Badge className={`${statusStyles[status] || "bg-gray-100 text-gray-800"}`}>
        {status}
      </Badge>
    );
  };

  const totalPages = Math.ceil(inventoryData.length / itemsPerPage);
  const paginatedData = inventoryData.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div className="space-y-4" style={{ width: '1300px', margin: '0 auto' }}>
      {/* 面包屑和标题 */}
      <div>
        <h1 className="text-[15px] font-bold">库存管理</h1>
      </div>

      {/* 统计概况 */}
      <div className="grid grid-cols-6 gap-4">
        {statsData.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="border border-gray-200">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
                    <Icon className={`h-6 w-6 ${stat.iconColor}`} />
                  </div>
                  <div>
                    <div className="text-2xl font-medium text-gray-900">{stat.value}</div>
                    <div className="text-sm text-gray-600">{stat.label}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* 操作按钮区域 */}
      <div className="flex justify-end">
        <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
          <Plus className="h-4 w-4 mr-1" />
          新建需求
        </Button>
      </div>

      {/* 需求列表 */}
      <Card>
        <CardContent className="p-0">
          {/* 搜索和筛选 */}
          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="搜索项目名称/编号/申请人..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="请选择状态" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部状态</SelectItem>
                  <SelectItem value="已提交资产">已提交资产</SelectItem>
                  <SelectItem value="已提交申请">已提交申请</SelectItem>
                  <SelectItem value="已提交装修">已提交装修</SelectItem>
                  <SelectItem value="已结算">已结算</SelectItem>
                  <SelectItem value="新增需求">新增需求</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-1" />
                筛选
              </Button>
            </div>
          </div>

          {/* 表格 */}
          <div className="border rounded-lg m-4">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead>项目ID</TableHead>
                  <TableHead>项目名称</TableHead>
                  <TableHead>项目类型</TableHead>
                  <TableHead>当前节点</TableHead>
                  <TableHead>位置-城市-区</TableHead>
                  <TableHead>需求类型</TableHead>
                  <TableHead>申请人</TableHead>
                  <TableHead>申请部门</TableHead>
                  <TableHead>运营类型</TableHead>
                  <TableHead>申报数量</TableHead>
                  <TableHead>在途时长</TableHead>
                  <TableHead>审批创建时间</TableHead>
                  <TableHead>审批更新时间</TableHead>
                  <TableHead>操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedData.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium text-blue-600">
                      {item.id}
                    </TableCell>
                    <TableCell>{item.name}</TableCell>
                    <TableCell>{item.type}</TableCell>
                    <TableCell>{getStatusBadge(item.status)}</TableCell>
                    <TableCell>{item.location}</TableCell>
                    <TableCell>{item.requestType}</TableCell>
                    <TableCell>{item.applicant}</TableCell>
                    <TableCell>{item.department}</TableCell>
                    <TableCell>{item.category}</TableCell>
                    <TableCell>{item.quantity}</TableCell>
                    <TableCell>{item.approvalDays}</TableCell>
                    <TableCell>{item.createTime}</TableCell>
                    <TableCell>{item.updateTime}</TableCell>
                    <TableCell>
                      <Button variant="link" size="sm" className="text-blue-600 hover:text-blue-800 p-0 h-auto">
                        详情
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* 分页 */}
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-200">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <span>共 {inventoryData.length} 条</span>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              
              <div className="flex items-center gap-1">
                {[...Array(Math.min(5, totalPages))].map((_, i) => {
                  const pageNum = i + 1;
                  return (
                    <Button
                      key={pageNum}
                      variant={currentPage === pageNum ? "default" : "outline"}
                      size="sm"
                      onClick={() => setCurrentPage(pageNum)}
                      className={currentPage === pageNum ? "bg-blue-600 text-white" : ""}
                    >
                      {pageNum}
                    </Button>
                  );
                })}
                {totalPages > 5 && (
                  <>
                    <span className="px-2">...</span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(totalPages)}
                    >
                      {totalPages}
                    </Button>
                  </>
                )}
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <span>{itemsPerPage}</span>
              <span>条/页</span>
              <Select value="first" onValueChange={() => {}}>
                <SelectTrigger className="w-16 h-8">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="first">首页</SelectItem>
                </SelectContent>
              </Select>
              <span>1</span>
              <span>页</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}