import { Card, CardContent } from "../ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Settings } from "lucide-react";
import { BuildingFileManagementContent as NewBuildingFileManagementContent } from "./BuildingFileManagement";
import { BuildingPersonnelManagementContent as NewBuildingPersonnelManagementContent } from "./BuildingPersonnelManagement";
import { BuildingSupplierManagementContent as NewBuildingSupplierManagementContent } from "./BuildingSupplierManagement";
import { PricingManagementContent as NewPricingManagementContent } from "./PricingManagement";

interface DefaultContentProps {
  itemId: string;
}

export function DefaultContent({ itemId }: DefaultContentProps) {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-lg font-medium">功能开发中</h1>
        <p className="text-muted-foreground text-xs">
          该功能模块 "{itemId}" 正在开发中，敬请期待
        </p>
      </div>
      
      <Card>
        <CardContent>
          <div className="space-y-4" style={{ maxWidth: '1300px', margin: '0 auto' }}>
            <Tabs defaultValue="billing-statistics" className="w-full">
              <TabsList className="grid w-fit grid-cols-3">
                <TabsTrigger value="billing-statistics">计费统计</TabsTrigger>
                <TabsTrigger value="billing-progress">计费进展</TabsTrigger>
                <TabsTrigger value="feedback-handling">反馈处理</TabsTrigger>
              </TabsList>

              {/* Tab 1: 计费统计 */}
              <TabsContent value="billing-statistics" className="space-y-4">
                <Card className="border-0">
                  <CardContent className="p-6">
                    <div className="text-center space-y-4">
                      <div className="w-16 h-16 bg-muted rounded-lg flex items-center justify-center mx-auto">
                        <Settings className="h-8 w-8 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-medium">计费统计功能开发中</p>
                        <p className="text-muted-foreground">我们正在努力完善计费数据统计功能</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Tab 2: 计费进展 */}
              <TabsContent value="billing-progress" className="space-y-4">
                <Card className="border-0">
                  <CardContent className="p-6">
                    <div className="text-center space-y-4">
                      <div className="w-16 h-16 bg-muted rounded-lg flex items-center justify-center mx-auto">
                        <Settings className="h-8 w-8 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-medium">计费进展功能开发中</p>
                        <p className="text-muted-foreground">我们正在努力完善计费进展跟踪功能</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Tab 3: 反馈处理 */}
              <TabsContent value="feedback-handling" className="space-y-4">
                <Card className="border-0">
                  <CardContent className="p-6">
                    <div className="text-center space-y-4">
                      <div className="w-16 h-16 bg-muted rounded-lg flex items-center justify-center mx-auto">
                        <Settings className="h-8 w-8 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-medium">反馈处理功能开发中</p>
                        <p className="text-muted-foreground">我们正在努力完善用户反馈处理功能</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// 其他页面的占位组件
export function BusinessAnalysisContent() { return <DefaultContent itemId="business-analysis" />; }
export function BudgetManagementContent() { return <DefaultContent itemId="budget-management" />; }
export function CostManagementContent() { return <DefaultContent itemId="cost-management" />; }
export function PricingManagementContent() { return <NewPricingManagementContent />; }
export function BillingManagementContent() { return <DefaultContent itemId="billing-management" />; }
export function DemandManagementContent() { return <DefaultContent itemId="demand-management" />; }
export function LeaseManagementContent() { return <DefaultContent itemId="lease-management" />; }
export function ConstructionManagementContent() { return <DefaultContent itemId="construction-management" />; }
export function AllocationManagementContent() { return <DefaultContent itemId="allocation-management" />; }
export function MoveManagementContent() { return <DefaultContent itemId="move-management" />; }
export function InventoryManagementContent() { return <DefaultContent itemId="inventory-management" />; }
export function SupplyDemandManagementContent() { return <DefaultContent itemId="supply-demand-management" />; }
export function FacilityManagementContent() { return <DefaultContent itemId="facility-management" />; }
export function BuildingFileManagementContent() { return <NewBuildingFileManagementContent />; }
export function BuildingPersonnelManagementContent() { return <NewBuildingPersonnelManagementContent />; }
export function BuildingSupplierManagementContent() { return <NewBuildingSupplierManagementContent />; }
export function BuildingOperationInfoContent() { return <DefaultContent itemId="building-operation-info" />; }
export function PermissionManagementContent() { return <DefaultContent itemId="permission-management" />; }
export function OperationLogContent() { return <DefaultContent itemId="operation-log" />; }
export function InterfaceConfigContent() { return <DefaultContent itemId="interface-config" />; }