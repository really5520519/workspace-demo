import svgPaths from "./svg-dw1en8ruyw";
import imgAvatar from "figma:asset/0b17d61a8c403f95cac66847d0b125064c9bdd70.png";

function TipsCheckCircle() {
  return (
    <div className="relative shrink-0 size-4" data-name="tips/check-circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="tips/check-circle">
          <path clipRule="evenodd" d={svgPaths.p9881c00} fill="var(--fill-0, #4E5969)" fillRule="evenodd" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function ComponentsLink() {
  return (
    <div
      className="box-border content-stretch flex gap-1 items-center justify-start px-1 py-[3px] relative shrink-0"
      data-name="components/Link"
    >
      <TipsCheckCircle />
    </div>
  );
}

function EditObliqueLine() {
  return (
    <div className="relative shrink-0 size-3" data-name="edit/oblique-line">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="edit/oblique-line">
          <path
            clipRule="evenodd"
            d={svgPaths.p10c63fb0}
            fill="var(--fill-0, #C9CDD4)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function ComponentsSeparator() {
  return (
    <div
      className="box-border content-stretch flex items-center justify-start overflow-clip p-0 relative shrink-0"
      data-name="components/separator"
    >
      <EditObliqueLine />
    </div>
  );
}

function ComponentsLink1() {
  return (
    <div
      className="box-border content-stretch flex gap-1 items-center justify-start px-1 py-0 relative shrink-0"
      data-name="components/Link"
    >
      <div className="font-['PingFang_SC:Regular',_sans-serif] leading-[0] not-italic relative shrink-0 text-[#4e5969] text-[14px] text-nowrap">
        <p className="block leading-[22px] whitespace-pre">结果页</p>
      </div>
    </div>
  );
}

function ComponentsLink2() {
  return (
    <div
      className="box-border content-stretch flex gap-1 items-center justify-start px-1 py-0 relative shrink-0"
      data-name="components/Link"
    >
      <div className="font-['PingFang_SC:Medium',_sans-serif] leading-[0] not-italic relative shrink-0 text-[#1d2129] text-[14px] text-nowrap">
        <p className="block leading-[22px] whitespace-pre">成功页</p>
      </div>
    </div>
  );
}

function Breadcrumb() {
  return (
    <div
      className="absolute box-border content-stretch flex items-center justify-start left-60 px-0 py-px top-[76px]"
      data-name="breadcrumb"
    >
      <ComponentsLink />
      <ComponentsSeparator />
      <ComponentsLink1 />
      <ComponentsSeparator />
      <ComponentsLink2 />
    </div>
  );
}

function TipsCheckCircleFill() {
  return (
    <div className="relative shrink-0 size-12" data-name="tips/check-circle-fill">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 48">
        <g id="tips/check-circle-fill">
          <path
            clipRule="evenodd"
            d={svgPaths.p38508d00}
            fill="var(--fill-0, #00B42A)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function ResultIcon() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-center justify-center overflow-clip p-0 relative shrink-0"
      data-name="result-icon"
    >
      <TipsCheckCircleFill />
    </div>
  );
}

function TextTitle() {
  return (
    <div
      className="box-border content-stretch flex gap-1 items-end justify-start overflow-clip p-0 relative shrink-0"
      data-name="text/title"
    >
      <div className="flex flex-col font-['PingFang_SC:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#1d2129] text-[14px] text-nowrap">
        <p className="block leading-[22px] whitespace-pre">提交成功</p>
      </div>
    </div>
  );
}

function TextText() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-center overflow-clip p-0 relative shrink-0 w-full"
      data-name="text/text"
    >
      <div className="font-['PingFang_SC:Regular',_sans-serif] leading-[0] not-italic relative shrink-0 text-[#86909c] text-[14px] text-center w-full">
        <p className="block leading-[22px]">表单提交成功！</p>
      </div>
    </div>
  );
}

function WidthScrubber() {
  return (
    <div
      className="box-border content-stretch flex gap-[200px] items-center justify-start overflow-clip p-0 relative shrink-0"
      data-name="width-scrubber"
    >
      <div className="shrink-0 size-[0.001px]" data-name="_ignore" />
      <div className="shrink-0 size-[0.001px]" data-name="_ignore" />
    </div>
  );
}

function Description() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-center justify-start p-0 relative shrink-0 w-full"
      data-name="description"
    >
      <TextTitle />
      <TextText />
      <WidthScrubber />
    </div>
  );
}

function Button() {
  return (
    <div
      className="bg-[#f2f3f5] box-border content-stretch flex gap-2 items-center justify-center overflow-clip px-4 py-[5px] relative rounded-sm shrink-0"
      data-name="Button"
    >
      <div className="flex flex-col font-['PingFang_SC:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#4e5969] text-[14px] text-nowrap">
        <p className="block leading-[22px] whitespace-pre">打印结果</p>
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div
      className="bg-[#165dff] box-border content-stretch flex gap-2 items-center justify-center overflow-clip px-4 py-[5px] relative rounded-sm shrink-0"
      data-name="Button"
    >
      <div className="flex flex-col font-['PingFang_SC:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#ffffff] text-[14px] text-nowrap">
        <p className="block leading-[22px] whitespace-pre">返回项目列表</p>
      </div>
    </div>
  );
}

function Extra() {
  return (
    <div
      className="box-border content-stretch flex gap-4 items-center justify-start p-0 relative shrink-0"
      data-name="extra"
    >
      <Button />
      <Button1 />
    </div>
  );
}

function Result() {
  return (
    <div
      className="absolute bg-[#ffffff] box-border content-stretch flex flex-col gap-4 items-center justify-start left-0 overflow-clip p-[24px] right-0 top-40"
      data-name="Result"
    >
      <ResultIcon />
      <Description />
      <Extra />
    </div>
  );
}

function TextTitle1() {
  return (
    <div
      className="box-border content-stretch flex gap-1 items-end justify-start overflow-clip p-0 relative shrink-0"
      data-name="text/title"
    >
      <div className="flex flex-col font-['PingFang_SC:Medium',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#1d2129] text-[16px] text-nowrap">
        <p className="block leading-[24px] whitespace-pre">当前进度</p>
      </div>
    </div>
  );
}

function Tail() {
  return (
    <div className="absolute h-0 left-0 right-[-71px] top-0" data-name="tail">
      <div className="absolute bottom-[-0.5px] left-0 right-0 top-[-0.5px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 150 2">
          <g id="tail">
            <path d="M0 1L150 1" id="line" stroke="var(--stroke-0, #165DFF)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Tail1() {
  return (
    <div className="basis-0 grow h-0 min-h-px min-w-px relative shrink-0" data-name="tail">
      <Tail />
    </div>
  );
}

function Track() {
  return (
    <div className="relative shrink-0 w-full" data-name="track">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-1 items-center justify-start pl-[75px] pr-0 py-0 relative w-full">
          <div className="relative shrink-0 size-2.5" data-name="dot">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 10">
              <circle cx="5" cy="5" fill="var(--fill-0, #165DFF)" id="dot" r="5" />
            </svg>
          </div>
          <Tail1 />
        </div>
      </div>
    </div>
  );
}

function Content() {
  return (
    <div
      className="box-border content-stretch flex flex-col font-['PingFang_SC:Regular',_sans-serif] gap-1 items-center justify-start leading-[0] not-italic p-0 relative shrink-0 text-center w-40"
      data-name="content"
    >
      <div className="relative shrink-0 text-[#1d2129] text-[14px] w-full">
        <p className="block leading-[22px]">提交申请</p>
      </div>
      <div className="relative shrink-0 text-[#86909c] text-[12px] w-full">
        <p className="block leading-[20px]">2020/10/10 14:00:39</p>
      </div>
    </div>
  );
}

function ComponentsStepsItemDot() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-col gap-2 grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="components/steps-item-dot"
    >
      <Track />
      <Content />
    </div>
  );
}

function Tail2() {
  return (
    <div className="absolute h-0 left-0 right-[-71px] top-0" data-name="tail">
      <div className="absolute bottom-[-0.5px] left-0 right-0 top-[-0.5px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 150 2">
          <g id="tail">
            <path d="M0 1L150 1" id="line" stroke="var(--stroke-0, #E5E6EB)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Tail3() {
  return (
    <div className="basis-0 grow h-0 min-h-px min-w-px relative shrink-0" data-name="tail">
      <Tail2 />
    </div>
  );
}

function Track1() {
  return (
    <div className="relative shrink-0 w-full" data-name="track">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-1 items-center justify-start pl-[75px] pr-0 py-0 relative w-full">
          <div className="relative shrink-0 size-2.5" data-name="dot">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 10">
              <circle cx="5" cy="5" fill="var(--fill-0, #165DFF)" id="dot" r="5" />
            </svg>
          </div>
          <Tail3 />
        </div>
      </div>
    </div>
  );
}

function Content1() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-1 items-center justify-start leading-[0] not-italic p-0 relative shrink-0 text-center w-40"
      data-name="content"
    >
      <div className="font-['PingFang_SC:Medium',_sans-serif] relative shrink-0 text-[#1d2129] text-[14px] w-full">
        <p className="block leading-[22px]">直属领导审核</p>
      </div>
      <div className="font-['PingFang_SC:Regular',_sans-serif] relative shrink-0 text-[#86909c] text-[12px] w-full">
        <p className="block leading-[20px]">进行中</p>
      </div>
    </div>
  );
}

function ComponentsStepsItemDot1() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-col gap-2 grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="components/steps-item-dot"
    >
      <Track1 />
      <Content1 />
    </div>
  );
}

function Tail4() {
  return (
    <div className="absolute h-0 left-0 right-[-71px] top-0" data-name="tail">
      <div className="absolute bottom-[-0.5px] left-0 right-0 top-[-0.5px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 150 2">
          <g id="tail">
            <path d="M0 1L150 1" id="line" stroke="var(--stroke-0, #E5E6EB)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Tail5() {
  return (
    <div className="basis-0 grow h-0 min-h-px min-w-px relative shrink-0" data-name="tail">
      <Tail4 />
    </div>
  );
}

function Track2() {
  return (
    <div className="relative shrink-0 w-full" data-name="track">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-1 items-center justify-start pl-[75px] pr-0 py-0 relative w-full">
          <div className="relative shrink-0 size-2.5" data-name="dot">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 10">
              <circle cx="5" cy="5" fill="var(--fill-0, #C9CDD4)" id="dot" r="5" />
            </svg>
          </div>
          <Tail5 />
        </div>
      </div>
    </div>
  );
}

function Content2() {
  return (
    <div
      className="box-border content-stretch flex flex-col font-['PingFang_SC:Regular',_sans-serif] gap-1 items-center justify-start leading-[0] not-italic p-0 relative shrink-0 text-center w-40"
      data-name="content"
    >
      <div className="relative shrink-0 text-[#1d2129] text-[14px] w-full">
        <p className="block leading-[22px]">购买证书</p>
      </div>
      <div className="relative shrink-0 text-[#86909c] text-[12px] w-full">
        <p className="block leading-[20px]">未开始</p>
      </div>
    </div>
  );
}

function ComponentsStepsItemDot2() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-col gap-2 grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="components/steps-item-dot"
    >
      <Track2 />
      <Content2 />
    </div>
  );
}

function Tail6() {
  return (
    <div className="absolute h-0 left-0 right-[-71px] top-0" data-name="tail">
      <div className="absolute bottom-[-0.5px] left-0 right-0 top-[-0.5px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 150 2">
          <g id="tail">
            <path d="M0 1L150 1" id="line" stroke="var(--stroke-0, #E5E6EB)" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Tail7() {
  return (
    <div className="basis-0 grow h-0 min-h-px min-w-px relative shrink-0" data-name="tail">
      <Tail6 />
    </div>
  );
}

function Track3() {
  return (
    <div className="relative shrink-0 w-full" data-name="track">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-1 items-center justify-start pl-[75px] pr-0 py-0 relative w-full">
          <div className="relative shrink-0 size-2.5" data-name="dot">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 10">
              <circle cx="5" cy="5" fill="var(--fill-0, #C9CDD4)" id="dot" r="5" />
            </svg>
          </div>
          <Tail7 />
        </div>
      </div>
    </div>
  );
}

function Content3() {
  return (
    <div
      className="box-border content-stretch flex flex-col font-['PingFang_SC:Regular',_sans-serif] gap-1 items-center justify-start leading-[0] not-italic p-0 relative shrink-0 text-center w-40"
      data-name="content"
    >
      <div className="relative shrink-0 text-[#1d2129] text-[14px] w-full">
        <p className="block leading-[22px]">安全测试</p>
      </div>
      <div className="relative shrink-0 text-[#86909c] text-[12px] w-full">
        <p className="block leading-[20px]">未开始</p>
      </div>
    </div>
  );
}

function ComponentsStepsItemDot3() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-col gap-2 grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="components/steps-item-dot"
    >
      <Track3 />
      <Content3 />
    </div>
  );
}

function Track4() {
  return (
    <div className="relative shrink-0 w-full" data-name="track">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-1 items-center justify-start pl-[75px] pr-0 py-0 relative w-full">
          <div className="relative shrink-0 size-2.5" data-name="dot">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 10">
              <circle cx="5" cy="5" fill="var(--fill-0, #C9CDD4)" id="dot" r="5" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Content4() {
  return (
    <div
      className="box-border content-stretch flex flex-col font-['PingFang_SC:Regular',_sans-serif] gap-1 items-center justify-start leading-[0] not-italic p-0 relative shrink-0 text-center w-40"
      data-name="content"
    >
      <div className="relative shrink-0 text-[#1d2129] text-[14px] w-full">
        <p className="block leading-[22px]">正式上线</p>
      </div>
      <div className="relative shrink-0 text-[#86909c] text-[12px] w-full">
        <p className="block leading-[20px]">未开始</p>
      </div>
    </div>
  );
}

function ComponentsStepsItemDot4() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-col gap-2 grow items-start justify-start min-h-px min-w-px overflow-clip p-0 relative shrink-0"
      data-name="components/steps-item-dot"
    >
      <Track4 />
      <Content4 />
    </div>
  );
}

function StepsDot() {
  return (
    <div
      className="box-border content-stretch flex items-start justify-start p-0 relative shrink-0 w-full"
      data-name="steps-dot"
    >
      <ComponentsStepsItemDot />
      <ComponentsStepsItemDot1 />
      <ComponentsStepsItemDot2 />
      <ComponentsStepsItemDot3 />
      <ComponentsStepsItemDot4 />
    </div>
  );
}

function StepsWrapper() {
  return (
    <div
      className="absolute bg-[#f7f8fa] box-border content-stretch flex flex-col gap-6 items-start justify-start left-[150px] overflow-clip p-[20px] right-[150px] top-[404px]"
      data-name="steps-wrapper"
    >
      <TextTitle1 />
      <StepsDot />
    </div>
  );
}

function Body() {
  return (
    <div className="absolute bg-[#ffffff] h-[764px] left-60 overflow-clip right-5 rounded top-[116px]" data-name="body">
      <Result />
      <StepsWrapper />
    </div>
  );
}

function Component2() {
  return (
    <div className="absolute inset-[-6.41%_-6.39%_-10.58%_-7.17%]" data-name="编组备份 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 23">
        <g id="ç¼ç»å¤ä»½ 2">
          <path
            clipRule="evenodd"
            d={svgPaths.p3e321500}
            fill="var(--fill-0, #12D2AC)"
            fillRule="evenodd"
            id="ç©å½¢å¤ä»½ 3"
          />
          <path
            clipRule="evenodd"
            d={svgPaths.p34cbf780}
            fill="var(--fill-0, #307AF2)"
            fillRule="evenodd"
            id="ç©å½¢å¤ä»½ 7"
          />
          <path clipRule="evenodd" d={svgPaths.p6006d00} fill="var(--fill-0, #0057FE)" fillRule="evenodd" id="ç©å½¢" />
        </g>
      </svg>
    </div>
  );
}

function Component3() {
  return (
    <div className="absolute contents inset-[-6.41%_-6.39%_-10.58%_-7.17%]" data-name="编组 3">
      <Component2 />
    </div>
  );
}

function Component5() {
  return (
    <div className="absolute contents inset-[-6.41%_-6.39%_-10.58%_-7.17%]" data-name="编组 5备份">
      <Component3 />
    </div>
  );
}

function Component6() {
  return (
    <div className="absolute contents inset-[-6.41%_-6.39%_-10.58%_-7.17%]" data-name="编组 6备份">
      <Component5 />
    </div>
  );
}

function Component() {
  return (
    <div className="absolute contents inset-[-6.41%_-6.39%_-10.58%_-7.17%]" data-name="画板">
      <Component6 />
    </div>
  );
}

function Component1() {
  return (
    <div className="absolute contents inset-[-6.41%_-6.39%_-10.58%_-7.17%]" data-name="页面1">
      <Component />
    </div>
  );
}

function Component21() {
  return (
    <div className="absolute inset-[20.31%_9.38%] overflow-clip" data-name="编组备份 2 1">
      <Component1 />
    </div>
  );
}

function Arco() {
  return (
    <div className="overflow-clip relative shrink-0 size-8" data-name="Arco">
      <Component21 />
    </div>
  );
}

function Logo() {
  return (
    <div
      className="box-border content-stretch flex gap-3 items-center justify-start p-0 relative shrink-0"
      data-name="Logo"
    >
      <Arco />
      <div className="font-['PingFang_SC:Medium',_sans-serif] leading-[0] not-italic relative shrink-0 text-[#1d2129] text-[20px] text-nowrap">
        <p className="block leading-[28px] whitespace-pre">Arco Pro</p>
      </div>
    </div>
  );
}

function Wrapper() {
  return (
    <div
      className="box-border content-stretch flex gap-3 items-center justify-start overflow-clip p-0 relative shrink-0 w-[182px]"
      data-name="wrapper"
    >
      <div className="flex flex-col font-['PingFang_SC:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#86909c] text-[14px] text-nowrap">
        <p className="block leading-[22px] whitespace-pre">输入内容查询</p>
      </div>
    </div>
  );
}

function InteractiveButtonSearch() {
  return (
    <div className="relative shrink-0 size-3.5" data-name="interactive-button/search">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="interactive-button/search">
          <path
            clipRule="evenodd"
            d={svgPaths.p31dc9c00}
            fill="var(--fill-0, #4E5969)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function AddAfter() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-center justify-center overflow-clip p-0 relative shrink-0"
      data-name="addAfter"
    >
      <InteractiveButtonSearch />
    </div>
  );
}

function SearchBox() {
  return (
    <div
      className="bg-[#f2f3f5] box-border content-stretch flex items-center justify-start overflow-clip px-3 py-[5px] relative rounded-3xl shrink-0"
      data-name="search-box"
    >
      <Wrapper />
      <AddAfter />
    </div>
  );
}

function GeneralLanguage() {
  return (
    <div className="relative shrink-0 size-3.5" data-name="general/language">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="general/language">
          <path clipRule="evenodd" d={svgPaths.pb0f9a40} fill="var(--fill-0, #4E5969)" fillRule="evenodd" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div
      className="bg-[#f2f3f5] box-border content-stretch flex gap-2.5 items-center justify-center overflow-clip p-[9px] relative rounded-[18px] shrink-0"
      data-name="Button"
    >
      <GeneralLanguage />
    </div>
  );
}

function GeneralNotification() {
  return (
    <div className="relative shrink-0 size-3.5" data-name="general/notification">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="general/notification">
          <path
            clipRule="evenodd"
            d={svgPaths.p19a08dc0}
            fill="var(--fill-0, #4E5969)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Button3() {
  return (
    <div
      className="bg-[#f2f3f5] box-border content-stretch flex gap-2.5 items-center justify-center overflow-clip p-[9px] relative rounded-[18px] shrink-0"
      data-name="Button"
    >
      <GeneralNotification />
    </div>
  );
}

function GeneralMoonFill() {
  return (
    <div className="relative shrink-0 size-3.5" data-name="general/moon-fill">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="general/moon-fill">
          <path d={svgPaths.pcc7d370} fill="var(--fill-0, #4E5969)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Button4() {
  return (
    <div
      className="bg-[#f2f3f5] box-border content-stretch flex gap-2.5 items-center justify-center overflow-clip p-[9px] relative rounded-[18px] shrink-0"
      data-name="Button"
    >
      <GeneralMoonFill />
    </div>
  );
}

function InteractiveButtonSettings() {
  return (
    <div className="relative shrink-0 size-3.5" data-name="interactive-button/settings">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="interactive-button/settings">
          <path
            clipRule="evenodd"
            d={svgPaths.p24686280}
            fill="var(--fill-0, #4E5969)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div
      className="bg-[#f2f3f5] box-border content-stretch flex gap-2.5 items-center justify-center overflow-clip p-[9px] relative rounded-[18px] shrink-0"
      data-name="Button"
    >
      <InteractiveButtonSettings />
    </div>
  );
}

function GeneralSkin() {
  return (
    <div className="relative shrink-0 size-3.5" data-name="general/skin">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="general/skin">
          <path
            clipRule="evenodd"
            d={svgPaths.p367d5e00}
            fill="var(--fill-0, #4E5969)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Button6() {
  return (
    <div
      className="bg-[#f2f3f5] box-border content-stretch flex gap-2.5 items-center justify-center overflow-clip p-[9px] relative rounded-[18px] shrink-0"
      data-name="Button"
    >
      <GeneralSkin />
    </div>
  );
}

function Placeholder() {
  return <div className="bg-[#ffffff] shrink-0 size-0" data-name="placeholder" />;
}

function Avatar() {
  return (
    <div
      className="bg-center bg-cover bg-no-repeat box-border content-stretch flex flex-col items-center justify-center p-[16px] relative rounded-[100px] shrink-0"
      data-name="Avatar"
      style={{ backgroundImage: `url('${imgAvatar}')` }}
    >
      <Placeholder />
    </div>
  );
}

function NavbarRight() {
  return (
    <div
      className="box-border content-stretch flex gap-4 items-center justify-start p-0 relative shrink-0"
      data-name="navbar- right"
    >
      <SearchBox />
      <Button2 />
      <Button3 />
      <Button4 />
      <Button5 />
      <Button6 />
      <Avatar />
    </div>
  );
}

function Navbar() {
  return (
    <div className="absolute bg-[#ffffff] h-[60px] left-0 right-0 top-0" data-name="navbar">
      <div className="box-border content-stretch flex items-center justify-between overflow-clip px-4 py-2.5 relative size-full">
        <Logo />
        <NavbarRight />
      </div>
      <div
        aria-hidden="true"
        className="absolute border-[#e5e6eb] border-[0px_0px_1px] border-solid inset-0 pointer-events-none"
      />
    </div>
  );
}

function GeneralDashboard() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="general/dashboard">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="general/dashboard">
          <path
            clipRule="evenodd"
            d={svgPaths.p11b62d00}
            fill="var(--fill-0, #4E5969)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function IconChangeSizeHere() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-center justify-center overflow-clip p-0 relative shrink-0"
      data-name="icon <- change size here"
    >
      <GeneralDashboard />
    </div>
  );
}

function Wrapper1() {
  return (
    <div
      className="basis-0 box-border content-stretch flex gap-2 grow items-center justify-start min-h-px min-w-px overflow-clip p-0 relative shrink-0"
      data-name="wrapper"
    >
      <div className="flex flex-col font-['PingFang_SC:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#4e5969] text-[14px] text-nowrap">
        <p className="block leading-[22px] whitespace-pre">仪表盘</p>
      </div>
    </div>
  );
}

function Suffix() {
  return (
    <div className="relative shrink-0 size-3.5" data-name="suffix">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="suffix">
          <path
            clipRule="evenodd"
            d={svgPaths.p3d05b00}
            fill="var(--fill-0, #4E5969)"
            fillRule="evenodd"
            id="Stroke (Stroke)"
          />
        </g>
      </svg>
    </div>
  );
}

function MenuItem() {
  return (
    <div className="bg-[rgba(255,255,255,0)] relative rounded-sm shrink-0 w-full" data-name="menu-item">
      <div className="flex flex-row items-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex gap-4 items-center justify-start px-3 py-[9px] relative w-full">
          <IconChangeSizeHere />
          <Wrapper1 />
          <Suffix />
        </div>
      </div>
    </div>
  );
}

function GeneralApps() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="general/apps">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="general/apps">
          <path
            clipRule="evenodd"
            d={svgPaths.p260f7c00}
            fill="var(--fill-0, #4E5969)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function IconChangeSizeHere1() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-center justify-center overflow-clip p-0 relative shrink-0"
      data-name="icon <- change size here"
    >
      <GeneralApps />
    </div>
  );
}

function Wrapper2() {
  return (
    <div
      className="basis-0 box-border content-stretch flex gap-2 grow items-center justify-start min-h-px min-w-px overflow-clip p-0 relative shrink-0"
      data-name="wrapper"
    >
      <div className="flex flex-col font-['PingFang_SC:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#4e5969] text-[14px] text-nowrap">
        <p className="block leading-[22px] whitespace-pre">数据可视化</p>
      </div>
    </div>
  );
}

function Suffix1() {
  return (
    <div className="relative shrink-0 size-3.5" data-name="suffix">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="suffix">
          <path
            clipRule="evenodd"
            d={svgPaths.p3d05b00}
            fill="var(--fill-0, #4E5969)"
            fillRule="evenodd"
            id="Stroke (Stroke)"
          />
        </g>
      </svg>
    </div>
  );
}

function MenuItem1() {
  return (
    <div className="bg-[rgba(255,255,255,0)] relative rounded-sm shrink-0 w-full" data-name="menu-item">
      <div className="flex flex-row items-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex gap-4 items-center justify-start px-3 py-[9px] relative w-full">
          <IconChangeSizeHere1 />
          <Wrapper2 />
          <Suffix1 />
        </div>
      </div>
    </div>
  );
}

function InteractiveButtonList() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="interactive-button/list">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="interactive-button/list">
          <path clipRule="evenodd" d={svgPaths.pabb9680} fill="var(--fill-0, #4E5969)" fillRule="evenodd" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function IconWrapper() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-center justify-center overflow-clip p-0 relative shrink-0"
      data-name="icon-wrapper"
    >
      <InteractiveButtonList />
    </div>
  );
}

function Wrapper3() {
  return (
    <div
      className="basis-0 box-border content-stretch flex gap-2 grow items-center justify-start min-h-px min-w-px overflow-clip p-0 relative shrink-0"
      data-name="wrapper"
    >
      <div className="flex flex-col font-['PingFang_SC:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#4e5969] text-[14px] text-nowrap">
        <p className="block leading-[22px] whitespace-pre">列表页</p>
      </div>
    </div>
  );
}

function Suffix2() {
  return (
    <div className="relative shrink-0 size-3.5" data-name="suffix">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="suffix">
          <path
            clipRule="evenodd"
            d={svgPaths.p3d05b00}
            fill="var(--fill-0, #4E5969)"
            fillRule="evenodd"
            id="Stroke (Stroke)"
          />
        </g>
      </svg>
    </div>
  );
}

function MenuItem2() {
  return (
    <div className="bg-[rgba(255,255,255,0)] relative rounded-sm shrink-0 w-full" data-name="menu-item">
      <div className="flex flex-row items-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex gap-4 items-center justify-start px-3 py-[9px] relative w-full">
          <IconWrapper />
          <Wrapper3 />
          <Suffix2 />
        </div>
      </div>
    </div>
  );
}

function InteractiveButtonSettings1() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="interactive-button/settings">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="interactive-button/settings">
          <path
            clipRule="evenodd"
            d={svgPaths.p1ad2bf80}
            fill="var(--fill-0, #4E5969)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function IconChangeSizeHere2() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-center justify-center overflow-clip p-0 relative shrink-0"
      data-name="icon <- change size here"
    >
      <InteractiveButtonSettings1 />
    </div>
  );
}

function Wrapper4() {
  return (
    <div
      className="basis-0 box-border content-stretch flex gap-2 grow items-center justify-start min-h-px min-w-px overflow-clip p-0 relative shrink-0"
      data-name="wrapper"
    >
      <div className="flex flex-col font-['PingFang_SC:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#4e5969] text-[14px] text-nowrap">
        <p className="block leading-[22px] whitespace-pre">表单页</p>
      </div>
    </div>
  );
}

function Suffix3() {
  return (
    <div className="relative shrink-0 size-3.5" data-name="suffix">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="suffix">
          <path
            clipRule="evenodd"
            d={svgPaths.p3d05b00}
            fill="var(--fill-0, #4E5969)"
            fillRule="evenodd"
            id="Stroke (Stroke)"
          />
        </g>
      </svg>
    </div>
  );
}

function MenuItem3() {
  return (
    <div className="bg-[rgba(255,255,255,0)] relative rounded-sm shrink-0 w-full" data-name="menu-item">
      <div className="flex flex-row items-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex gap-4 items-center justify-start px-3 py-[9px] relative w-full">
          <IconChangeSizeHere2 />
          <Wrapper4 />
          <Suffix3 />
        </div>
      </div>
    </div>
  );
}

function GeneralFile() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="general/file">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="general/file">
          <path
            clipRule="evenodd"
            d={svgPaths.p12d98d80}
            fill="var(--fill-0, #4E5969)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function IconChangeSizeHere3() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-center justify-center overflow-clip p-0 relative shrink-0"
      data-name="icon <- change size here"
    >
      <GeneralFile />
    </div>
  );
}

function Wrapper5() {
  return (
    <div
      className="basis-0 box-border content-stretch flex gap-2 grow items-center justify-start min-h-px min-w-px overflow-clip p-0 relative shrink-0"
      data-name="wrapper"
    >
      <div className="flex flex-col font-['PingFang_SC:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#4e5969] text-[14px] text-nowrap">
        <p className="block leading-[22px] whitespace-pre">详情页</p>
      </div>
    </div>
  );
}

function Suffix4() {
  return (
    <div className="relative shrink-0 size-3.5" data-name="suffix">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="suffix">
          <path
            clipRule="evenodd"
            d={svgPaths.p3d05b00}
            fill="var(--fill-0, #4E5969)"
            fillRule="evenodd"
            id="Stroke (Stroke)"
          />
        </g>
      </svg>
    </div>
  );
}

function MenuItem4() {
  return (
    <div className="bg-[rgba(255,255,255,0)] relative rounded-sm shrink-0 w-full" data-name="menu-item">
      <div className="flex flex-row items-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex gap-4 items-center justify-start px-3 py-[9px] relative w-full">
          <IconChangeSizeHere3 />
          <Wrapper5 />
          <Suffix4 />
        </div>
      </div>
    </div>
  );
}

function TipsCheckCircle1() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="tips/check-circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="tips/check-circle">
          <path clipRule="evenodd" d={svgPaths.pb815500} fill="var(--fill-0, #165DFF)" fillRule="evenodd" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function IconWrapper1() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-center justify-center overflow-clip p-0 relative shrink-0"
      data-name="icon-wrapper"
    >
      <TipsCheckCircle1 />
    </div>
  );
}

function Wrapper6() {
  return (
    <div
      className="basis-0 box-border content-stretch flex gap-2 grow items-center justify-start min-h-px min-w-px overflow-clip p-0 relative shrink-0"
      data-name="wrapper"
    >
      <div className="flex flex-col font-['PingFang_SC:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#165dff] text-[14px] text-nowrap">
        <p className="block leading-[22px] whitespace-pre">结果页</p>
      </div>
    </div>
  );
}

function Suffix5() {
  return (
    <div className="relative shrink-0 size-3.5" data-name="suffix">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="suffix">
          <path
            clipRule="evenodd"
            d={svgPaths.p14314a00}
            fill="var(--fill-0, #165DFF)"
            fillRule="evenodd"
            id="Stroke (Stroke)"
          />
        </g>
      </svg>
    </div>
  );
}

function Header() {
  return (
    <div className="relative shrink-0 w-full" data-name="header">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-4 items-center justify-start px-3 py-[9px] relative w-full">
          <IconWrapper1 />
          <Wrapper6 />
          <Suffix5 />
        </div>
      </div>
    </div>
  );
}

function Content5() {
  return (
    <div
      className="basis-0 box-border content-stretch flex gap-2 grow items-center justify-start min-h-px min-w-px overflow-clip p-0 relative shrink-0"
      data-name="content"
    >
      <div className="flex flex-col font-['PingFang_SC:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#165dff] text-[14px] text-nowrap">
        <p className="block leading-[22px] whitespace-pre">成功页</p>
      </div>
    </div>
  );
}

function VerticalMenuItem2RdLevel() {
  return (
    <div className="bg-[#f2f3f5] relative rounded-sm shrink-0 w-full" data-name="vertical-menu-item/2rd-level">
      <div className="flex flex-row items-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex items-center justify-start pl-[42px] pr-2 py-[9px] relative w-full">
          <Content5 />
        </div>
      </div>
    </div>
  );
}

function Content6() {
  return (
    <div
      className="basis-0 box-border content-stretch flex gap-2 grow items-center justify-start min-h-px min-w-px overflow-clip p-0 relative shrink-0"
      data-name="content"
    >
      <div className="flex flex-col font-['PingFang_SC:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#1d2129] text-[14px] text-nowrap">
        <p className="block leading-[22px] whitespace-pre">失败页</p>
      </div>
    </div>
  );
}

function VerticalMenuItem2RdLevel1() {
  return (
    <div
      className="bg-[rgba(255,255,255,0)] relative rounded-sm shrink-0 w-full"
      data-name="vertical-menu-item/2rd-level"
    >
      <div className="flex flex-row items-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex items-center justify-start pl-[42px] pr-2 py-[9px] relative w-full">
          <Content6 />
        </div>
      </div>
    </div>
  );
}

function Submenu() {
  return (
    <div
      className="bg-[#ffffff] box-border content-stretch flex flex-col gap-1 items-start justify-start p-0 relative shrink-0 w-full"
      data-name="submenu"
    >
      <VerticalMenuItem2RdLevel />
      <VerticalMenuItem2RdLevel1 />
    </div>
  );
}

function MenuItem5() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-1 items-center justify-start overflow-clip p-0 relative rounded-sm shrink-0 w-full"
      data-name="menu-item"
    >
      <Header />
      <Submenu />
    </div>
  );
}

function TipsInfoCircle() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="tips/info-circle">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="tips/info-circle">
          <path
            clipRule="evenodd"
            d={svgPaths.p20066f80}
            fill="var(--fill-0, #4E5969)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function IconChangeSizeHere4() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-center justify-center overflow-clip p-0 relative shrink-0"
      data-name="icon <- change size here"
    >
      <TipsInfoCircle />
    </div>
  );
}

function Wrapper7() {
  return (
    <div
      className="basis-0 box-border content-stretch flex gap-2 grow items-center justify-start min-h-px min-w-px overflow-clip p-0 relative shrink-0"
      data-name="wrapper"
    >
      <div className="flex flex-col font-['PingFang_SC:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#4e5969] text-[14px] text-nowrap">
        <p className="block leading-[22px] whitespace-pre">异常页</p>
      </div>
    </div>
  );
}

function Suffix6() {
  return (
    <div className="relative shrink-0 size-3.5" data-name="suffix">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="suffix">
          <path
            clipRule="evenodd"
            d={svgPaths.p3d05b00}
            fill="var(--fill-0, #4E5969)"
            fillRule="evenodd"
            id="Stroke (Stroke)"
          />
        </g>
      </svg>
    </div>
  );
}

function MenuItem6() {
  return (
    <div className="bg-[rgba(255,255,255,0)] relative rounded-sm shrink-0 w-full" data-name="menu-item">
      <div className="flex flex-row items-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex gap-4 items-center justify-start px-3 py-[9px] relative w-full">
          <IconChangeSizeHere4 />
          <Wrapper7 />
          <Suffix6 />
        </div>
      </div>
    </div>
  );
}

function GeneralUser() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="general/user">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="general/user">
          <path
            clipRule="evenodd"
            d={svgPaths.p15ad1400}
            fill="var(--fill-0, #4E5969)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function IconChangeSizeHere5() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-center justify-center overflow-clip p-0 relative shrink-0"
      data-name="icon <- change size here"
    >
      <GeneralUser />
    </div>
  );
}

function Wrapper8() {
  return (
    <div
      className="basis-0 box-border content-stretch flex gap-2 grow items-center justify-start min-h-px min-w-px overflow-clip p-0 relative shrink-0"
      data-name="wrapper"
    >
      <div className="flex flex-col font-['PingFang_SC:Regular',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#4e5969] text-[14px] text-nowrap">
        <p className="block leading-[22px] whitespace-pre">个人中心</p>
      </div>
    </div>
  );
}

function Suffix7() {
  return (
    <div className="relative shrink-0 size-3.5" data-name="suffix">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="suffix">
          <path
            clipRule="evenodd"
            d={svgPaths.p3d05b00}
            fill="var(--fill-0, #4E5969)"
            fillRule="evenodd"
            id="Stroke (Stroke)"
          />
        </g>
      </svg>
    </div>
  );
}

function MenuItem7() {
  return (
    <div className="bg-[rgba(255,255,255,0)] relative rounded-sm shrink-0 w-full" data-name="menu-item">
      <div className="flex flex-row items-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex gap-4 items-center justify-start px-3 py-[9px] relative w-full">
          <IconChangeSizeHere5 />
          <Wrapper8 />
          <Suffix7 />
        </div>
      </div>
    </div>
  );
}

function ArcoMenuInner() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-full" data-name="arco-menu-inner">
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-1 items-start justify-start px-2 py-1 relative size-full">
          <MenuItem />
          <MenuItem1 />
          <MenuItem2 />
          <MenuItem3 />
          <MenuItem4 />
          <MenuItem5 />
          <MenuItem6 />
          <MenuItem7 />
        </div>
      </div>
    </div>
  );
}

function DirectionMenuFold() {
  return (
    <div className="relative size-4" data-name="direction/menu-fold">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="direction/menu-fold">
          <path
            clipRule="evenodd"
            d={svgPaths.p19cca580}
            fill="var(--fill-0, #86909C)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function MenuIconShrink() {
  return (
    <div className="bg-[#f7f8fa] relative rounded-sm shrink-0 size-6" data-name="menu-icon/shrink">
      <div className="absolute flex items-center justify-center left-1/2 size-4 top-1/2 translate-x-[-50%] translate-y-[-50%]">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <DirectionMenuFold />
        </div>
      </div>
    </div>
  );
}

function ShrinkWrapper() {
  return (
    <div className="bg-[#ffffff] relative shrink-0 w-full" data-name="shrink-wrapper">
      <div className="flex flex-row items-center justify-end relative size-full">
        <div className="box-border content-stretch flex gap-2.5 items-center justify-end p-[12px] relative w-full">
          <MenuIconShrink />
        </div>
      </div>
    </div>
  );
}

function Menu() {
  return (
    <div
      className="absolute bg-[#ffffff] bottom-0 box-border content-stretch flex flex-col items-start justify-start left-0 overflow-clip p-0 top-[60px] w-[220px]"
      data-name="menu"
    >
      <ArcoMenuInner />
      <ShrinkWrapper />
    </div>
  );
}

export default function Component4() {
  return (
    <div className="bg-[#f7f8fa] relative size-full" data-name="结果页/成功页">
      <Breadcrumb />
      <Body />
      <Navbar />
      <Menu />
    </div>
  );
}