
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Button } from "../ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { ArrowUpIcon, ArrowDownIcon, TrendingUp, TrendingDown } from "lucide-react";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

// 模拟数据
const summaryMetricsData = {
  revenue: { current: 12500000, ytd: 98500000, growth: 15.2 },
  cost: { current: 8900000, ytd: 68200000, growth: 8.7 },
  profit: { current: 3600000, ytd: 30300000, growth: 28.5 }
};

const monthlyTrendData = [
  { month: "1月", revenue: 8500000, cost: 6200000, profit: 2300000 },
  { month: "2月", revenue: 9200000, cost: 6800000, profit: 2400000 },
  { month: "3月", revenue: 10100000, cost: 7400000, profit: 2700000 },
  { month: "4月", revenue: 11200000, cost: 7900000, profit: 3300000 },
  { month: "5月", revenue: 11800000, cost: 8300000, profit: 3500000 },
  { month: "6月", revenue: 12500000, cost: 8900000, profit: 3600000 }
];

const expenseTypeData = [
  { name: "工位费用", actual: 4200000, budget: 4500000 },
  { name: "空间费用", actual: 2800000, budget: 3000000 },
  { name: "运营费用", actual: 1200000, budget: 1300000 },
  { name: "服务费用", actual: 700000, budget: 800000 }
];

const regionData = [
  { name: "CHN", actual: 5800000, budget: 6000000 },
  { name: "AMS", actual: 1500000, budget: 1600000 },
  { name: "EMEA", actual: 1200000, budget: 1300000 },
  { name: "APAC", actual: 400000, budget: 500000 }
];

const workAreaTableData = [
  { time: "2024-06", region: "CHN", country: "中国", city: "北京", workArea: "北京总部A栋", department: "技术部", revenue: 2800000, cost: 1900000, profit: 900000 },
  { time: "2024-06", region: "CHN", country: "中国", city: "北京", workArea: "北京总部B栋", department: "产品部", revenue: 2200000, cost: 1600000, profit: 600000 },
  { time: "2024-06", region: "AMS", country: "美国", city: "纽约", workArea: "纽约办公室", department: "销售部", revenue: 1500000, cost: 1100000, profit: 400000 },
  { time: "2024-06", region: "EMEA", country: "英国", city: "伦敦", workArea: "伦敦分部", department: "市场部", revenue: 1200000, cost: 800000, profit: 400000 }
];

const businessTableData = [
  { time: "2024-06", region: "CHN", country: "中国", city: "北京", department: "技术部", workArea: "北京总部A栋", revenue: 2800000, cost: 1900000, profit: 900000 },
  { time: "2024-06", region: "CHN", country: "中国", city: "北京", department: "产品部", workArea: "北京总部B栋", revenue: 2200000, cost: 1600000, profit: 600000 },
  { time: "2024-06", region: "AMS", country: "美国", city: "纽约", department: "销售部", workArea: "纽约办公室", revenue: 1500000, cost: 1100000, profit: 400000 },
  { time: "2024-06", region: "EMEA", country: "英国", city: "伦敦", department: "市场部", workArea: "伦敦分部", revenue: 1200000, cost: 800000, profit: 400000 }
];

// 收入数据
const revenueMetricsData = {
  total: { current: 12500000, ytd: 98500000, growth: 15.2 },
  workspace: { current: 6800000, ytd: 52000000, growth: 12.5 },
  space: { current: 3200000, ytd: 28500000, growth: 18.7 },
  operation: { current: 1800000, ytd: 12500000, growth: 22.3 },
  service: { current: 700000, ytd: 5500000, growth: 8.9 }
};

const revenueDetailData = {
  furniture: { current: 4200000, ytd: 32000000, growth: 14.2 },
  meeting: { current: 2600000, ytd: 20000000, growth: 10.8 }
};

const revenueTrendData = [
  { month: "1月", total: 8500000, workspace: 4600000, space: 2200000, operation: 1200000, service: 500000 },
  { month: "2月", total: 9200000, workspace: 5000000, space: 2400000, operation: 1300000, service: 500000 },
  { month: "3月", total: 10100000, workspace: 5500000, space: 2700000, operation: 1400000, service: 500000 },
  { month: "4月", total: 11200000, workspace: 6100000, space: 2900000, operation: 1600000, service: 600000 },
  { month: "5月", total: 11800000, workspace: 6400000, space: 3100000, operation: 1700000, service: 600000 },
  { month: "6月", total: 12500000, workspace: 6800000, space: 3200000, operation: 1800000, service: 700000 }
];

// 区域收入数据
const areaRevenueData = [
  { area: "A区", zone: "研发中心", seats: 150, utilization: "85%", revenue: 280000, growth: "+12.5%" },
  { area: "B区", zone: "产品部", seats: 120, utilization: "78%", revenue: 220000, growth: "+8.3%" },
  { area: "C区", zone: "销售部", seats: 100, utilization: "92%", revenue: 320000, growth: "+15.8%" },
  { area: "D区", zone: "市场部", seats: 80, utilization: "75%", revenue: 180000, growth: "+5.2%" }
];

// 成本数据
const costMetricsData = {
  total: { current: 8900000, ytd: 68200000, growth: 8.7 },
  workspace: { current: 4200000, ytd: 32500000, growth: 9.2 },
  engineering: { current: 2800000, ytd: 21800000, growth: 7.5 },
  operation: { current: 1500000, ytd: 11200000, growth: 12.3 },
  comprehensive: { current: 400000, ytd: 2700000, growth: 3.8 }
};

const costDetailData = {
  rent: { current: 2800000, ytd: 21000000, growth: 6.8 },
  furniture: { current: 1400000, ytd: 11500000, growth: 11.7 },
  renovation: { current: 2400000, ytd: 18600000, growth: 8.3 },
  staff: { current: 400000, ytd: 2900000, growth: 15.2 },
  property: { current: 900000, ytd: 6800000, growth: 9.5 },
  consultant: { current: 300000, ytd: 2200000, growth: 5.4 },
  ifm: { current: 200000, ytd: 1600000, growth: 18.7 },
  other: { current: 100000, ytd: 800000, growth: 2.1 }
};

const costTrendData = [
  { month: "1月", total: 6200000, unitWorkspace: 5200, unitEngineering: 180, unitOperation: 95 },
  { month: "2月", total: 6800000, unitWorkspace: 5400, unitEngineering: 185, unitOperation: 98 },
  { month: "3月", total: 7400000, unitWorkspace: 5600, unitEngineering: 190, unitOperation: 102 },
  { month: "4月", total: 7900000, unitWorkspace: 5800, unitEngineering: 195, unitOperation: 105 },
  { month: "5月", total: 8300000, unitWorkspace: 6000, unitEngineering: 200, unitOperation: 108 },
  { month: "6月", total: 8900000, unitWorkspace: 6200, unitEngineering: 205, unitOperation: 112 }
];

const formatCurrency = (value: number) => {
  return `¥${(value / 10000).toFixed(1)}万`;
};

const formatNumber = (value: number) => {
  return value.toLocaleString();
};

export function BusinessAnalysis() {
  const [activeTab, setActiveTab] = useState("summary");
  const [listTab, setListTab] = useState("workArea");
  
  const [region, setRegion] = useState("all");
  const [timeType, setTimeType] = useState("month");
  const [currency, setCurrency] = useState("cny");

  const MetricCard = ({ title, current, ytd, growth, prefix = "¥", showChart = false, currentGrowth, ytdGrowth }) => {
    // 收入占比数据
    const revenueBreakdownData = [
      { name: "工位收入", value: 6800000, color: "#3b82f6" },
      { name: "空间收入", value: 3200000, color: "#10b981" },
      { name: "运营收入", value: 1800000, color: "#f59e0b" },
      { name: "服务收入", value: 700000, color: "#8b5cf6" }
    ];

    const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }) => {
      if (percent < 0.1) return null; // 小于10%不显示标签
      const RADIAN = Math.PI / 180;
      const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
      const x = cx + radius * Math.cos(-midAngle * RADIAN);
      const y = cy + radius * Math.sin(-midAngle * RADIAN);

      return (
        <text 
          x={x} 
          y={y} 
          fill="white" 
          textAnchor={x > cx ? 'start' : 'end'} 
          dominantBaseline="central"
          className="text-xs font-medium"
        >
          {`${(percent * 100).toFixed(0)}%`}
        </text>
      );
    };

    return (
      <Card className="bg-white border border-gray-200 h-full flex flex-col">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-gray-600 font-bold">{title}</CardTitle>
        </CardHeader>
        <CardContent className="pt-0 flex-1 flex flex-col justify-between">
          {showChart && title === "总收入" ? (
            <div className="flex-1 flex flex-col">
              {/* 上方：甜甜圈图区域 */}
              <div className="flex-1 flex flex-col items-center justify-center">
                <div className="h-32 w-32">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={revenueBreakdownData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={renderCustomizedLabel}
                        outerRadius={50}
                        innerRadius={30}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {revenueBreakdownData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                
                {/* 图例 */}
                <div className="grid grid-cols-2 gap-1 mt-2">
                  {revenueBreakdownData.map((item, index) => (
                    <div key={index} className="flex items-center gap-1">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }}></div>
                      <span className="text-xs text-gray-600">{item.name}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* 下方：数据区域 */}
              <div className="space-y-2 mt-4">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-500">本期:</span>
                  <span className="text-lg font-medium text-gray-900">
                    {prefix}{formatNumber(current)}
                  </span>
                  <div className="flex items-center gap-1">
                    {(currentGrowth || growth) > 0 ? (
                      <ArrowUpIcon className="h-3 w-3 text-green-500" />
                    ) : (
                      <ArrowDownIcon className="h-3 w-3 text-red-500" />
                    )}
                    <span className={`text-xs ${(currentGrowth || growth) > 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {(currentGrowth || growth) > 0 ? '+' : ''}{currentGrowth || growth}%
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-500">年累计:</span>
                  <span className="text-lg font-medium text-gray-900">
                    {prefix}{formatNumber(ytd)}
                  </span>
                  <div className="flex items-center gap-1">
                    {(ytdGrowth || growth) > 0 ? (
                      <ArrowUpIcon className="h-3 w-3 text-green-500" />
                    ) : (
                      <ArrowDownIcon className="h-3 w-3 text-red-500" />
                    )}
                    <span className={`text-xs ${(ytdGrowth || growth) > 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {(ytdGrowth || growth) > 0 ? '+' : ''}{ytdGrowth || growth}%
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500">本期:</span>
                <span className="text-lg font-medium text-gray-900">
                  {prefix}{formatNumber(current)}
                </span>
                <div className="flex items-center gap-1">
                  {(currentGrowth || growth) > 0 ? (
                    <ArrowUpIcon className="h-3 w-3 text-green-500" />
                  ) : (
                    <ArrowDownIcon className="h-3 w-3 text-red-500" />
                  )}
                  <span className={`text-xs ${(currentGrowth || growth) > 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {(currentGrowth || growth) > 0 ? '+' : ''}{currentGrowth || growth}%
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500">年累计:</span>
                <span className="text-lg font-medium text-gray-900">
                  {prefix}{formatNumber(ytd)}
                </span>
                <div className="flex items-center gap-1">
                  {(ytdGrowth || growth) > 0 ? (
                    <ArrowUpIcon className="h-3 w-3 text-green-500" />
                  ) : (
                    <ArrowDownIcon className="h-3 w-3 text-red-500" />
                  )}
                  <span className={`text-xs ${(ytdGrowth || growth) > 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {(ytdGrowth || growth) > 0 ? '+' : ''}{ytdGrowth || growth}%
                  </span>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  const renderFilters = () => (
    <div className="flex items-center gap-4 mb-6">
      <div>
        <Select value={region} onValueChange={setRegion}>
          <SelectTrigger className="w-32 h-8 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部大区</SelectItem>
            <SelectItem value="CHN">CHN</SelectItem>
            <SelectItem value="AMS">AMS</SelectItem>
            <SelectItem value="EMEA">EMEA</SelectItem>
            <SelectItem value="APAC">APAC</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <Select value={timeType} onValueChange={setTimeType}>
          <SelectTrigger className="w-24 h-8 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="month">月</SelectItem>
            <SelectItem value="quarter">季</SelectItem>
            <SelectItem value="half">半年</SelectItem>
            <SelectItem value="year">年</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <Select value={currency} onValueChange={setCurrency}>
          <SelectTrigger className="w-24 h-8 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="cny">人民币</SelectItem>
            <SelectItem value="usd">美元</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );

  return (
    <div className="flex-1 overflow-auto" style={{ maxWidth: '1300px', margin: '0 auto' }}>
      <div className="space-y-6 p-[0px]">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-medium">经营分析</h1>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="inline-flex mb-6">
            <TabsTrigger value="summary" className="text-xs text-primary">汇总</TabsTrigger>
            <TabsTrigger value="revenue" className="text-xs text-primary">收入</TabsTrigger>
            <TabsTrigger value="cost" className="text-xs text-primary">成本</TabsTrigger>
          </TabsList>

          {/* 汇总标签页 */}
          <TabsContent value="summary" className="space-y-6">
            {renderFilters()}
            
            {/* 统计区域 */}
            <div className="space-y-6">
              {/* 第1行：大指标 */}
              <div className="grid grid-cols-3 gap-6">
                <MetricCard 
                  title="总收入" 
                  current={summaryMetricsData.revenue.current}
                  ytd={summaryMetricsData.revenue.ytd}
                  growth={summaryMetricsData.revenue.growth}
                  currentGrowth={12.8}
                  ytdGrowth={15.2}
                />
                <MetricCard 
                  title="总成本" 
                  current={summaryMetricsData.cost.current}
                  ytd={summaryMetricsData.cost.ytd}
                  growth={summaryMetricsData.cost.growth}
                  currentGrowth={6.5}
                  ytdGrowth={8.7}
                />
                <MetricCard 
                  title="收支差" 
                  current={summaryMetricsData.profit.current}
                  ytd={summaryMetricsData.profit.ytd}
                  growth={summaryMetricsData.profit.growth}
                  currentGrowth={25.3}
                  ytdGrowth={28.5}
                />
              </div>

              {/* 第2行：月度趋势图 */}
              <Card className="bg-white border border-gray-200 mt-[0px] mr-[0px] mb-[21px] ml-[0px]">
                <CardHeader>
                  <CardTitle className="text-sm">月度趋势</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={monthlyTrendData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" className="text-xs" />
                        <YAxis className="text-xs" tickFormatter={formatCurrency} />
                        <Tooltip formatter={(value) => formatCurrency(value)} />
                        <Legend />
                        <Line type="monotone" dataKey="revenue" stroke="#3b82f6" name="总收入" strokeWidth={2} />
                        <Line type="monotone" dataKey="cost" stroke="#ef4444" name="总成本" strokeWidth={2} />
                        <Line type="monotone" dataKey="profit" stroke="#10b981" name="收支差" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* 第3行：对比图表 */}
              <div className="grid grid-cols-2 gap-6">
                <Card className="bg-white border border-gray-200">
                  <CardHeader>
                    <CardTitle className="text-sm">按费用类型 vs 预算</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={expenseTypeData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" className="text-xs" />
                          <YAxis className="text-xs" tickFormatter={formatCurrency} />
                          <Tooltip formatter={(value) => formatCurrency(value)} />
                          <Legend />
                          <Bar dataKey="actual" fill="#3b82f6" name="实际" />
                          <Bar dataKey="budget" fill="#e5e7eb" name="预算" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white border border-gray-200">
                  <CardHeader>
                    <CardTitle className="text-sm">按房产大区 vs 预算</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={regionData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" className="text-xs" />
                          <YAxis className="text-xs" tickFormatter={formatCurrency} />
                          <Tooltip formatter={(value) => formatCurrency(value)} />
                          <Legend />
                          <Bar dataKey="actual" fill="#3b82f6" name="实际" />
                          <Bar dataKey="budget" fill="#e5e7eb" name="预算" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* 列表区域 */}
            <Card className="bg-white border border-gray-200">
              <CardHeader>
                <CardTitle className="text-sm font-bold">列表</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <Tabs value={listTab} onValueChange={setListTab}>
                    <TabsList className="h-8">
                      <TabsTrigger value="workArea" className="text-xs h-6">按工区</TabsTrigger>
                      <TabsTrigger value="business" className="text-xs h-6">按业务</TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-gray-50">
                        {listTab === "workArea" ? (
                          <>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">时间</TableHead>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">分区</TableHead>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">国家</TableHead>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">城市</TableHead>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">工区</TableHead>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">部门</TableHead>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">总收入</TableHead>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">总成本</TableHead>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">收支差</TableHead>
                          </>
                        ) : (
                          <>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">时间</TableHead>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">部门</TableHead>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">分区</TableHead>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">国家</TableHead>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">城市</TableHead>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">工区</TableHead>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">总收入</TableHead>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">总成本</TableHead>
                            <TableHead className="text-xs font-medium text-gray-700 h-10">收支差</TableHead>
                          </>
                        )}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(listTab === "workArea" ? workAreaTableData : businessTableData).map((row, index) => (
                        <TableRow key={index} className="hover:bg-gray-50">
                          <TableCell className="text-xs text-gray-900">{row.time}</TableCell>
                          {listTab === "workArea" ? (
                            <>
                              <TableCell className="text-xs text-gray-900">{row.region}</TableCell>
                              <TableCell className="text-xs text-gray-900">{row.country}</TableCell>
                              <TableCell className="text-xs text-gray-900">{row.city}</TableCell>
                              <TableCell className="text-xs text-gray-900">{row.workArea}</TableCell>
                              <TableCell className="text-xs text-gray-900">{row.department}</TableCell>
                            </>
                          ) : (
                            <>
                              <TableCell className="text-xs text-gray-900">{row.department}</TableCell>
                              <TableCell className="text-xs text-gray-900">{row.region}</TableCell>
                              <TableCell className="text-xs text-gray-900">{row.country}</TableCell>
                              <TableCell className="text-xs text-gray-900">{row.city}</TableCell>
                              <TableCell className="text-xs text-gray-900">{row.workArea}</TableCell>
                            </>
                          )}
                          <TableCell className="text-xs text-gray-900 font-medium">
                            {formatCurrency(row.revenue)}
                          </TableCell>
                          <TableCell className="text-xs text-gray-900 font-medium">
                            {formatCurrency(row.cost)}
                          </TableCell>
                          <TableCell className="text-xs text-gray-900 font-medium">
                            {formatCurrency(row.profit)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* 收入标签页 */}
          <TabsContent value="revenue" className="space-y-6">
            {renderFilters()}
            
            <div className="space-y-6">
              {/* 第1行：大指标4列 */}
              <div className="grid grid-cols-4 gap-4">
                {/* 第1列 */}
                <div className="h-full flex flex-col">
                  <MetricCard 
                    title="总收入" 
                    current={revenueMetricsData.total.current}
                    ytd={revenueMetricsData.total.ytd}
                    growth={revenueMetricsData.total.growth}
                    showChart={true}
                    currentGrowth={12.8}
                    ytdGrowth={15.2}
                  />
                </div>

                {/* 第2列 */}
                <div className="space-y-2 h-full flex flex-col">
                  <Card className="bg-white border border-gray-200 p-3 flex-1">
                    <div className="text-xs text-gray-600 mb-1">工位收入</div>
                    <div className="text-sm font-medium">{formatCurrency(revenueMetricsData.workspace.current)}</div>
                  </Card>
                  <Card className="bg-white border border-gray-200 p-3 flex-1">
                    <div className="text-xs text-gray-600 mb-1">空间收入</div>
                    <div className="text-sm font-medium">{formatCurrency(revenueMetricsData.space.current)}</div>
                  </Card>
                  <Card className="bg-white border border-gray-200 p-3 flex-1">
                    <div className="text-xs text-gray-600 mb-1">运营收入</div>
                    <div className="text-sm font-medium">{formatCurrency(revenueMetricsData.operation.current)}</div>
                  </Card>
                  <Card className="bg-white border border-gray-200 p-3 flex-1">
                    <div className="text-xs text-gray-600 mb-1">服务收入</div>
                    <div className="text-sm font-medium">{formatCurrency(revenueMetricsData.service.current)}</div>
                  </Card>
                </div>

                {/* 第3列 */}
                <div className="space-y-2 h-full flex flex-col">
                  <Card className="bg-white border border-gray-200 p-3 flex-1">
                    <div className="text-xs text-gray-600 mb-1">桌椅收入</div>
                    <div className="text-sm font-medium">{formatCurrency(revenueDetailData.furniture.current)}</div>
                  </Card>
                  <Card className="bg-white border border-gray-200 p-3 flex-1">
                    <div className="text-xs text-gray-600 mb-1">会议室占用</div>
                    <div className="text-sm font-medium">{formatCurrency(revenueDetailData.meeting.current)}</div>
                  </Card>
                  <div className="flex-1"></div>
                  <div className="flex-1"></div>
                </div>

                {/* 第4列 - 暂时留空 */}
                <div className="space-y-2">
                  {/* 可以添加更多指标 */}
                </div>
              </div>

              {/* 第2行：收入趋势图 */}
              <Card className="bg-white border border-gray-200">
                <CardHeader>
                  <CardTitle className="text-sm">收入趋势</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={revenueTrendData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" className="text-xs" />
                        <YAxis className="text-xs" tickFormatter={formatCurrency} />
                        <Tooltip formatter={(value) => formatCurrency(value)} />
                        <Legend />
                        <Line type="monotone" dataKey="total" stroke="#3b82f6" name="总收入" strokeWidth={2} />
                        <Line type="monotone" dataKey="workspace" stroke="#10b981" name="工位收入" strokeWidth={2} />
                        <Line type="monotone" dataKey="space" stroke="#f59e0b" name="空间收入" strokeWidth={2} />
                        <Line type="monotone" dataKey="operation" stroke="#8b5cf6" name="运营收入" strokeWidth={2} />
                        <Line type="monotone" dataKey="service" stroke="#ef4444" name="服务收入" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* 第3行：区域收入表 */}
              <Card className="bg-white border border-gray-200">
                <CardHeader>
                  <CardTitle className="text-sm">区域收入详情</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-50">
                          <TableHead className="text-xs font-medium text-gray-700 h-10">分区</TableHead>
                          <TableHead className="text-xs font-medium text-gray-700 h-10">工区</TableHead>
                          <TableHead className="text-xs font-medium text-gray-700 h-10 text-right">工位数</TableHead>
                          <TableHead className="text-xs font-medium text-gray-700 h-10 text-right">使用率</TableHead>
                          <TableHead className="text-xs font-medium text-gray-700 h-10 text-right">本月收入</TableHead>
                          <TableHead className="text-xs font-medium text-gray-700 h-10 text-right">增长率</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {areaRevenueData.map((item, index) => (
                          <TableRow key={index} className="hover:bg-gray-50">
                            <TableCell className="text-xs text-gray-900">{item.area}</TableCell>
                            <TableCell className="text-xs text-gray-900">{item.zone}</TableCell>
                            <TableCell className="text-xs text-gray-900 text-right">{item.seats}</TableCell>
                            <TableCell className="text-xs text-gray-900 text-right">
                              <div className="flex items-center justify-end gap-2">
                                <div className="w-16 bg-gray-200 rounded-full h-2">
                                  <div 
                                    className="bg-blue-600 h-2 rounded-full" 
                                    style={{ width: item.utilization }}
                                  />
                                </div>
                                <span>{item.utilization}</span>
                              </div>
                            </TableCell>
                            <TableCell className="text-xs text-gray-900 text-right">¥{item.revenue}</TableCell>
                            <TableCell className="text-xs text-right">
                              <div className="flex items-center justify-end gap-1">
                                {parseFloat(item.growth) > 0 ? (
                                  <ArrowUpIcon className="h-3 w-3 text-green-500" />
                                ) : (
                                  <ArrowDownIcon className="h-3 w-3 text-red-500" />
                                )}
                                <span className={parseFloat(item.growth) > 0 ? 'text-green-500' : 'text-red-500'}>
                                  {item.growth}
                                </span>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* 成本标签页 */}
          <TabsContent value="cost" className="space-y-6">
            {renderFilters()}
            
            <div className="space-y-6">
              {/* 成本指标 */}
              <div className="grid grid-cols-4 gap-4">
                <Card className="bg-white border border-gray-200 p-3">
                  <div className="text-xs text-gray-600 mb-2">总成本</div>
                  <div className="text-lg font-medium">{formatCurrency(costMetricsData.total.current)}</div>
                  <div className="text-xs text-gray-500 mt-1">同比增长 {costMetricsData.total.growth}%</div>
                </Card>
                <Card className="bg-white border border-gray-200 p-3">
                  <div className="text-xs text-gray-600 mb-2">工位成本</div>
                  <div className="text-lg font-medium">{formatCurrency(costMetricsData.workspace.current)}</div>
                  <div className="text-xs text-gray-500 mt-1">同比增长 {costMetricsData.workspace.growth}%</div>
                </Card>
                <Card className="bg-white border border-gray-200 p-3">
                  <div className="text-xs text-gray-600 mb-2">工程成本</div>
                  <div className="text-lg font-medium">{formatCurrency(costMetricsData.engineering.current)}</div>
                  <div className="text-xs text-gray-500 mt-1">同比增长 {costMetricsData.engineering.growth}%</div>
                </Card>
                <Card className="bg-white border border-gray-200 p-3">
                  <div className="text-xs text-gray-600 mb-2">运营成本</div>
                  <div className="text-lg font-medium">{formatCurrency(costMetricsData.operation.current)}</div>
                  <div className="text-xs text-gray-500 mt-1">同比增长 {costMetricsData.operation.growth}%</div>
                </Card>
              </div>

              {/* 成本趋势图 */}
              <Card className="bg-white border border-gray-200">
                <CardHeader>
                  <CardTitle className="text-sm">成本趋势</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={costTrendData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" className="text-xs" />
                        <YAxis className="text-xs" tickFormatter={formatCurrency} />
                        <Tooltip formatter={(value) => formatCurrency(value)} />
                        <Legend />
                        <Line type="monotone" dataKey="total" stroke="#ef4444" name="总成本" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}